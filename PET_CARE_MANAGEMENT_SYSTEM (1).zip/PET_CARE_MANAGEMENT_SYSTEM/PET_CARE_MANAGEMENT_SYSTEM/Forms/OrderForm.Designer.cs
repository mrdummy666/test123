﻿namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    partial class OrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrderForm));
            BtnClose = new Button();
            LblTitle = new Label();
            TxtOrderID = new TextBox();
            label2 = new Label();
            label3 = new Label();
            TxtCreatedBy = new TextBox();
            LblCustomer1 = new Label();
            BtnSave = new Button();
            DgvCustomers = new DataGridView();
            TxtSearchCustomer = new TextBox();
            label4 = new Label();
            DtpDateCreated = new DateTimePicker();
            label6 = new Label();
            DgvItems = new DataGridView();
            BtnAddItem = new Button();
            BtnDeleteItem = new Button();
            label1 = new Label();
            TxtTotal = new TextBox();
            BtnUpdateItem = new Button();
            BtnPrint = new Button();
            TxtCustomer = new TextBox();
            LblCustomer2 = new Label();
            PrintDocReceipt = new System.Drawing.Printing.PrintDocument();
            PrintPrevDiagReceipt = new PrintPreviewDialog();
            ((System.ComponentModel.ISupportInitialize)DgvCustomers).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DgvItems).BeginInit();
            SuspendLayout();
            // 
            // BtnClose
            // 
            BtnClose.BackColor = Color.Red;
            BtnClose.Cursor = Cursors.Hand;
            BtnClose.FlatAppearance.BorderSize = 0;
            BtnClose.FlatStyle = FlatStyle.Flat;
            BtnClose.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            BtnClose.ForeColor = Color.White;
            BtnClose.Location = new Point(602, 1);
            BtnClose.Name = "BtnClose";
            BtnClose.Size = new Size(42, 34);
            BtnClose.TabIndex = 6;
            BtnClose.Text = "X";
            BtnClose.UseVisualStyleBackColor = false;
            BtnClose.Click += BtnClose_Click;
            // 
            // LblTitle
            // 
            LblTitle.AutoSize = true;
            LblTitle.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            LblTitle.ForeColor = Color.Black;
            LblTitle.Location = new Point(4, 5);
            LblTitle.Name = "LblTitle";
            LblTitle.Size = new Size(59, 20);
            LblTitle.TabIndex = 8;
            LblTitle.Text = "ORDER";
            // 
            // TxtOrderID
            // 
            TxtOrderID.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtOrderID.Location = new Point(36, 86);
            TxtOrderID.Name = "TxtOrderID";
            TxtOrderID.Size = new Size(253, 27);
            TxtOrderID.TabIndex = 0;
            TxtOrderID.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.WhiteSmoke;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(36, 65);
            label2.Name = "label2";
            label2.Size = new Size(59, 17);
            label2.TabIndex = 10;
            label2.Text = "Order ID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.WhiteSmoke;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(36, 124);
            label3.Name = "label3";
            label3.Size = new Size(71, 17);
            label3.TabIndex = 11;
            label3.Text = "Created By";
            // 
            // TxtCreatedBy
            // 
            TxtCreatedBy.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtCreatedBy.Location = new Point(36, 143);
            TxtCreatedBy.Name = "TxtCreatedBy";
            TxtCreatedBy.Size = new Size(253, 27);
            TxtCreatedBy.TabIndex = 1;
            TxtCreatedBy.TextAlign = HorizontalAlignment.Center;
            // 
            // LblCustomer1
            // 
            LblCustomer1.AutoSize = true;
            LblCustomer1.BackColor = Color.WhiteSmoke;
            LblCustomer1.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            LblCustomer1.Location = new Point(316, 65);
            LblCustomer1.Name = "LblCustomer1";
            LblCustomer1.Size = new Size(64, 17);
            LblCustomer1.TabIndex = 15;
            LblCustomer1.Text = "Customer";
            // 
            // BtnSave
            // 
            BtnSave.BackColor = SystemColors.Highlight;
            BtnSave.Cursor = Cursors.Hand;
            BtnSave.FlatAppearance.BorderSize = 0;
            BtnSave.FlatStyle = FlatStyle.Flat;
            BtnSave.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnSave.ForeColor = Color.White;
            BtnSave.Location = new Point(267, 588);
            BtnSave.Name = "BtnSave";
            BtnSave.Size = new Size(113, 34);
            BtnSave.TabIndex = 5;
            BtnSave.Text = "Save";
            BtnSave.UseVisualStyleBackColor = false;
            BtnSave.Click += BtnSave_Click;
            // 
            // DgvCustomers
            // 
            DgvCustomers.AllowUserToAddRows = false;
            DgvCustomers.AllowUserToDeleteRows = false;
            DgvCustomers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvCustomers.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.False;
            DgvCustomers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            DgvCustomers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvCustomers.Location = new Point(316, 86);
            DgvCustomers.Name = "DgvCustomers";
            DgvCustomers.ReadOnly = true;
            DgvCustomers.RowTemplate.Height = 25;
            DgvCustomers.Size = new Size(292, 138);
            DgvCustomers.TabIndex = 19;
            // 
            // TxtSearchCustomer
            // 
            TxtSearchCustomer.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            TxtSearchCustomer.Location = new Point(419, 55);
            TxtSearchCustomer.Name = "TxtSearchCustomer";
            TxtSearchCustomer.PlaceholderText = "Search Customer";
            TxtSearchCustomer.Size = new Size(189, 25);
            TxtSearchCustomer.TabIndex = 21;
            TxtSearchCustomer.TextChanged += TxtSearchOwner_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.WhiteSmoke;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(36, 181);
            label4.Name = "label4";
            label4.Size = new Size(85, 17);
            label4.TabIndex = 22;
            label4.Text = "Date Created";
            // 
            // DtpDateCreated
            // 
            DtpDateCreated.CalendarFont = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            DtpDateCreated.CustomFormat = "MMMM dd, yyyy";
            DtpDateCreated.Format = DateTimePickerFormat.Custom;
            DtpDateCreated.Location = new Point(36, 201);
            DtpDateCreated.Name = "DtpDateCreated";
            DtpDateCreated.Size = new Size(253, 23);
            DtpDateCreated.TabIndex = 23;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.WhiteSmoke;
            label6.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(36, 240);
            label6.Name = "label6";
            label6.Size = new Size(39, 17);
            label6.TabIndex = 24;
            label6.Text = "Items";
            // 
            // DgvItems
            // 
            DgvItems.AllowUserToAddRows = false;
            DgvItems.AllowUserToDeleteRows = false;
            DgvItems.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvItems.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Control;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            DgvItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            DgvItems.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvItems.Location = new Point(36, 260);
            DgvItems.Name = "DgvItems";
            DgvItems.ReadOnly = true;
            DgvItems.RowTemplate.Height = 25;
            DgvItems.Size = new Size(572, 232);
            DgvItems.TabIndex = 25;
            // 
            // BtnAddItem
            // 
            BtnAddItem.BackColor = SystemColors.Highlight;
            BtnAddItem.Cursor = Cursors.Hand;
            BtnAddItem.FlatAppearance.BorderSize = 0;
            BtnAddItem.FlatStyle = FlatStyle.Flat;
            BtnAddItem.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            BtnAddItem.ForeColor = Color.White;
            BtnAddItem.Location = new Point(445, 234);
            BtnAddItem.Name = "BtnAddItem";
            BtnAddItem.Size = new Size(53, 23);
            BtnAddItem.TabIndex = 26;
            BtnAddItem.Text = "Add";
            BtnAddItem.UseVisualStyleBackColor = false;
            BtnAddItem.Click += BtnAddItem_Click;
            // 
            // BtnDeleteItem
            // 
            BtnDeleteItem.BackColor = Color.Red;
            BtnDeleteItem.Cursor = Cursors.Hand;
            BtnDeleteItem.FlatAppearance.BorderSize = 0;
            BtnDeleteItem.FlatStyle = FlatStyle.Flat;
            BtnDeleteItem.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            BtnDeleteItem.ForeColor = Color.White;
            BtnDeleteItem.Location = new Point(555, 234);
            BtnDeleteItem.Name = "BtnDeleteItem";
            BtnDeleteItem.Size = new Size(53, 23);
            BtnDeleteItem.TabIndex = 27;
            BtnDeleteItem.Text = "Delete";
            BtnDeleteItem.UseVisualStyleBackColor = false;
            BtnDeleteItem.Click += BtnDeleteItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.WhiteSmoke;
            label1.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(36, 502);
            label1.Name = "label1";
            label1.Size = new Size(36, 17);
            label1.TabIndex = 28;
            label1.Text = "Total";
            // 
            // TxtTotal
            // 
            TxtTotal.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtTotal.Location = new Point(36, 522);
            TxtTotal.Name = "TxtTotal";
            TxtTotal.Size = new Size(253, 27);
            TxtTotal.TabIndex = 29;
            TxtTotal.TextAlign = HorizontalAlignment.Center;
            // 
            // BtnUpdateItem
            // 
            BtnUpdateItem.BackColor = Color.LimeGreen;
            BtnUpdateItem.Cursor = Cursors.Hand;
            BtnUpdateItem.FlatAppearance.BorderSize = 0;
            BtnUpdateItem.FlatStyle = FlatStyle.Flat;
            BtnUpdateItem.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            BtnUpdateItem.ForeColor = Color.White;
            BtnUpdateItem.Location = new Point(500, 234);
            BtnUpdateItem.Name = "BtnUpdateItem";
            BtnUpdateItem.Size = new Size(53, 23);
            BtnUpdateItem.TabIndex = 30;
            BtnUpdateItem.Text = "Update";
            BtnUpdateItem.UseVisualStyleBackColor = false;
            BtnUpdateItem.Click += BtnUpdateItem_Click;
            // 
            // BtnPrint
            // 
            BtnPrint.BackColor = SystemColors.Highlight;
            BtnPrint.Cursor = Cursors.Hand;
            BtnPrint.FlatAppearance.BorderSize = 0;
            BtnPrint.FlatStyle = FlatStyle.Flat;
            BtnPrint.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnPrint.ForeColor = Color.White;
            BtnPrint.Location = new Point(267, 588);
            BtnPrint.Name = "BtnPrint";
            BtnPrint.Size = new Size(113, 34);
            BtnPrint.TabIndex = 31;
            BtnPrint.Text = "Print";
            BtnPrint.UseVisualStyleBackColor = false;
            BtnPrint.Click += BtnPrint_Click;
            // 
            // TxtCustomer
            // 
            TxtCustomer.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtCustomer.Location = new Point(355, 86);
            TxtCustomer.Name = "TxtCustomer";
            TxtCustomer.Size = new Size(253, 27);
            TxtCustomer.TabIndex = 32;
            TxtCustomer.TextAlign = HorizontalAlignment.Center;
            // 
            // LblCustomer2
            // 
            LblCustomer2.AutoSize = true;
            LblCustomer2.BackColor = Color.WhiteSmoke;
            LblCustomer2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            LblCustomer2.Location = new Point(355, 66);
            LblCustomer2.Name = "LblCustomer2";
            LblCustomer2.Size = new Size(64, 17);
            LblCustomer2.TabIndex = 33;
            LblCustomer2.Text = "Customer";
            // 
            // PrintDocReceipt
            // 
            PrintDocReceipt.PrintPage += PrintDocReceipt_PrintPage;
            // 
            // PrintPrevDiagReceipt
            // 
            PrintPrevDiagReceipt.AutoScrollMargin = new Size(0, 0);
            PrintPrevDiagReceipt.AutoScrollMinSize = new Size(0, 0);
            PrintPrevDiagReceipt.ClientSize = new Size(400, 300);
            PrintPrevDiagReceipt.Enabled = true;
            PrintPrevDiagReceipt.Icon = (Icon)resources.GetObject("PrintPrevDiagReceipt.Icon");
            PrintPrevDiagReceipt.Name = "printPrevDiagReceipt";
            PrintPrevDiagReceipt.Visible = false;
            // 
            // OrderForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(645, 644);
            Controls.Add(LblCustomer2);
            Controls.Add(TxtCustomer);
            Controls.Add(BtnUpdateItem);
            Controls.Add(TxtTotal);
            Controls.Add(label1);
            Controls.Add(BtnDeleteItem);
            Controls.Add(BtnAddItem);
            Controls.Add(DgvItems);
            Controls.Add(label6);
            Controls.Add(DtpDateCreated);
            Controls.Add(label4);
            Controls.Add(TxtSearchCustomer);
            Controls.Add(DgvCustomers);
            Controls.Add(LblCustomer1);
            Controls.Add(TxtCreatedBy);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(TxtOrderID);
            Controls.Add(LblTitle);
            Controls.Add(BtnClose);
            Controls.Add(BtnPrint);
            Controls.Add(BtnSave);
            FormBorderStyle = FormBorderStyle.None;
            Name = "OrderForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "OrderForm";
            Load += OrderForm_Load;
            ((System.ComponentModel.ISupportInitialize)DgvCustomers).EndInit();
            ((System.ComponentModel.ISupportInitialize)DgvItems).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnClose;
        private Label LblTitle;
        private TextBox TxtOrderID;
        private Label label2;
        private Label label3;
        private TextBox TxtCreatedBy;
        private Label LblCustomer1;
        private Button BtnSave;
        private DataGridView DgvCustomers;
        private TextBox TxtSearchCustomer;
        private Label label4;
        private DateTimePicker DtpDateCreated;
        private Label label6;
        private DataGridView DgvItems;
        private Button BtnAddItem;
        private Button BtnDeleteItem;
        private Label label1;
        private TextBox TxtTotal;
        private Button BtnUpdateItem;
        private Button BtnPrint;
        private TextBox TxtCustomer;
        private Label LblCustomer2;
        private System.Drawing.Printing.PrintDocument PrintDocReceipt;
        private PrintPreviewDialog PrintPrevDiagReceipt;
    }
}