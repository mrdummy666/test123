﻿using Mysqlx.Crud;
using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    public partial class UpdatePetForm : Form
    {
        public OwnersService ownersService;
        public PetsService petsService;
        public int toUpdateId;
        public int ownerId;
        public UpdatePetForm(int petId)
        {
            InitializeComponent();
            petsService = new();
            ownersService = new();
            toUpdateId = petId;
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            string petName = TxtPetName.Text.Trim();
            string animalType = TxtAnimalType.Text.Trim().ToUpper();
            string breed = TxtBreed.Text.Trim().ToUpper();
            int genderIndex = CboxGender.SelectedIndex;
            char gender = genderIndex == 0 ? 'M' : 'F';

            int selectedRowIndex = DgvOwners.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvOwners.Rows[selectedRowIndex];
            int ownerId = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);



            if (petName.Length == 0 || animalType.Length == 0 || breed.Length == 0)
            {
                MessageBox.Show("All fields are required.", "Update Pet", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Response createPetResponse = petsService.UpdatePet(toUpdateId, ownerId, petName, animalType, breed, gender);
                if (createPetResponse.Status)
                {
                    MessageBox.Show(createPetResponse.Message, "Update Pet", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MainForm.ToRefreshPetsTable = true;
                    Close();
                }
                else
                {
                    MessageBox.Show(createPetResponse.Message, "Update Pet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void UpdatePetForm_Load(object sender, EventArgs e)
        {
            DgvOwners.MultiSelect = false;

            Response getPetResponse = petsService.GetPet(toUpdateId);
            if (getPetResponse.Status)
            {
                Pet pet = getPetResponse.Payload!;
                TxtPetName.Text = pet.PetName;
                TxtAnimalType.Text = pet.AnimalType;
                TxtBreed.Text = pet.Breed;
                CboxGender.SelectedIndex = pet.Gender == 'M' ? 0 : 1;

                ownerId = pet.OwnerId;
                RefreshOwnersTable();
            }
            else
            {
                MessageBox.Show(getPetResponse.Message, "Update Pet", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshOwnersTable(string filter = "")
        {
            Response getOwnersResponse = ownersService.GetOwners();
            if (getOwnersResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Name", typeof(string)));

                List<Owner> owners = getOwnersResponse.Payload!;

                Owner selectedOwner = owners.FirstOrDefault(o => o.Id == ownerId)!;

                string fullName = selectedOwner.FirstName + " " + selectedOwner.LastName;
                DataRow dr = dt.NewRow();
                dr["Id"] = selectedOwner.Id;
                dr["Name"] = fullName;
                if (fullName.ToUpper().Contains(filter)) dt.Rows.Add(dr);

                foreach (Owner owner in owners)
                {
                    fullName = owner.FirstName + " " + owner.LastName;
                    if (ownerId != owner.Id && fullName.ToUpper().Contains(filter))
                    {
                        dr = dt.NewRow();
                        dr["Id"] = owner.Id;
                        dr["Name"] = fullName;
                        dt.Rows.Add(dr);
                    }
                }

                DgvOwners.DataSource = dt;
                DgvOwners.Columns["Id"].Visible = false;

                if (DgvOwners.Rows.Count > 0) DgvOwners.Rows[0].Selected = true;

                BtnSave.Enabled = DgvOwners.Rows.Count > 0;

            }
            else
            {
                MessageBox.Show(getOwnersResponse.Message, "Update Pet", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TxtSearchOwner_TextChanged(object sender, EventArgs e)
        {
            RefreshOwnersTable(TxtSearchOwner.Text.Trim().ToUpper());
        }
    }
}
