﻿namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    partial class PetActivityForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnClose = new Button();
            LblTitle = new Label();
            TxtPetName = new TextBox();
            label2 = new Label();
            label3 = new Label();
            TxtActivity = new TextBox();
            label4 = new Label();
            TxtOwner = new TextBox();
            BtnSave = new Button();
            SuspendLayout();
            // 
            // BtnClose
            // 
            BtnClose.BackColor = Color.Red;
            BtnClose.Cursor = Cursors.Hand;
            BtnClose.FlatAppearance.BorderSize = 0;
            BtnClose.FlatStyle = FlatStyle.Flat;
            BtnClose.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            BtnClose.ForeColor = Color.White;
            BtnClose.Location = new Point(281, 1);
            BtnClose.Name = "BtnClose";
            BtnClose.Size = new Size(42, 34);
            BtnClose.TabIndex = 6;
            BtnClose.Text = "X";
            BtnClose.UseVisualStyleBackColor = false;
            BtnClose.Click += BtnClose_Click;
            // 
            // LblTitle
            // 
            LblTitle.AutoSize = true;
            LblTitle.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            LblTitle.ForeColor = Color.Black;
            LblTitle.Location = new Point(4, 5);
            LblTitle.Name = "LblTitle";
            LblTitle.Size = new Size(106, 20);
            LblTitle.TabIndex = 8;
            LblTitle.Text = "PET ACTIVITY";
            // 
            // TxtPetName
            // 
            TxtPetName.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtPetName.Location = new Point(36, 86);
            TxtPetName.Name = "TxtPetName";
            TxtPetName.Size = new Size(253, 27);
            TxtPetName.TabIndex = 0;
            TxtPetName.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(36, 65);
            label2.Name = "label2";
            label2.Size = new Size(65, 17);
            label2.TabIndex = 10;
            label2.Text = "Pet Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(36, 183);
            label3.Name = "label3";
            label3.Size = new Size(48, 17);
            label3.TabIndex = 11;
            label3.Text = "Activity";
            // 
            // TxtActivity
            // 
            TxtActivity.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtActivity.Location = new Point(36, 204);
            TxtActivity.Multiline = true;
            TxtActivity.Name = "TxtActivity";
            TxtActivity.Size = new Size(253, 91);
            TxtActivity.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(36, 124);
            label4.Name = "label4";
            label4.Size = new Size(46, 17);
            label4.TabIndex = 13;
            label4.Text = "Owner";
            // 
            // TxtOwner
            // 
            TxtOwner.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtOwner.Location = new Point(36, 145);
            TxtOwner.Name = "TxtOwner";
            TxtOwner.Size = new Size(253, 27);
            TxtOwner.TabIndex = 4;
            TxtOwner.TextAlign = HorizontalAlignment.Center;
            // 
            // BtnSave
            // 
            BtnSave.BackColor = SystemColors.Highlight;
            BtnSave.Cursor = Cursors.Hand;
            BtnSave.FlatAppearance.BorderSize = 0;
            BtnSave.FlatStyle = FlatStyle.Flat;
            BtnSave.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnSave.ForeColor = Color.White;
            BtnSave.Location = new Point(105, 319);
            BtnSave.Name = "BtnSave";
            BtnSave.Size = new Size(113, 34);
            BtnSave.TabIndex = 5;
            BtnSave.Text = "Save";
            BtnSave.UseVisualStyleBackColor = false;
            BtnSave.Click += BtnSave_Click;
            // 
            // PetActivityForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(324, 375);
            Controls.Add(BtnSave);
            Controls.Add(TxtOwner);
            Controls.Add(label4);
            Controls.Add(TxtActivity);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(TxtPetName);
            Controls.Add(LblTitle);
            Controls.Add(BtnClose);
            FormBorderStyle = FormBorderStyle.None;
            Name = "PetActivityForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "PetActivityForm";
            Load += PetActivityForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnClose;
        private TextBox TxtPetName;
        private Label label2;
        private Label label3;
        private TextBox TxtActivity;
        private Label label4;
        private TextBox TxtOwner;
        private Button BtnSave;
        private Label LblTitle;
    }
}