﻿namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    partial class AppointmentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            BtnClose = new Button();
            LblTitle = new Label();
            TxtTitle = new TextBox();
            label2 = new Label();
            label5 = new Label();
            BtnSave = new Button();
            DgvOwners = new DataGridView();
            TxtSearchCustomer = new TextBox();
            TxtDetails = new TextBox();
            label3 = new Label();
            DtpSchedule = new DateTimePicker();
            label4 = new Label();
            CboxStatus = new ComboBox();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)DgvOwners).BeginInit();
            SuspendLayout();
            // 
            // BtnClose
            // 
            BtnClose.BackColor = Color.Red;
            BtnClose.Cursor = Cursors.Hand;
            BtnClose.FlatAppearance.BorderSize = 0;
            BtnClose.FlatStyle = FlatStyle.Flat;
            BtnClose.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            BtnClose.ForeColor = Color.White;
            BtnClose.Location = new Point(602, 1);
            BtnClose.Name = "BtnClose";
            BtnClose.Size = new Size(42, 34);
            BtnClose.TabIndex = 6;
            BtnClose.Text = "X";
            BtnClose.UseVisualStyleBackColor = false;
            BtnClose.Click += BtnClose_Click;
            // 
            // LblTitle
            // 
            LblTitle.AutoSize = true;
            LblTitle.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            LblTitle.ForeColor = Color.Black;
            LblTitle.Location = new Point(4, 5);
            LblTitle.Name = "LblTitle";
            LblTitle.Size = new Size(118, 20);
            LblTitle.TabIndex = 8;
            LblTitle.Text = "APPOINTMENT";
            // 
            // TxtTitle
            // 
            TxtTitle.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtTitle.Location = new Point(36, 86);
            TxtTitle.Name = "TxtTitle";
            TxtTitle.Size = new Size(253, 27);
            TxtTitle.TabIndex = 0;
            TxtTitle.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(36, 65);
            label2.Name = "label2";
            label2.Size = new Size(32, 17);
            label2.TabIndex = 10;
            label2.Text = "Title";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(316, 65);
            label5.Name = "label5";
            label5.Size = new Size(64, 17);
            label5.TabIndex = 15;
            label5.Text = "Customer";
            // 
            // BtnSave
            // 
            BtnSave.BackColor = SystemColors.Highlight;
            BtnSave.Cursor = Cursors.Hand;
            BtnSave.FlatAppearance.BorderSize = 0;
            BtnSave.FlatStyle = FlatStyle.Flat;
            BtnSave.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnSave.ForeColor = Color.White;
            BtnSave.Location = new Point(263, 382);
            BtnSave.Name = "BtnSave";
            BtnSave.Size = new Size(113, 34);
            BtnSave.TabIndex = 5;
            BtnSave.Text = "Save";
            BtnSave.UseVisualStyleBackColor = false;
            BtnSave.Click += BtnSave_Click;
            // 
            // DgvOwners
            // 
            DgvOwners.AllowUserToAddRows = false;
            DgvOwners.AllowUserToDeleteRows = false;
            DgvOwners.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvOwners.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.False;
            DgvOwners.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            DgvOwners.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvOwners.Location = new Point(316, 86);
            DgvOwners.Name = "DgvOwners";
            DgvOwners.ReadOnly = true;
            DgvOwners.RowTemplate.Height = 25;
            DgvOwners.Size = new Size(292, 260);
            DgvOwners.TabIndex = 19;
            // 
            // TxtSearchCustomer
            // 
            TxtSearchCustomer.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            TxtSearchCustomer.Location = new Point(419, 55);
            TxtSearchCustomer.Name = "TxtSearchCustomer";
            TxtSearchCustomer.PlaceholderText = "Search Customer";
            TxtSearchCustomer.Size = new Size(189, 25);
            TxtSearchCustomer.TabIndex = 21;
            TxtSearchCustomer.TextChanged += TxtSearchOwner_TextChanged;
            // 
            // TxtDetails
            // 
            TxtDetails.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtDetails.Location = new Point(36, 146);
            TxtDetails.Multiline = true;
            TxtDetails.Name = "TxtDetails";
            TxtDetails.Size = new Size(253, 82);
            TxtDetails.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(36, 127);
            label3.Name = "label3";
            label3.Size = new Size(47, 17);
            label3.TabIndex = 11;
            label3.Text = "Details";
            // 
            // DtpSchedule
            // 
            DtpSchedule.CalendarFont = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            DtpSchedule.CustomFormat = "MMMM dd, yyyy hh:mm tt";
            DtpSchedule.Format = DateTimePickerFormat.Custom;
            DtpSchedule.Location = new Point(36, 263);
            DtpSchedule.Name = "DtpSchedule";
            DtpSchedule.Size = new Size(253, 23);
            DtpSchedule.TabIndex = 25;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.WhiteSmoke;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(36, 243);
            label4.Name = "label4";
            label4.Size = new Size(60, 17);
            label4.TabIndex = 24;
            label4.Text = "Schedule";
            // 
            // CboxStatus
            // 
            CboxStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            CboxStatus.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CboxStatus.FormattingEnabled = true;
            CboxStatus.Location = new Point(36, 317);
            CboxStatus.Name = "CboxStatus";
            CboxStatus.Size = new Size(253, 29);
            CboxStatus.TabIndex = 26;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(36, 298);
            label6.Name = "label6";
            label6.Size = new Size(43, 17);
            label6.TabIndex = 27;
            label6.Text = "Status";
            // 
            // AppointmentForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(645, 438);
            Controls.Add(CboxStatus);
            Controls.Add(label6);
            Controls.Add(DtpSchedule);
            Controls.Add(label4);
            Controls.Add(TxtSearchCustomer);
            Controls.Add(DgvOwners);
            Controls.Add(BtnSave);
            Controls.Add(label5);
            Controls.Add(TxtDetails);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(TxtTitle);
            Controls.Add(LblTitle);
            Controls.Add(BtnClose);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AppointmentForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "NewPetForm";
            Load += NewPetForm_Load;
            ((System.ComponentModel.ISupportInitialize)DgvOwners).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnClose;
        private TextBox TxtTitle;
        private Label label2;
        private Label label5;
        private Button BtnSave;
        private DataGridView DgvOwners;
        private TextBox TxtSearchCustomer;
        private TextBox TxtDetails;
        private Label label3;
        private DateTimePicker DtpSchedule;
        private Label label4;
        private Label LblTitle;
        private ComboBox CboxStatus;
        private Label label6;
    }
}