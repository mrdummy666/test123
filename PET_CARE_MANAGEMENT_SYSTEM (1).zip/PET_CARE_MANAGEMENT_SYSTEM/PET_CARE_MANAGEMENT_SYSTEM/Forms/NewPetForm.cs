﻿using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    public partial class NewPetForm : Form
    {
        public OwnersService ownersService;
        public PetsService petsService;
        public NewPetForm()
        {
            InitializeComponent();
            petsService = new();
            ownersService = new();
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            string petName = TxtPetName.Text.Trim();
            string animalType = TxtAnimalType.Text.Trim().ToUpper();
            string breed = TxtBreed.Text.Trim().ToUpper();
            int genderIndex = CboxGender.SelectedIndex;
            char gender = genderIndex == 0 ? 'M' : 'F';

            int selectedRowIndex = DgvOwners.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvOwners.Rows[selectedRowIndex];
            int ownerId = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);



            if (petName.Length == 0 || animalType.Length == 0 || breed.Length == 0)
            {
                MessageBox.Show("All fields are required.", "New Pet", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Response createPetResponse = petsService.CreatePet(ownerId, petName, animalType, breed, gender);
                if (createPetResponse.Status)
                {
                    MessageBox.Show(createPetResponse.Message, "New Pet", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MainForm.ToRefreshPetsTable = true;
                    Close();
                }
                else
                {
                    MessageBox.Show(createPetResponse.Message, "New Pet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void NewPetForm_Load(object sender, EventArgs e)
        {
            DgvOwners.MultiSelect = false;
            CboxGender.SelectedIndex = 0;
            RefreshOwnersTable();
            BtnSave.Enabled = DgvOwners.Rows.Count > 0;
            if (DgvOwners.Rows.Count > 0) DgvOwners.Rows[0].Selected = true;
        }

        private void RefreshOwnersTable(string filter = "")
        {
            Response getOwnersResponse = ownersService.GetOwners();

            if (getOwnersResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Name", typeof(string)));

                List<Owner> owners = getOwnersResponse.Payload!;

                foreach (Owner owner in owners)
                {
                    string fullName = owner.FirstName + " " + owner.LastName;

                    if (fullName.ToUpper().Contains(filter))
                    {
                        DataRow dr = dt.NewRow();
                        dr["Id"] = owner.Id;
                        dr["Name"] = fullName;
                        dt.Rows.Add(dr);
                    }
                }

                DgvOwners.DataSource = dt;
                DgvOwners.Columns["Id"].Visible = false;

                BtnSave.Enabled = DgvOwners.Rows.Count > 0;
            }
            else
            {
                MessageBox.Show(getOwnersResponse.Message, "New Pet", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void TxtSearchOwner_TextChanged(object sender, EventArgs e)
        {
            RefreshOwnersTable(TxtSearchOwner.Text.Trim().ToUpper());
        }
    }
}
