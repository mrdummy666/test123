﻿using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    public partial class ServiceForm : Form
    {
        public ServicesService servicesService;
        private readonly int serviceId;
        public ServiceForm(int serviceId = 0)
        {
            InitializeComponent();
            servicesService = new();
            this.serviceId = serviceId;
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            string name = TxtName.Text.Trim();
            string description = TxtDescription.Text.Trim();
            decimal price = Convert.ToDecimal(TxtPrice.Text.Trim());

            if (name.Length == 0 || description.Length == 0)
            {
                MessageBox.Show("All fields are required.", string.Format("{0} Service", serviceId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (price > 0)
                {
                    Response checkServiceName = servicesService.CheckServiceName(name, serviceId);

                    if (checkServiceName.Status)
                    {
                        Response actionServiceResponse = serviceId == 0 ? servicesService.CreateService(name, description, price) : servicesService.UpdateService(serviceId, name, description, price);
                        if (actionServiceResponse.Status)
                        {
                            MessageBox.Show(actionServiceResponse.Message, string.Format("{0} Service", serviceId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Information);
                            MainForm.ToRefreshServicesTable = true;
                            Close();
                        }
                        else
                        {
                            MessageBox.Show(actionServiceResponse.Message, string.Format("{0} Service", serviceId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show(checkServiceName.Message, string.Format("{0} Service", serviceId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Price must be greater than 0.00", string.Format("{0} Service", serviceId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void ServiceForm_Load(object sender, EventArgs e)
        {
            if (serviceId == 0)
            {
                // CREATE
                LblTitle.Text = "NEW SERVICE";
                TxtPrice.Text = "0.00";
            }
            else
            {
                //UPDATE
                LblTitle.Text = "UPDATE SERVICE";
                Response getServiceResponse = servicesService.GetService(serviceId);
                if (getServiceResponse.Status)
                {
                    Service service = getServiceResponse.Payload!;
                    TxtName.Text = service.Name;
                    TxtDescription.Text = service.Description;
                    TxtPrice.Text = service.Price.ToString();
                }
                else
                {
                    MessageBox.Show(getServiceResponse.Message, "Update Service", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void TxtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            // allows 0-9, backspace, and decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }

            // checks to make sure only 1 decimal is allowed
            if (e.KeyChar == 46)
            {
                if (((TextBox)sender).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }
    }
}
