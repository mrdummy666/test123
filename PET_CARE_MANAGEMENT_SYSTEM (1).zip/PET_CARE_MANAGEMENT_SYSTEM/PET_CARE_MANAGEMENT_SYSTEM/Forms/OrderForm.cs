﻿using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    public partial class OrderForm : Form
    {
        public OrdersService ordersService;
        public OwnersService ownersService;
        public ProductsService productsService;
        public ServicesService servicesService;
        public AuthService authService;

        private readonly User currentUser;
        private int toUpdateId;
        private readonly string action;
        private int customerId = 0;
        public static List<OrderItem> orderItems = new();

        public OrderForm(User user, int orderId, string action)
        {
            InitializeComponent();
            ordersService = new();
            ownersService = new();
            productsService = new();
            servicesService = new();
            authService = new();

            currentUser = user;
            toUpdateId = orderId;
            this.action = action;
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
            orderItems.Clear();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            BtnSave.Enabled = false;
            if (action == "CREATE")
            {
                //CREATE
                int selectedRowIndex = DgvCustomers.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = DgvCustomers.Rows[selectedRowIndex];
                int customerId = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);
                string customerName = Convert.ToString(selectedRow.Cells["Name"].Value)!;

                decimal total = Convert.ToDecimal(TxtTotal.Text.Replace(",", ""));
                string createdAt = DtpDateCreated.Value.ToString("yyyy-MM-dd H:mm:ss"); //DateTime.Now.ToString("yyyy-MM-dd H:mm:ss");
                string updatedAt = createdAt;

                foreach (OrderItem orderItem in orderItems)
                {
                    if (orderItem.Status == 1 && orderItem.ItemType == 'P')
                    {
                        Product product = productsService.GetProduct(orderItem.ItemId).Payload!;

                        if (product.Quantity < orderItem.Quantity)
                        {
                            MessageBox.Show(string.Format("Insufficient Quantity for this Product: {0}!", product.Name), "New Order Item", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                }

                Response createOrderResponse = ordersService.CreateOrder(customerId, currentUser.Id, currentUser.Role, total, createdAt, updatedAt);
                if (createOrderResponse.Status)
                {
                    toUpdateId = createOrderResponse.Payload;
                    foreach (OrderItem orderItem in orderItems)
                    {
                        if (orderItem.Status == 1)
                        {
                            Response createOrderItemResponse = ordersService.CreateOrderItem(toUpdateId, orderItem.ItemId, orderItem.ItemType, orderItem.Quantity, orderItem.Price, orderItem.Total, createdAt, updatedAt);
                            if (!createOrderItemResponse.Status)
                            {
                                MessageBox.Show(createOrderItemResponse.Message, "New Order Item", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                if (orderItem.ItemType == 'P')
                                {
                                    // UPDATE THE PRODUCTS QUANTITY
                                    Product product = productsService.GetProduct(orderItem.ItemId).Payload!;
                                    int newQty = product.Quantity - orderItem.Quantity;
                                    Response updateProductResponse = productsService.UpdateProduct(orderItem.ItemId, product.CategoryId, product.Name, product.Description, newQty, product.Price, product.ExpiredAt?.ToString("yyyy-MM-dd H:mm:ss"));

                                    if (!updateProductResponse.Status)
                                    {
                                        MessageBox.Show(updateProductResponse.Message, "Update Product Quantity", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }
                        }
                    }

                    MainForm.ToRefreshOrdersTable = true;

                    BtnSave.Visible = false;
                    TxtSearchCustomer.Visible = false;
                    LblCustomer1.Visible = false;
                    DgvCustomers.Visible = false;
                    BtnAddItem.Visible = false;
                    BtnUpdateItem.Visible = false;
                    BtnDeleteItem.Visible = false;

                    TxtCustomer.Visible = true;
                    LblCustomer2.Visible = true;
                    TxtCustomer.Text = customerName;
                    DtpDateCreated.Enabled = false;
                    DgvItems.Enabled = false;

                    BtnPrint.Visible = true;

                    MessageBox.Show(createOrderResponse.Message, "New Order", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Close();
                    //orderItems.Clear();
                }
                else
                {
                    MessageBox.Show(createOrderResponse.Message, "New Order", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                // UPDATE
                int selectedRowIndex = DgvCustomers.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = DgvCustomers.Rows[selectedRowIndex];
                int customerId = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);
                string customerName = Convert.ToString(selectedRow.Cells["Name"].Value)!;

                decimal total = Convert.ToDecimal(TxtTotal.Text.Replace(",", ""));
                string createdAt = DtpDateCreated.Value.ToString("yyyy-MM-dd H:mm:ss"); //DateTime.Now.ToString("yyyy-MM-dd H:mm:ss");
                string updatedAt = createdAt;

                foreach (OrderItem orderItem in orderItems)
                {
                    if (orderItem.Status == 1)
                    {
                        Product product = productsService.GetProduct(orderItem.ItemId).Payload!;

                        if (product.Quantity < orderItem.Quantity)
                        {
                            MessageBox.Show(string.Format("Insufficient Quantity for this Product: {0}!", product.Name), "New Order Item", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                }

                Response updateOrderResponse = ordersService.UpdateOrder(toUpdateId, customerId, total, updatedAt);
                if (updateOrderResponse.Status)
                {
                    foreach (OrderItem orderItem in orderItems)
                    {
                        if (orderItem.Id > 0)
                        {
                            // OLD
                            Response getOrderItemResponse = ordersService.GetOrderItem(orderItem.Id);
                            if (getOrderItemResponse.Status)
                            {
                                OrderItem oldOrderItem = getOrderItemResponse.Payload!;
                                int oldValue = oldOrderItem.Quantity;

                                if (orderItem.Status == 1)
                                {
                                    int toDeduct = orderItem.Quantity - oldValue;


                                    // TO UPDATE
                                    Response updateOrderItemResponse = ordersService.UpdateOrderItem(toUpdateId, orderItem.Quantity, orderItem.Price, orderItem.Total, updatedAt);
                                    if (!updateOrderItemResponse.Status)
                                    {
                                        MessageBox.Show(updateOrderItemResponse.Message, "Update Order Item", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }

                                    // UPDATE THE PRODUCTS QUANTITY
                                    Product product = productsService.GetProduct(orderItem.ItemId).Payload!;

                                    int newQty = product.Quantity - toDeduct;
                                    Response updateProductResponse = productsService.UpdateProduct(orderItem.ItemId, product.CategoryId, product.Name, product.Description, newQty, product.Price, product.ExpiredAt?.ToString("yyyy-MM-dd H:mm:ss"));

                                    if (!updateProductResponse.Status)
                                    {
                                        MessageBox.Show(updateProductResponse.Message, "Update Product Quantity", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                                else
                                {
                                    // TO DELETE
                                    Response deleteOrderItemResponse = ordersService.DeleteOrderItem(orderItem.Id);
                                    if (!deleteOrderItemResponse.Status)
                                    {
                                        MessageBox.Show(deleteOrderItemResponse.Message, "Delete Order Item", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }

                                    // UPDATE THE PRODUCTS QUANTITY
                                    Product product = productsService.GetProduct(orderItem.ItemId).Payload!;

                                    int newQty = product.Quantity + orderItem.Quantity;
                                    Response updateProductResponse = productsService.UpdateProduct(orderItem.ItemId, product.CategoryId, product.Name, product.Description, newQty, product.Price, product.ExpiredAt?.ToString("yyyy-MM-dd H:mm:ss"));

                                    if (!updateProductResponse.Status)
                                    {
                                        MessageBox.Show(updateProductResponse.Message, "Update Product Quantity", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show(getOrderItemResponse.Message, "Get Order Item", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                        }
                        else
                        {
                            if (orderItem.Status == 1)
                            {
                                // TO UPDATE
                                Response createOrderItemResponse = ordersService.CreateOrderItem(toUpdateId, orderItem.ItemId, orderItem.ItemType, orderItem.Quantity, orderItem.Price, orderItem.Total, createdAt, updatedAt);
                                if (!createOrderItemResponse.Status)
                                {
                                    MessageBox.Show(createOrderItemResponse.Message, "New Order Item", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                                else
                                {
                                    // UPDATE THE PRODUCTS QUANTITY
                                    Product product = productsService.GetProduct(orderItem.ItemId).Payload!;
                                    int newQty = product.Quantity - orderItem.Quantity;
                                    Response updateProductResponse = productsService.UpdateProduct(orderItem.ItemId, product.CategoryId, product.Name, product.Description, newQty, product.Price, product.ExpiredAt?.ToString("yyyy-MM-dd H:mm:ss"));

                                    if (!updateProductResponse.Status)
                                    {
                                        MessageBox.Show(updateProductResponse.Message, "Update Product Quantity", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }
                        }

                    }

                    MainForm.ToRefreshOrdersTable = true;

                    BtnSave.Visible = false;
                    TxtSearchCustomer.Visible = false;
                    LblCustomer1.Visible = false;
                    DgvCustomers.Visible = false;
                    BtnAddItem.Visible = false;
                    BtnUpdateItem.Visible = false;
                    BtnDeleteItem.Visible = false;

                    TxtCustomer.Visible = true;
                    LblCustomer2.Visible = true;
                    TxtCustomer.Text = customerName;

                    DtpDateCreated.Enabled = false;
                    DgvItems.Enabled = false;

                    BtnPrint.Visible = true;


                    MessageBox.Show(updateOrderResponse.Message, "Update Order", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Close();
                    //orderItems.Clear();
                }
                else
                {
                    MessageBox.Show(updateOrderResponse.Message, "Update Order", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            BtnSave.Enabled = true;
        }

        private void OrderForm_Load(object sender, EventArgs e)
        {
            DgvCustomers.MultiSelect = false;
            DgvItems.MultiSelect = false;

            TxtCustomer.Visible = false;
            LblCustomer2.Visible = false;

            BtnPrint.Visible = false;
            TxtCustomer.ReadOnly = true;


            if (action == "CREATE")
            {
                // CREATE
                LblTitle.Text = "NEW ORDER";

                Response getNextIdResponse = ordersService.GetNextId();
                if (getNextIdResponse.Status)
                {
                    int nextId = (int)getNextIdResponse.Payload!;
                    TxtOrderID.Text = nextId.ToString();
                }
                else
                {
                    MessageBox.Show(getNextIdResponse.Message, "New Order", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                TxtCreatedBy.Text = currentUser.FirstName + " " + currentUser.LastName;

                if (currentUser.Role == 'C')
                {
                    DtpDateCreated.Enabled = false;
                }

                TxtTotal.Text = "0.00";
                BtnDeleteItem.Enabled = false;
                BtnUpdateItem.Enabled = false;

                RefreshCustomersTable();
                RefreshItemsTable();


                if (DgvCustomers.Rows.Count > 0) DgvCustomers.Rows[0].Selected = true;

            }
            else if (action == "UPDATE")
            {
                // UPDATE
                LblTitle.Text = "UPDATE ORDER";

                Response getOrderResponse = ordersService.GetOrder(toUpdateId);

                if (getOrderResponse.Status)
                {
                    Order order = getOrderResponse.Payload!;

                    LblCustomer1.Visible = true;
                    DgvCustomers.Visible = true;
                    TxtCustomer.Visible = false;
                    LblCustomer2.Visible = false;
                    TxtSearchCustomer.Visible = true;
                    BtnAddItem.Visible = true;
                    BtnUpdateItem.Visible = true;
                    BtnDeleteItem.Visible = true;
                    BtnSave.Visible = true;
                    //BtnPrint.Visible = true;
                    DtpDateCreated.Enabled = true;

                    TxtOrderID.Text = order.Id.ToString();

                    customerId = order.CustomerId;
                    //Response getCustomerResponse = ownersService.GetOwner(customerId);
                    //Owner? customer = getCustomerResponse.Payload;
                    //string customerName = getCustomerResponse.Status ? string.Format("{0} {1}", customer!.FirstName, customer!.LastName) : "";

                    int creatorId = order.CreatorId;
                    Response getCreatorResponse = authService.GetUser(creatorId);
                    User? creator = getCreatorResponse.Payload;
                    string creatorName = getCreatorResponse.Status ? string.Format("{0} {1}", creator!.FirstName, creator!.LastName) : "";



                    //TxtCustomer.Text = customerName;
                    TxtCreatedBy.Text = creatorName;
                    DtpDateCreated.Value = order.CreatedAt;
                    TxtTotal.Text = $"{order.Total:n}";

                    RefreshCustomersTable();

                    if (DgvCustomers.Rows.Count > 0) DgvCustomers.Rows[0].Selected = true;

                    Response getOrderItemsResponse = ordersService.GetOrderItems(orderId: toUpdateId);

                    if (getOrderItemsResponse.Status)
                    {
                        orderItems = getOrderItemsResponse.Payload!;

                        RefreshItemsTable(orderItems);

                        DgvItems.Rows[0].Selected = true;
                    }
                    else
                    {
                        MessageBox.Show(getOrderItemsResponse.Message, "Update Order", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show(getOrderResponse.Message, "Update Order", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                // VIEW
                LblCustomer1.Visible = false;
                DgvCustomers.Visible = false;
                TxtCustomer.Visible = true;
                LblCustomer2.Visible = true;
                TxtSearchCustomer.Visible = false;
                BtnAddItem.Visible = false;
                BtnUpdateItem.Visible = false;
                BtnDeleteItem.Visible = false;
                BtnSave.Visible = false;
                DtpDateCreated.Enabled = false;
                DgvItems.Enabled = false;

                BtnPrint.Visible = true;


                TxtOrderID.Text = toUpdateId.ToString();

                Response getOrderResponse = ordersService.GetOrder(id: toUpdateId);

                if (getOrderResponse.Status)
                {
                    Order order = getOrderResponse.Payload!;

                    int customerId = order.CustomerId;
                    Response getCustomerResponse = ownersService.GetOwner(customerId);
                    Owner? customer = getCustomerResponse.Payload;
                    string customerName = getCustomerResponse.Status ? string.Format("{0} {1}", customer!.FirstName, customer!.LastName) : "";

                    int creatorId = order.CreatorId;
                    Response getCreatorResponse = authService.GetUser(creatorId);
                    User? creator = getCreatorResponse.Payload;
                    string creatorName = getCreatorResponse.Status ? string.Format("{0} {1}", creator!.FirstName, creator!.LastName) : "";

                    TxtCustomer.Text = customerName;
                    TxtCreatedBy.Text = creatorName;
                    DtpDateCreated.Value = order.CreatedAt;
                    TxtTotal.Text = $"{order.Total:n}";

                    Response getOrderItemsResponse = ordersService.GetOrderItems(orderId: toUpdateId);

                    if (getOrderItemsResponse.Status)
                    {
                        orderItems = getOrderItemsResponse.Payload!;

                        RefreshItemsTable(orderItems);
                    }
                    else
                    {
                        MessageBox.Show(getOrderItemsResponse.Message, "View Order", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                else
                {
                    MessageBox.Show(getOrderResponse.Message, "View Order", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            TxtOrderID.ReadOnly = true;
            TxtCreatedBy.ReadOnly = true;
            TxtTotal.ReadOnly = true;


            BtnSave.Enabled = DgvCustomers.Rows.Count > 0 && DgvItems.Rows.Count > 0;
        }

        private void RefreshCustomersTable(string filter = "")
        {
            Response getOwnersResponse = ownersService.GetOwners();

            if (getOwnersResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Name", typeof(string)));

                List<Owner> owners = getOwnersResponse.Payload!;

                //foreach (Owner owner in owners)
                //{
                //    string fullName = owner.FirstName + " " + owner.LastName;

                //    if (fullName.ToUpper().Contains(filter))
                //    {
                //        DataRow dr = dt.NewRow();
                //        dr["Id"] = owner.Id;
                //        dr["Name"] = fullName;
                //        dt.Rows.Add(dr);
                //    }
                //}
                if (toUpdateId != 0)
                {

                    Owner selectedOwner = owners.FirstOrDefault(o => o.Id == customerId)!;

                    string fullName = selectedOwner.FirstName + " " + selectedOwner.LastName;
                    DataRow dr = dt.NewRow();
                    dr["Id"] = selectedOwner.Id;
                    dr["Name"] = fullName;
                    if (fullName.ToUpper().Contains(filter)) dt.Rows.Add(dr);

                    foreach (Owner owner in owners)
                    {
                        fullName = owner.FirstName + " " + owner.LastName;
                        if (customerId != owner.Id && fullName.ToUpper().Contains(filter))
                        {
                            dr = dt.NewRow();
                            dr["Id"] = owner.Id;
                            dr["Name"] = fullName;
                            dt.Rows.Add(dr);
                        }
                    }
                }
                else
                {
                    foreach (Owner owner in owners)
                    {
                        string fullName = owner.FirstName + " " + owner.LastName;

                        if (fullName.ToUpper().Contains(filter))
                        {
                            DataRow dr = dt.NewRow();
                            dr["Id"] = owner.Id;
                            dr["Name"] = fullName;
                            dt.Rows.Add(dr);
                        }
                    }
                }

                DgvCustomers.DataSource = dt;
                DgvCustomers.Columns["Id"].Visible = false;

                BtnSave.Enabled = DgvCustomers.Rows.Count > 0;
            }
            else
            {
                MessageBox.Show(getOwnersResponse.Message, string.Format("{0} Order", action == "CREATE" ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void RefreshItemsTable(List<OrderItem>? orderItems = null)
        {

            DataTable dt = new();
            dt.Columns.Add(new DataColumn("Id", typeof(int)));
            dt.Columns.Add(new DataColumn("ItemId", typeof(int)));
            dt.Columns.Add(new DataColumn("Item", typeof(string)));
            dt.Columns.Add(new DataColumn("Quantity", typeof(string)));
            dt.Columns.Add(new DataColumn("Price", typeof(string)));
            dt.Columns.Add(new DataColumn("Amount", typeof(string)));
            dt.Columns.Add(new DataColumn("ItemType", typeof(string)));

            if (orderItems != null)
            {
                foreach (OrderItem item in orderItems)
                {

                    if (item.Status == 1)
                    {
                        string itemName;
                        if (item.ItemType == 'P')
                        {
                            Response getProductResponse = productsService.GetProduct(item.ItemId);
                            Product? product = getProductResponse.Payload != null ? getProductResponse!.Payload : null;
                            itemName = product != null ? product.Name : "";
                        }
                        else
                        {
                            Response getServiceResponse = servicesService.GetService(item.ItemId);
                            Service? service = getServiceResponse.Payload != null ? getServiceResponse!.Payload : null;
                            itemName = service != null ? service.Name : "";
                        }

                        DataRow dr = dt.NewRow();
                        dr["Id"] = item.Id;
                        dr["ItemId"] = item.ItemId;
                        dr["ItemType"] = item.ItemType == 'P' ? "Product" : "Service";
                        dr["Item"] = itemName;
                        dr["Quantity"] = $"{item.Quantity:n0}";
                        dr["Price"] = $"{item.Price:n}";
                        dr["Amount"] = $"{item.Total:n}";
                        dt.Rows.Add(dr);
                    }
                }
            }

            DgvItems.DataSource = dt;
            DgvItems.Columns["Id"].Visible = false;
            DgvItems.Columns["ItemId"].Visible = false;
        }

        private void TxtSearchOwner_TextChanged(object sender, EventArgs e)
        {
            RefreshCustomersTable(TxtSearchCustomer.Text.Trim().ToUpper());
        }

        private void BtnAddItem_Click(object sender, EventArgs e)
        {
            Hide();
            ItemForm itemForm = new(0, 0, 'N');
            itemForm.ShowDialog();
            Show();
            RefreshItemsTable(orderItems);

            TxtTotal.Text = $"{orderItems.Sum(u => u.Total):n}";

            BtnDeleteItem.Enabled = orderItems.Where(oi => oi.Status == 1).ToList().Count > 0;
            BtnUpdateItem.Enabled = orderItems.Where(oi => oi.Status == 1).ToList().Count > 0;
            BtnSave.Enabled = orderItems.Where(oi => oi.Status == 1).ToList().Count > 0 && DgvCustomers.Rows.Count > 0;

        }

        private void BtnDeleteItem_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvItems.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvItems.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            int index = orderItems.FindIndex(oi => oi.Id == id)!;
            orderItems[index].Status = 0;

            RefreshItemsTable(orderItems);

            TxtTotal.Text = $"{orderItems.Where(oi => oi.Status == 1).Sum(u => u.Total):n}";

            BtnDeleteItem.Enabled = orderItems.Where(oi => oi.Status == 1).ToList().Count > 0;
            BtnUpdateItem.Enabled = orderItems.Where(oi => oi.Status == 1).ToList().Count > 0;
            BtnSave.Enabled = orderItems.Where(oi => oi.Status == 1).ToList().Count > 0 && DgvCustomers.Rows.Count > 0;

        }

        private void BtnUpdateItem_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvItems.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvItems.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["ItemId"].Value)!);
            char itemType = Convert.ToString(selectedRow.Cells["ItemType"].Value)!.ToCharArray()[0];

            Hide();
            ItemForm itemForm = new(toUpdateId, id, itemType);
            itemForm.ShowDialog();
            Show();
            RefreshItemsTable(orderItems);

            TxtTotal.Text = $"{orderItems.Where(oi => oi.Status == 1).Sum(u => u.Total):n}";

            BtnDeleteItem.Enabled = orderItems.Where(oi => oi.Status == 1).ToList().Count > 0;
            BtnUpdateItem.Enabled = orderItems.Where(oi => oi.Status == 1).ToList().Count > 0;
            BtnSave.Enabled = orderItems.Where(oi => oi.Status == 1).ToList().Count > 0 && DgvCustomers.Rows.Count > 0;
        }

        private void PrintDocReceipt_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            Response getOrderResponse = ordersService.GetOrder(id: toUpdateId);
            if (getOrderResponse.Status)
            {
                Order order = getOrderResponse.Payload!;

                int customerId = order.CustomerId;
                Response getCustomerResponse = ownersService.GetOwner(customerId);
                Owner? customer = getCustomerResponse.Payload;
                string customerName = getCustomerResponse.Status ? string.Format("{0} {1}", customer!.FirstName, customer!.LastName) : "";

                e.Graphics.DrawString("PETSTACULAR VETERINARY CLINIC", new Font("Arial", 5, FontStyle.Bold), Brushes.Black, new Point(12, 10));
                e.Graphics.DrawString("Date: ", new Font("Helvetica", 2), Brushes.Black, new Point(100, 30));
                e.Graphics.DrawString(/*string.Format("_____{0}_____", order.CreatedAt.ToString("MMMM dd, yyyy"))*/"___September 31, 2023___", new Font("Helvetica", 2, FontStyle.Underline), Brushes.Black, new Point(110, 30));
                e.Graphics.DrawString("Customer: ", new Font("Helvetica", 2), Brushes.Black, new Point(10, 40));
                e.Graphics.DrawString(string.Format("_____{0}_____", customerName), new Font("Helvetica", 2, FontStyle.Underline), Brushes.Black, new Point(26, 40));
                e.Graphics.DrawString("CHARGE SLIP", new Font("Arial", 3, FontStyle.Bold), Brushes.Black, new Point(60, 50));


                Response getOrderItemsResponse = ordersService.GetOrderItems(orderId: toUpdateId);
                if (getOrderItemsResponse.Status)
                {
                    orderItems = getOrderItemsResponse.Payload!;


                    e.Graphics.DrawString("ITEM", new Font("Helvetica", 2), Brushes.Black, new Point(10, 70));
                    e.Graphics.DrawString("TYPE", new Font("Helvetica", 2), Brushes.Black, new Point(70, 70));
                    e.Graphics.DrawString("PRICE", new Font("Helvetica", 2), Brushes.Black, new Point(85, 70));
                    e.Graphics.DrawString("QTY", new Font("Helvetica", 2), Brushes.Black, new Point(110, 70));
                    e.Graphics.DrawString("AMOUNT ", new Font("Helvetica", 2), Brushes.Black, new Point(130, 70));

                    int init = 75;
                    foreach (var orderItem in orderItems)
                    {
                        string itemName;
                        if (orderItem.ItemType == 'P')
                        {
                            Response getProductResponse = productsService.GetProduct(orderItem.ItemId);
                            Product? product = getProductResponse.Payload != null ? getProductResponse!.Payload : null;
                            itemName = product != null ? product.Name : "";
                        }
                        else
                        {
                            Response getServiceResponse = servicesService.GetService(orderItem.ItemId);
                            Service? service = getServiceResponse.Payload != null ? getServiceResponse!.Payload : null;
                            itemName = service != null ? service.Name : "";
                        }

                        if (itemName.Length > 30)
                        {
                            itemName = string.Concat(itemName.AsSpan(30), "...");
                        }
                        e.Graphics.DrawString(itemName, new Font("Arial", 2), Brushes.Black, new Point(10, init));
                        e.Graphics.DrawString(orderItem.ItemType == 'P' ? "Product" : "Service", new Font("Arial", 2), Brushes.Black, new Point(70, init));
                        e.Graphics.DrawString($"{orderItem.Price:n}", new Font("Arial", 2), Brushes.Black, new Point(85, init));
                        e.Graphics.DrawString($"{orderItem.Quantity:n0}", new Font("Arial", 2), Brushes.Black, new Point(110, init));
                        e.Graphics.DrawString($"{orderItem.Total:n}", new Font("Arial", 2), Brushes.Black, new Point(130, init));
                        init += 5;
                    }
                    e.Graphics.DrawString("TOTAL: ", new Font("Helvetica", 2), Brushes.Black, new Point(100, init > 180 ? init + 10 : 181));
                    e.Graphics.DrawString($"{order.Total:n}", new Font("Helvetica", 3, FontStyle.Bold), Brushes.Black, new Point(118, init > 180 ? init + 10 : 180));
                }
                else
                {
                    MessageBox.Show(getOrderItemsResponse.Message, "Print Order", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show(getOrderResponse.Message, "Print Order", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void BtnPrint_Click(object sender, EventArgs e)
        {
            PrintPrevDiagReceipt.Document = PrintDocReceipt;
            PrintDocReceipt.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("Suit Detail", 150, 200);
            PrintPrevDiagReceipt.ShowDialog();
        }
    }
}
