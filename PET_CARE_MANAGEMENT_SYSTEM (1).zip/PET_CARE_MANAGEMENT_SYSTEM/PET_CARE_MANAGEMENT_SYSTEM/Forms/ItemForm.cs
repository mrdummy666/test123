﻿using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System.Data;

namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    public partial class ItemForm : Form
    {
        private readonly ProductsService productsService;
        private readonly ServicesService servicesService;
        public int orderId;
        public int itemId;
        public char itemType;
        public Product? selectedProduct = null;
        public Service? selectedService = null;
        public ItemForm(int orderId, int itemId, char itemType)
        {
            InitializeComponent();
            productsService = new();
            servicesService = new();
            this.orderId = orderId;
            this.itemId = itemId;
            this.itemType = itemType;
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            int selectedId = (itemType == 'P' ? selectedProduct!.Id : selectedService!.Id);
            int index = OrderForm.orderItems.FindIndex(oi => oi.ItemId == selectedId && oi.ItemType == itemType);

            if (index > -1)
            {
                OrderItem toUpdate = OrderForm.orderItems[index];
                toUpdate.Quantity = (int)NumQuantity.Value;
                toUpdate.Total = Convert.ToDecimal(TxtAmount.Text);
                toUpdate.Status = 1;
                OrderForm.orderItems[index] = toUpdate;
            }
            else
            {
                OrderForm.orderItems.Add(new OrderItem
                {
                    Id = OrderForm.orderItems.Count * -1,
                    ItemId = selectedId,
                    ItemType = itemType,
                    OrderId = orderId,
                    Price = itemType == 'P' ? selectedProduct!.Price : selectedService!.Price,
                    Quantity = (int)NumQuantity.Value,
                    Total = Convert.ToDecimal(TxtAmount.Text),
                    Status = 1
                });
            }

            Close();
        }

        private void NewPetForm_Load(object sender, EventArgs e)
        {
            DgvItems.MultiSelect = false;
            RefreshItemsTable();
            BtnSave.Enabled = false;
            //if (DgvProducts.Rows.Count > 0) DgvProducts.Rows[0].Selected = true;

            TxtItemName.ReadOnly = true;
            TxtPrice.ReadOnly = true;
            TxtAmount.ReadOnly = true;
            NumQuantity.Enabled = false;


            //if (orderId == 0)
            //{
            // NEW ITEM
            if (itemId == 0)
            {
                CBoxItemType.SelectedIndex = 0; // Product
                // CREATE
                LblTitle.Text = "ADD ITEM";

                TxtPrice.Text = "0.00";
                NumQuantity.Value = 0;
                TxtAmount.Text = "0.00";
            }
            else
            {
                //UPDATE
                LblTitle.Text = "UPDATE ITEM";
                OrderItem item = OrderForm.orderItems.FirstOrDefault(oi => oi.ItemId == itemId && oi.ItemType == itemType)!;

                string itemName;
                if (itemType == 'P')
                {
                    Product product = productsService.GetProduct(itemId).Payload!;

                    selectedProduct = new Product
                    {
                        Id = itemId,
                        Name = product.Name,
                        Quantity = product.Quantity,
                        Price = item.Price
                    };

                    NumQuantity.Value = item.Quantity > product.Quantity ? product.Quantity : item.Quantity;
                    itemName = selectedProduct.Name;
                }
                else
                {
                    Service service = servicesService.GetService(itemId).Payload!;

                    selectedService = new Service
                    {
                        Id = itemId,
                        Name = service.Name,
                        Price = item.Price,
                    };

                    NumQuantity.Minimum = 1;
                    itemName = selectedService.Name;
                }

                TxtItemName.Text = itemName;
                TxtPrice.Text = $"{item.Price:n}";
                TxtAmount.Text = $"{item.Total:n}";
                NumQuantity.Value = item.Quantity;
                NumQuantity.Minimum = 1;

                NumQuantity.Enabled = true;
                DgvItems.Enabled = false;
                CBoxItemType.Enabled = false;
                TxtSearchItem.Enabled = false;
                BtnSave.Enabled = true;

            }

        }

        private void RefreshItemsTable(string filter = "")
        {
            Response getItemsResponse = itemType == 'P' ? productsService.GetOrderProducts() : servicesService.GetServices();

            if (getItemsResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Name", typeof(string)));
                dt.Columns.Add(new DataColumn("Description", typeof(string)));
                dt.Columns.Add(new DataColumn("Available Qty", typeof(string)));
                dt.Columns.Add(new DataColumn("Price", typeof(string)));

                int selectedIndex = 0;
                if (itemType == 'P')
                {
                    List<Product> products = getItemsResponse.Payload!;
                    int ctr = 0;
                    foreach (Product product in products)
                    {
                        string name = product.Name;
                        string description = product.Description;
                        int quantity = product.Quantity;
                        decimal price = product.Price;

                        if (name.ToUpper().Contains(filter) || description.ToUpper().Contains(filter) || quantity.ToString().Contains(filter) || price.ToString().Contains(filter))
                        {
                            if (itemId != 0)
                            {
                                if (itemId == product.Id)
                                {
                                    selectedIndex = ctr;
                                    NumQuantity.Maximum = product.Quantity;
                                }
                                ctr++;
                            }

                            DataRow dr = dt.NewRow();
                            dr["Id"] = product.Id;
                            dr["Name"] = name;
                            dr["Description"] = description;
                            dr["Available Qty"] = $"{quantity:n0}";
                            dr["price"] = $"{price:n}";
                            dt.Rows.Add(dr);
                        }
                    }
                }
                else
                {
                    NumQuantity.Maximum = 100;
                    List<Service> services = getItemsResponse.Payload!;

                    int ctr = 0;
                    foreach (Service service in services)
                    {
                        string name = service.Name;
                        string description = service.Description;
                        decimal price = service.Price;

                        if (name.ToUpper().Contains(filter) || description.ToUpper().Contains(filter) || price.ToString().Contains(filter))
                        {
                            if (itemId != 0)
                            {
                                if (itemId == service.Id)
                                {
                                    selectedIndex = ctr;
                                }
                                ctr++;
                            }

                            DataRow dr = dt.NewRow();
                            dr["Id"] = service.Id;
                            dr["Name"] = name;
                            dr["Description"] = description;
                            dr["price"] = $"{price:n}";
                            dt.Rows.Add(dr);
                        }
                    }
                }


                DgvItems.DataSource = dt;
                DgvItems.Columns["Id"].Visible = false;

                if (itemId != 0)
                {
                    DgvItems.Rows[0].Selected = false;
                    DgvItems.Rows[selectedIndex].Selected = true;
                }

                DgvItems.Columns["Available Qty"].Visible = itemType == 'P';
            }
            else
            {
                MessageBox.Show(getItemsResponse.Message, string.Format("{0} Item", itemId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void TxtSearchOwner_TextChanged(object sender, EventArgs e)
        {
            RefreshItemsTable(TxtSearchItem.Text.Trim().ToUpper());
        }

        private void DgvItems_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            if (index > -1)
            {
                int id = (int)DgvItems.Rows[index].Cells[0].Value;
                string name = (string)DgvItems.Rows[index].Cells[1].Value;
                decimal price = Convert.ToDecimal(DgvItems.Rows[index].Cells[4].Value);
               
                if (itemType == 'P')
                {
                    int availQty = int.Parse(DgvItems.Rows[index].Cells[3].Value.ToString()!.Replace(",", ""));

                    if (availQty > 0)
                    {
                        selectedProduct = new Product
                        {
                            Id = id,
                            Name = name,
                            Quantity = availQty,
                            Price = price,
                        };
                        TxtItemName.Text = selectedProduct.Name;
                        TxtPrice.Text = $"{selectedProduct.Price:n}";
                        NumQuantity.Value = 1;
                        TxtAmount.Text = $"{selectedProduct.Price:n}";

                        NumQuantity.Enabled = true;
                        NumQuantity.Minimum = 1;
                        NumQuantity.Maximum = selectedProduct.Quantity;
                        BtnSave.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("There's no available quantity for this Item.", string.Format("{0} Item", itemId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    selectedService = new Service
                    {
                        Id = id,
                        Name = name,
                        Price = price,
                    };
                    TxtItemName.Text = selectedService.Name;
                    TxtPrice.Text = $"{selectedService.Price:n}";
                    NumQuantity.Value = 1;
                    TxtAmount.Text = $"{selectedService.Price:n}";

                    NumQuantity.Enabled = true;
                    NumQuantity.Minimum = 1;
                    BtnSave.Enabled = true;

                }
            }
        }

        private void NumQuantity_KeyUp(object sender, KeyEventArgs e)
        {
            TxtAmount.Text = $"{(NumQuantity.Value * (itemType == 'P' ? selectedProduct!.Price : selectedService!.Price)):n}";
        }

        private void NumQuantity_ValueChanged(object sender, EventArgs e)
        {
            TxtAmount.Text = $"{(NumQuantity.Value * (itemType == 'P' ? selectedProduct!.Price : selectedService!.Price)):n}";
        }

        private void CBoxItemType_SelectedIndexChanged(object sender, EventArgs e)
        {
            itemType = CBoxItemType.SelectedIndex == 0 ? 'P' : 'S';

            RefreshItemsTable();

            TxtItemName.Text = "";
            TxtPrice.Text = "0.00";
            TxtAmount.Text = "0.00";

            BtnSave.Enabled = false;
        }
    }
}
