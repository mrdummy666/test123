﻿namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    partial class NewPetForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            this.BtnClose = new Button();
            this.label1 = new Label();
            this.TxtPetName = new TextBox();
            this.label2 = new Label();
            this.label3 = new Label();
            this.TxtAnimalType = new TextBox();
            this.label4 = new Label();
            this.TxtBreed = new TextBox();
            this.label5 = new Label();
            this.BtnSave = new Button();
            this.label6 = new Label();
            this.CboxGender = new ComboBox();
            this.DgvOwners = new DataGridView();
            this.TxtSearchOwner = new TextBox();
            ((System.ComponentModel.ISupportInitialize)this.DgvOwners).BeginInit();
            SuspendLayout();
            // 
            // BtnClose
            // 
            this.BtnClose.BackColor = Color.Red;
            this.BtnClose.Cursor = Cursors.Hand;
            this.BtnClose.FlatAppearance.BorderSize = 0;
            this.BtnClose.FlatStyle = FlatStyle.Flat;
            this.BtnClose.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            this.BtnClose.ForeColor = Color.White;
            this.BtnClose.Location = new Point(602, 1);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new Size(42, 34);
            this.BtnClose.TabIndex = 6;
            this.BtnClose.Text = "X";
            this.BtnClose.UseVisualStyleBackColor = false;
            this.BtnClose.Click += this.BtnClose_Click;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            this.label1.ForeColor = Color.Black;
            this.label1.Location = new Point(4, 5);
            this.label1.Name = "label1";
            this.label1.Size = new Size(74, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "NEW PET";
            // 
            // TxtPetName
            // 
            this.TxtPetName.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            this.TxtPetName.Location = new Point(36, 86);
            this.TxtPetName.Name = "TxtPetName";
            this.TxtPetName.Size = new Size(253, 27);
            this.TxtPetName.TabIndex = 0;
            this.TxtPetName.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            this.label2.Location = new Point(36, 65);
            this.label2.Name = "label2";
            this.label2.Size = new Size(65, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "Pet Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            this.label3.Location = new Point(36, 124);
            this.label3.Name = "label3";
            this.label3.Size = new Size(94, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "Type of Animal";
            // 
            // TxtAnimalType
            // 
            this.TxtAnimalType.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            this.TxtAnimalType.Location = new Point(36, 143);
            this.TxtAnimalType.Name = "TxtAnimalType";
            this.TxtAnimalType.Size = new Size(253, 27);
            this.TxtAnimalType.TabIndex = 1;
            this.TxtAnimalType.TextAlign = HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            this.label4.Location = new Point(36, 181);
            this.label4.Name = "label4";
            this.label4.Size = new Size(42, 17);
            this.label4.TabIndex = 13;
            this.label4.Text = "Breed";
            // 
            // TxtBreed
            // 
            this.TxtBreed.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            this.TxtBreed.Location = new Point(36, 200);
            this.TxtBreed.Name = "TxtBreed";
            this.TxtBreed.Size = new Size(253, 27);
            this.TxtBreed.TabIndex = 2;
            this.TxtBreed.TextAlign = HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            this.label5.Location = new Point(316, 65);
            this.label5.Name = "label5";
            this.label5.Size = new Size(46, 17);
            this.label5.TabIndex = 15;
            this.label5.Text = "Owner";
            // 
            // BtnSave
            // 
            this.BtnSave.BackColor = SystemColors.Highlight;
            this.BtnSave.Cursor = Cursors.Hand;
            this.BtnSave.FlatAppearance.BorderSize = 0;
            this.BtnSave.FlatStyle = FlatStyle.Flat;
            this.BtnSave.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            this.BtnSave.ForeColor = Color.White;
            this.BtnSave.Location = new Point(263, 375);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new Size(113, 34);
            this.BtnSave.TabIndex = 5;
            this.BtnSave.Text = "Save";
            this.BtnSave.UseVisualStyleBackColor = false;
            this.BtnSave.Click += this.BtnSave_Click;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            this.label6.Location = new Point(36, 238);
            this.label6.Name = "label6";
            this.label6.Size = new Size(51, 17);
            this.label6.TabIndex = 18;
            this.label6.Text = "Gender";
            // 
            // CboxGender
            // 
            this.CboxGender.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            this.CboxGender.FormattingEnabled = true;
            this.CboxGender.Items.AddRange(new object[] { "Male", "Female" });
            this.CboxGender.Location = new Point(36, 257);
            this.CboxGender.Name = "CboxGender";
            this.CboxGender.Size = new Size(253, 29);
            this.CboxGender.TabIndex = 3;
            // 
            // DgvOwners
            // 
            this.DgvOwners.AllowUserToAddRows = false;
            this.DgvOwners.AllowUserToDeleteRows = false;
            this.DgvOwners.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvOwners.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.False;
            this.DgvOwners.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DgvOwners.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvOwners.Location = new Point(316, 86);
            this.DgvOwners.Name = "DgvOwners";
            this.DgvOwners.ReadOnly = true;
            this.DgvOwners.RowTemplate.Height = 25;
            this.DgvOwners.Size = new Size(292, 200);
            this.DgvOwners.TabIndex = 19;
            // 
            // TxtSearchOwner
            // 
            this.TxtSearchOwner.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            this.TxtSearchOwner.Location = new Point(419, 55);
            this.TxtSearchOwner.Name = "TxtSearchOwner";
            this.TxtSearchOwner.PlaceholderText = "Search Owner";
            this.TxtSearchOwner.Size = new Size(189, 25);
            this.TxtSearchOwner.TabIndex = 21;
            this.TxtSearchOwner.TextChanged += this.TxtSearchOwner_TextChanged;
            // 
            // NewPetForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(645, 430);
            Controls.Add(this.TxtSearchOwner);
            Controls.Add(this.DgvOwners);
            Controls.Add(this.CboxGender);
            Controls.Add(this.label6);
            Controls.Add(this.BtnSave);
            Controls.Add(this.label5);
            Controls.Add(this.TxtBreed);
            Controls.Add(this.label4);
            Controls.Add(this.TxtAnimalType);
            Controls.Add(this.label3);
            Controls.Add(this.label2);
            Controls.Add(this.TxtPetName);
            Controls.Add(this.label1);
            Controls.Add(this.BtnClose);
            FormBorderStyle = FormBorderStyle.None;
            Name = "NewPetForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "NewPetForm";
            Load += this.NewPetForm_Load;
            ((System.ComponentModel.ISupportInitialize)this.DgvOwners).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnClose;
        private Label label1;
        private TextBox TxtPetName;
        private Label label2;
        private Label label3;
        private TextBox TxtAnimalType;
        private Label label4;
        private TextBox TxtBreed;
        private Label label5;
        private Button BtnSave;
        private Label label6;
        private ComboBox CboxGender;
        private DataGridView DgvOwners;
        private TextBox TxtSearchOwner;
    }
}