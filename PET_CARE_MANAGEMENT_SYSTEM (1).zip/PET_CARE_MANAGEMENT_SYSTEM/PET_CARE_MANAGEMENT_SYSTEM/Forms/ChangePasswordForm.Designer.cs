﻿namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    partial class ChangePasswordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnClose = new Button();
            label1 = new Label();
            TxtNewPassword = new TextBox();
            label2 = new Label();
            label3 = new Label();
            TxtConfirmPassword = new TextBox();
            BtnSave = new Button();
            SuspendLayout();
            // 
            // BtnClose
            // 
            BtnClose.BackColor = Color.Red;
            BtnClose.Cursor = Cursors.Hand;
            BtnClose.FlatAppearance.BorderSize = 0;
            BtnClose.FlatStyle = FlatStyle.Flat;
            BtnClose.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            BtnClose.ForeColor = Color.White;
            BtnClose.Location = new Point(281, 1);
            BtnClose.Name = "BtnClose";
            BtnClose.Size = new Size(42, 34);
            BtnClose.TabIndex = 6;
            BtnClose.Text = "X";
            BtnClose.UseVisualStyleBackColor = false;
            BtnClose.Click += BtnClose_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(4, 5);
            label1.Name = "label1";
            label1.Size = new Size(157, 20);
            label1.TabIndex = 8;
            label1.Text = "CHANGE PASSWORD";
            // 
            // TxtNewPassword
            // 
            TxtNewPassword.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtNewPassword.Location = new Point(36, 86);
            TxtNewPassword.Name = "TxtNewPassword";
            TxtNewPassword.PasswordChar = '●';
            TxtNewPassword.Size = new Size(253, 27);
            TxtNewPassword.TabIndex = 0;
            TxtNewPassword.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(36, 65);
            label2.Name = "label2";
            label2.Size = new Size(94, 17);
            label2.TabIndex = 10;
            label2.Text = "New Password";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(36, 124);
            label3.Name = "label3";
            label3.Size = new Size(114, 17);
            label3.TabIndex = 11;
            label3.Text = "Confirm Password";
            // 
            // TxtConfirmPassword
            // 
            TxtConfirmPassword.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtConfirmPassword.Location = new Point(36, 143);
            TxtConfirmPassword.Name = "TxtConfirmPassword";
            TxtConfirmPassword.PasswordChar = '●';
            TxtConfirmPassword.Size = new Size(253, 27);
            TxtConfirmPassword.TabIndex = 1;
            TxtConfirmPassword.TextAlign = HorizontalAlignment.Center;
            // 
            // BtnSave
            // 
            BtnSave.BackColor = SystemColors.Highlight;
            BtnSave.Cursor = Cursors.Hand;
            BtnSave.FlatAppearance.BorderSize = 0;
            BtnSave.FlatStyle = FlatStyle.Flat;
            BtnSave.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnSave.ForeColor = Color.White;
            BtnSave.Location = new Point(106, 197);
            BtnSave.Name = "BtnSave";
            BtnSave.Size = new Size(113, 34);
            BtnSave.TabIndex = 5;
            BtnSave.Text = "Save";
            BtnSave.UseVisualStyleBackColor = false;
            BtnSave.Click += BtnSave_Click;
            // 
            // ChangePasswordForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(324, 263);
            Controls.Add(BtnSave);
            Controls.Add(TxtConfirmPassword);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(TxtNewPassword);
            Controls.Add(label1);
            Controls.Add(BtnClose);
            FormBorderStyle = FormBorderStyle.None;
            Name = "ChangePasswordForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ChangePasswordForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnClose;
        private Label label1;
        private TextBox TxtNewPassword;
        private Label label2;
        private Label label3;
        private TextBox TxtConfirmPassword;
        private Button BtnSave;
    }
}