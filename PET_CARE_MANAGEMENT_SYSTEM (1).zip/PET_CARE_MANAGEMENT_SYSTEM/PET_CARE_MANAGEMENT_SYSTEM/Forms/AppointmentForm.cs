﻿using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    public partial class AppointmentForm : Form
    {
        public AppointmentsService appointmentsService;
        public OwnersService ownersService;

        public int appointmentId;
        private int customerId = 0;
        public AppointmentForm(int appointmentId)
        {
            InitializeComponent();
            appointmentsService = new();
            ownersService = new();

            this.appointmentId = appointmentId;
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            string title = TxtTitle.Text.Trim();
            string details = TxtDetails.Text.Trim();
            string schedule = DtpSchedule.Value.ToString("yyyy-MM-dd H:mm:ss");
            string createdAt = DateTime.Now.ToString("yyyy-MM-dd H:mm:ss");
            string updatedAt = DateTime.Now.ToString("yyyy-MM-dd H:mm:ss");
            int status = CboxStatus.SelectedIndex + 1;

            int selectedRowIndex = DgvOwners.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvOwners.Rows[selectedRowIndex];
            int ownerId = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);


            if (title.Length == 0 || details.Length == 0)
            {
                MessageBox.Show("All fields are required.", "New Appointment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (appointmentId == 0)
                {
                    // CREATE
                    Response createAppointmentResponse = appointmentsService.CreateAppointment(ownerId, title, details, schedule, createdAt, updatedAt);
                    if (createAppointmentResponse.Status)
                    {
                        MessageBox.Show(createAppointmentResponse.Message, "New Appointment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        MainForm.ToRefreshAppointmentsTable = true;
                        Close();
                    }
                    else
                    {
                        MessageBox.Show(createAppointmentResponse.Message, "New Appointment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    // UPDATE
                    Response updateAppointmentResponse = appointmentsService.UpdateAppointment(appointmentId, customerId, title, details, schedule, status, updatedAt);
                    if (updateAppointmentResponse.Status)
                    {
                        MessageBox.Show(updateAppointmentResponse.Message, "Update Appointment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        MainForm.ToRefreshAppointmentsTable = true;
                        Close();
                    }
                    else
                    {
                        MessageBox.Show(updateAppointmentResponse.Message, "Update Appointment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void NewPetForm_Load(object sender, EventArgs e)
        {
            LblTitle.Text = appointmentId == 0 ? "NEW APPOINTMENT" : "UPDATE APPOINTMENT";
            DgvOwners.MultiSelect = false;

            if (appointmentId != 0)
            {
                Response getAppointmentResponse = appointmentsService.GetAppointment(appointmentId);
                if (getAppointmentResponse.Status)
                {
                    Appointment appointment = getAppointmentResponse.Payload!;
                    TxtTitle.Text = appointment.Title;
                    TxtDetails.Text = appointment.Details;
                    DtpSchedule.Value = appointment.Schedule;
                    customerId = appointment.CustomerId;

                    CboxStatus.Items.Add("Pending");
                    CboxStatus.Items.Add("Completed");
                    CboxStatus.Items.Add("Cancelled");
                    CboxStatus.Items.Add("Expired");

                    CboxStatus.SelectedIndex = appointment.Status - 1;

                    RefreshOwnersTable();
                }
                else
                {
                    MessageBox.Show(getAppointmentResponse.Message, "Update Appointment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                DtpSchedule.MinDate = DateTime.Now;
                RefreshOwnersTable();
                BtnSave.Enabled = DgvOwners.Rows.Count > 0;
                CboxStatus.Items.Add("Pending");
                CboxStatus.SelectedIndex = 0;
                CboxStatus.Enabled = false;

            }


        }

        private void RefreshOwnersTable(string filter = "")
        {
            Response getOwnersResponse = ownersService.GetOwners();

            if (getOwnersResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Name", typeof(string)));

                List<Owner> owners = getOwnersResponse.Payload!;

                if (appointmentId != 0)
                {

                    Owner selectedOwner = owners.FirstOrDefault(o => o.Id == customerId)!;

                    string fullName = selectedOwner.FirstName + " " + selectedOwner.LastName;
                    DataRow dr = dt.NewRow();
                    dr["Id"] = selectedOwner.Id;
                    dr["Name"] = fullName;
                    if (fullName.ToUpper().Contains(filter)) dt.Rows.Add(dr);

                    foreach (Owner owner in owners)
                    {
                        fullName = owner.FirstName + " " + owner.LastName;
                        if (customerId != owner.Id && fullName.ToUpper().Contains(filter))
                        {
                            dr = dt.NewRow();
                            dr["Id"] = owner.Id;
                            dr["Name"] = fullName;
                            dt.Rows.Add(dr);
                        }
                    }
                }
                else
                {
                    foreach (Owner owner in owners)
                    {
                        string fullName = owner.FirstName + " " + owner.LastName;

                        if (fullName.ToUpper().Contains(filter))
                        {
                            DataRow dr = dt.NewRow();
                            dr["Id"] = owner.Id;
                            dr["Name"] = fullName;
                            dt.Rows.Add(dr);
                        }
                    }
                }

                DgvOwners.DataSource = dt;
                DgvOwners.Columns["Id"].Visible = false;

                if (DgvOwners.Rows.Count > 0) DgvOwners.Rows[0].Selected = true;

                BtnSave.Enabled = DgvOwners.Rows.Count > 0;
            }
            else
            {
                MessageBox.Show(getOwnersResponse.Message, "New Pet", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void TxtSearchOwner_TextChanged(object sender, EventArgs e)
        {
            RefreshOwnersTable(TxtSearchCustomer.Text.Trim().ToUpper());
        }
    }
}
