﻿namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    partial class ServiceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnClose = new Button();
            LblTitle = new Label();
            TxtName = new TextBox();
            label2 = new Label();
            label3 = new Label();
            TxtDescription = new TextBox();
            label4 = new Label();
            TxtPrice = new TextBox();
            BtnSave = new Button();
            SuspendLayout();
            // 
            // BtnClose
            // 
            BtnClose.BackColor = Color.Red;
            BtnClose.Cursor = Cursors.Hand;
            BtnClose.FlatAppearance.BorderSize = 0;
            BtnClose.FlatStyle = FlatStyle.Flat;
            BtnClose.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            BtnClose.ForeColor = Color.White;
            BtnClose.Location = new Point(281, 1);
            BtnClose.Name = "BtnClose";
            BtnClose.Size = new Size(42, 34);
            BtnClose.TabIndex = 6;
            BtnClose.Text = "X";
            BtnClose.UseVisualStyleBackColor = false;
            BtnClose.Click += BtnClose_Click;
            // 
            // LblTitle
            // 
            LblTitle.AutoSize = true;
            LblTitle.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            LblTitle.ForeColor = Color.Black;
            LblTitle.Location = new Point(4, 5);
            LblTitle.Name = "LblTitle";
            LblTitle.Size = new Size(67, 20);
            LblTitle.TabIndex = 8;
            LblTitle.Text = "SERVICE";
            // 
            // TxtName
            // 
            TxtName.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtName.Location = new Point(36, 86);
            TxtName.Name = "TxtName";
            TxtName.Size = new Size(253, 27);
            TxtName.TabIndex = 0;
            TxtName.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(36, 65);
            label2.Name = "label2";
            label2.Size = new Size(88, 17);
            label2.TabIndex = 10;
            label2.Text = "Service Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(36, 124);
            label3.Name = "label3";
            label3.Size = new Size(119, 17);
            label3.TabIndex = 11;
            label3.Text = "Service Description";
            // 
            // TxtDescription
            // 
            TxtDescription.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtDescription.Location = new Point(36, 143);
            TxtDescription.Multiline = true;
            TxtDescription.Name = "TxtDescription";
            TxtDescription.Size = new Size(253, 91);
            TxtDescription.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(36, 244);
            label4.Name = "label4";
            label4.Size = new Size(36, 17);
            label4.TabIndex = 13;
            label4.Text = "Price";
            // 
            // TxtPrice
            // 
            TxtPrice.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtPrice.Location = new Point(36, 264);
            TxtPrice.Name = "TxtPrice";
            TxtPrice.Size = new Size(253, 27);
            TxtPrice.TabIndex = 4;
            TxtPrice.KeyPress += TxtPrice_KeyPress;
            // 
            // BtnSave
            // 
            BtnSave.BackColor = SystemColors.Highlight;
            BtnSave.Cursor = Cursors.Hand;
            BtnSave.FlatAppearance.BorderSize = 0;
            BtnSave.FlatStyle = FlatStyle.Flat;
            BtnSave.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnSave.ForeColor = Color.White;
            BtnSave.Location = new Point(106, 325);
            BtnSave.Name = "BtnSave";
            BtnSave.Size = new Size(113, 34);
            BtnSave.TabIndex = 5;
            BtnSave.Text = "Save";
            BtnSave.UseVisualStyleBackColor = false;
            BtnSave.Click += BtnSave_Click;
            // 
            // ServiceForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(324, 379);
            Controls.Add(BtnSave);
            Controls.Add(TxtPrice);
            Controls.Add(label4);
            Controls.Add(TxtDescription);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(TxtName);
            Controls.Add(LblTitle);
            Controls.Add(BtnClose);
            FormBorderStyle = FormBorderStyle.None;
            Name = "ServiceForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ServiceForm";
            Load += ServiceForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnClose;
        private Label LblTitle;
        private TextBox TxtName;
        private Label label2;
        private Label label3;
        private TextBox TxtDescription;
        private Label label4;
        private TextBox TxtPrice;
        private Button BtnSave;
    }
}