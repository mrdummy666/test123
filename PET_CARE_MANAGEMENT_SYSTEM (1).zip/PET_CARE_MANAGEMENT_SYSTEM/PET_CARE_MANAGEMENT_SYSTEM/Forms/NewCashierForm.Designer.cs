﻿namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    partial class NewCashierForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnClose = new Button();
            label1 = new Label();
            TxtFirstName = new TextBox();
            label2 = new Label();
            label3 = new Label();
            TxtMiddleName = new TextBox();
            label4 = new Label();
            TxtLastName = new TextBox();
            TxtUsername = new TextBox();
            label5 = new Label();
            BtnSave = new Button();
            label6 = new Label();
            CboxGender = new ComboBox();
            SuspendLayout();
            // 
            // BtnClose
            // 
            BtnClose.BackColor = Color.Red;
            BtnClose.Cursor = Cursors.Hand;
            BtnClose.FlatAppearance.BorderSize = 0;
            BtnClose.FlatStyle = FlatStyle.Flat;
            BtnClose.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            BtnClose.ForeColor = Color.White;
            BtnClose.Location = new Point(281, 1);
            BtnClose.Name = "BtnClose";
            BtnClose.Size = new Size(42, 34);
            BtnClose.TabIndex = 6;
            BtnClose.Text = "X";
            BtnClose.UseVisualStyleBackColor = false;
            BtnClose.Click += BtnClose_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(4, 5);
            label1.Name = "label1";
            label1.Size = new Size(110, 20);
            label1.TabIndex = 8;
            label1.Text = "NEW CASHIER";
            // 
            // TxtFirstName
            // 
            TxtFirstName.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtFirstName.Location = new Point(36, 86);
            TxtFirstName.Name = "TxtFirstName";
            TxtFirstName.Size = new Size(253, 27);
            TxtFirstName.TabIndex = 0;
            TxtFirstName.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(36, 65);
            label2.Name = "label2";
            label2.Size = new Size(71, 17);
            label2.TabIndex = 10;
            label2.Text = "First Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(36, 124);
            label3.Name = "label3";
            label3.Size = new Size(88, 17);
            label3.TabIndex = 11;
            label3.Text = "Middle Name";
            // 
            // TxtMiddleName
            // 
            TxtMiddleName.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtMiddleName.Location = new Point(36, 143);
            TxtMiddleName.Name = "TxtMiddleName";
            TxtMiddleName.Size = new Size(253, 27);
            TxtMiddleName.TabIndex = 1;
            TxtMiddleName.TextAlign = HorizontalAlignment.Center;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(36, 181);
            label4.Name = "label4";
            label4.Size = new Size(70, 17);
            label4.TabIndex = 13;
            label4.Text = "Last Name";
            // 
            // TxtLastName
            // 
            TxtLastName.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtLastName.Location = new Point(36, 200);
            TxtLastName.Name = "TxtLastName";
            TxtLastName.Size = new Size(253, 27);
            TxtLastName.TabIndex = 2;
            TxtLastName.TextAlign = HorizontalAlignment.Center;
            // 
            // TxtUsername
            // 
            TxtUsername.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtUsername.Location = new Point(36, 318);
            TxtUsername.Name = "TxtUsername";
            TxtUsername.Size = new Size(253, 27);
            TxtUsername.TabIndex = 4;
            TxtUsername.TextAlign = HorizontalAlignment.Center;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(36, 299);
            label5.Name = "label5";
            label5.Size = new Size(67, 17);
            label5.TabIndex = 15;
            label5.Text = "Username";
            // 
            // BtnSave
            // 
            BtnSave.BackColor = SystemColors.Highlight;
            BtnSave.Cursor = Cursors.Hand;
            BtnSave.FlatAppearance.BorderSize = 0;
            BtnSave.FlatStyle = FlatStyle.Flat;
            BtnSave.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnSave.ForeColor = Color.White;
            BtnSave.Location = new Point(106, 373);
            BtnSave.Name = "BtnSave";
            BtnSave.Size = new Size(113, 34);
            BtnSave.TabIndex = 5;
            BtnSave.Text = "Save";
            BtnSave.UseVisualStyleBackColor = false;
            BtnSave.Click += BtnSave_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(36, 238);
            label6.Name = "label6";
            label6.Size = new Size(51, 17);
            label6.TabIndex = 18;
            label6.Text = "Gender";
            // 
            // CboxGender
            // 
            CboxGender.DropDownStyle = ComboBoxStyle.DropDownList;
            CboxGender.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CboxGender.FormattingEnabled = true;
            CboxGender.Items.AddRange(new object[] { "Male", "Female" });
            CboxGender.Location = new Point(36, 257);
            CboxGender.Name = "CboxGender";
            CboxGender.Size = new Size(253, 29);
            CboxGender.TabIndex = 3;
            // 
            // NewCashierForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(324, 439);
            Controls.Add(CboxGender);
            Controls.Add(label6);
            Controls.Add(BtnSave);
            Controls.Add(TxtUsername);
            Controls.Add(label5);
            Controls.Add(TxtLastName);
            Controls.Add(label4);
            Controls.Add(TxtMiddleName);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(TxtFirstName);
            Controls.Add(label1);
            Controls.Add(BtnClose);
            FormBorderStyle = FormBorderStyle.None;
            Name = "NewCashierForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "NewCashierForm";
            Load += NewCashierForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnClose;
        private Label label1;
        private TextBox TxtFirstName;
        private Label label2;
        private Label label3;
        private TextBox TxtMiddleName;
        private Label label4;
        private TextBox TxtLastName;
        private TextBox TxtUsername;
        private Label label5;
        private Button BtnSave;
        private Label label6;
        private ComboBox CboxGender;
    }
}