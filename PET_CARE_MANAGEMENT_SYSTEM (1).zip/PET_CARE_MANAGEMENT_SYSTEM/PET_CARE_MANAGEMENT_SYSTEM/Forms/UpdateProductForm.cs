﻿using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    public partial class UpdateProductForm : Form
    {
        public CategoriesService categoriesService;
        public ProductsService productsService;
        public int toUpdateId;
        private List<Category> categories = new();

        public UpdateProductForm(int productId)
        {
            InitializeComponent();
            categoriesService = new();
            productsService = new();
            toUpdateId = productId;
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            string name = TxtName.Text.Trim();
            string description = TxtDescription.Text.Trim();
            int quantity = (int)NumQuantity.Value;
            decimal price = Convert.ToDecimal(TxtPrice.Text.Trim());
            string categoryName = CboxCategory.SelectedItem != null ? CboxCategory.SelectedItem.ToString()! : "";
            string expiredAt = DtpExpirationDate.Value.ToString("yyyy-MM-dd H:mm:ss");

            if (name.Length == 0 || description.Length == 0 || categoryName.Length == 0)
            {
                MessageBox.Show("All fields are required.", "Upadte Product", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (price > 0)
                {
                    Response checkProductName = productsService.CheckProductName(name, toUpdateId);

                    if (checkProductName.Status)
                    {
                        Response getCategoryNameResponse = categoriesService.GetCategoryIdByName(categoryName);

                        if (getCategoryNameResponse.Status)
                        {
                            Response getCategoryIdResponse = categoriesService.GetCategoryIdByName(categoryName);

                            Response createProductResponse = productsService.UpdateProduct(toUpdateId, getCategoryIdResponse.Payload!, name, description, quantity, price, DtpExpirationDate.Visible ? expiredAt : null);
                            if (createProductResponse.Status)
                            {
                                MessageBox.Show(createProductResponse.Message, "Update Product", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                MainForm.ToRefreshProductsTable = true;
                                Close();
                            }
                            else
                            {
                                MessageBox.Show(createProductResponse.Message, "Update Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show(getCategoryNameResponse.Message, "Update Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show(checkProductName.Message, "Update Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Price must be greater than 0.00.", "Update Product", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }
            }
        }

        private void UpdateProductForm_Load(object sender, EventArgs e)
        {
            Response getProductResponse = productsService.GetProduct(toUpdateId);

            if (getProductResponse.Status)
            {
                Product product = getProductResponse.Payload!;
                TxtName.Text = product.Name;
                TxtDescription.Text = product.Description;
                TxtPrice.Text = product.Price.ToString();
                NumQuantity.Value = product.Quantity;
                if (product.ExpiredAt != null)
                {
                    DtpExpirationDate.Value = product.ExpiredAt.Value;
                    LblExpirationDate.Visible = true;
                    DtpExpirationDate.Visible = true;
                }
                else
                {
                    LblExpirationDate.Visible = false;
                    DtpExpirationDate.Visible = false;
                }

                Response getCategoriesResponse = categoriesService.GetCategories();
                if (getCategoriesResponse.Status)
                {
                    categories = getCategoriesResponse.Payload!;
                    int selectedIndex = 0;
                    for (int i = 0; i < categories.Count; i++)
                    {
                        CboxCategory.Items.Add(categories[i].Name);
                        if (product.CategoryId == categories[i].Id) selectedIndex = i;
                    }
                    if (categories.Count > 0) CboxCategory.SelectedIndex = selectedIndex;
                }
                else
                {
                    MessageBox.Show(getCategoriesResponse.Message, "Update Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show(getProductResponse.Message, "Update Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TxtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            // allows 0-9, backspace, and decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }

            // checks to make sure only 1 decimal is allowed
            if (e.KeyChar == 46)
            {
                if (((TextBox)sender).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }

        private void CboxCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            string categoryName = CboxCategory.SelectedItem!.ToString()!;

            int hasExpiration = categories.Where(c => c.Name == categoryName).FirstOrDefault()!.HasExpiration;

            LblExpirationDate.Visible = hasExpiration == 1;
            DtpExpirationDate.Visible = hasExpiration == 1;
        }
    }
}
