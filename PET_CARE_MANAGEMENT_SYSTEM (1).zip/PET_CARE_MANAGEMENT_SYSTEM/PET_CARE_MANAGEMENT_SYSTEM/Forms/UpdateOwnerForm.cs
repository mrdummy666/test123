﻿using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    public partial class UpdateOwnerForm : Form
    {
        public AuthService authService;
        public OwnersService ownersService;
        public int toUpdateId;

        public UpdateOwnerForm(int ownerId)
        {
            InitializeComponent();
            authService = new();
            ownersService = new();
            toUpdateId = ownerId;
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            string firstName = TxtFirstName.Text.Trim();
            string middleName = TxtMiddleName.Text.Trim();
            string lastName = TxtLastName.Text.Trim();
            string mobileNumber = TxtMobileNumber.Text.Trim();
            int genderIndex = CboxGender.SelectedIndex;
            char gender = genderIndex == 0 ? 'M' : 'F';


            if (firstName.Length == 0 || middleName.Length == 0 || lastName.Length == 0 || mobileNumber.Length == 0)
            {
                MessageBox.Show("All fields are required.", "Update Pet Owner", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                //^(09|\+639)\d{9}$
                var regexItem = new Regex("^(09|\\+639)\\d{9}$");

                if (mobileNumber.Length < 11 || !regexItem.IsMatch(mobileNumber))
                {
                    MessageBox.Show("Invalid Mobile Number.", "Update Pet Owner", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    Response updateOwnerResponse = ownersService.UpdateOwner(toUpdateId, firstName, middleName, lastName, gender, mobileNumber);
                    if (updateOwnerResponse.Status)
                    {
                        MessageBox.Show(updateOwnerResponse.Message, "Update Pet Owner", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        MainForm.ToRefreshOwnersTable = true;
                        Close();
                    }
                    else
                    {
                        MessageBox.Show(updateOwnerResponse.Message, "Update Pet Owner", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void UpdateOwnerForm_Load(object sender, EventArgs e)
        {
            Response getOwnerResponse = ownersService.GetOwner(toUpdateId);
            if (getOwnerResponse.Status)
            {
                Owner owner = getOwnerResponse.Payload!;
                TxtFirstName.Text = owner.FirstName;
                TxtMiddleName.Text = owner.MiddleName;
                TxtLastName.Text = owner.LastName;
                CboxGender.SelectedIndex = owner.Gender == 'M' ? 0 : 1;
                TxtMobileNumber.Text = owner.MobileNumber;
            }
            else
            {
                MessageBox.Show(getOwnerResponse.Message, "Update Pet Owner", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
