﻿using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    public partial class UpdateCashierForm : Form
    {
        public AuthService authService;
        public CashiersService cashiersService;
        public int toUpdateId;
        public UpdateCashierForm(int id)
        {
            InitializeComponent();
            authService = new();
            cashiersService = new();

            toUpdateId = id;
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            string firstName = TxtFirstName.Text.Trim();
            string middleName = TxtMiddleName.Text.Trim();
            string lastName = TxtLastName.Text.Trim();
            string username = TxtUsername.Text.Trim();
            int genderIndex = CboxGender.SelectedIndex;
            char gender = genderIndex == 0 ? 'M' : 'F';


            if (firstName.Length == 0 || middleName.Length == 0 || lastName.Length == 0 || username.Length == 0)
            {
                MessageBox.Show("All fields are required.", "Update Cashier", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Response checkUsernameResponse = authService.CheckUsername(username, toUpdateId);

                if (checkUsernameResponse.Status)
                {
                    Response createCashierResponse = cashiersService.UpdateCashier(toUpdateId, firstName, middleName, lastName, gender, username);
                    if (createCashierResponse.Status)
                    {
                        MessageBox.Show(createCashierResponse.Message, "Update Cashier", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        MainForm.ToRefreshCashiersTable = true;
                        Close();
                    }
                    else
                    {
                        MessageBox.Show(createCashierResponse.Message, "Update Cashier", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show(checkUsernameResponse.Message, "Update Cashier", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void UpdateCashierForm_Load(object sender, EventArgs e)
        {
            Response getUserResponse = authService.GetUser(toUpdateId);
            if (getUserResponse.Status)
            {
                User user = getUserResponse.Payload!;
                TxtFirstName.Text = user.FirstName;
                TxtMiddleName.Text = user.MiddleName;
                TxtLastName.Text = user.LastName;
                CboxGender.SelectedIndex = user.Gender == 'M' ? 0 : 1;
                TxtUsername.Text = user.Username;
            }
            else
            {
                MessageBox.Show(getUserResponse.Message, "Update Cashier", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
