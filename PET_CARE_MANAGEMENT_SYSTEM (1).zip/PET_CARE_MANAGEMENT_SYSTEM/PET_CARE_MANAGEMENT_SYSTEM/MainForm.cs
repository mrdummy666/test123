﻿using PET_CARE_MANAGEMENT_SYSTEM.Forms;
using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;

using System.Data;

namespace PET_CARE_MANAGEMENT_SYSTEM
{
    public partial class MainForm : Form
    {
        private readonly User currentUser;
        private readonly CashiersService cashiersService;
        private readonly OwnersService ownersService;
        private readonly PetsService petsService;
        private readonly CategoriesService categoriesService;
        private readonly ProductsService productsService;
        private readonly OrdersService ordersService;
        private readonly AuthService authService;
        private readonly PetActivityService petActivityService;
        private readonly AppointmentsService appointmentsService;
        private readonly ServicesService servicesService;

        private int categoryId = 0;

        // TO REFRESH TABLES
        public static bool ToRefreshHome { get; set; } = true;
        public static bool ToRefreshCashiersTable { get; set; } = true;
        public static bool ToRefreshOwnersTable { get; set; } = true;
        public static bool ToRefreshPetsTable { get; set; } = true;
        public static bool ToRefreshProductsTable { get; set; } = true;
        public static bool ToRefreshCategoriesTable { get; set; } = true;
        public static bool ToRefreshOrdersTable { get; set; } = true;
        public static bool ToRefreshAppointmentsTable { get; set; } = true;
        public static bool ToRefreshServicesTable { get; set; } = true;

        public MainForm(User user)
        {
            InitializeComponent();
            currentUser = user;
            cashiersService = new();
            ownersService = new();
            petsService = new();
            categoriesService = new();
            productsService = new();
            ordersService = new();
            authService = new();
            petActivityService = new();
            appointmentsService = new();
            servicesService = new();
        }

        private void HandleNavigation(string id)
        {
            // BUTTONS
            BtnHomeAdmin.BackColor = Color.WhiteSmoke;
            BtnCashiersAdmin.BackColor = Color.WhiteSmoke;
            BtnOwnersAdmin.BackColor = Color.WhiteSmoke;
            BtnPetsAdmin.BackColor = Color.WhiteSmoke;
            BtnProductsAdmin.BackColor = Color.WhiteSmoke;
            BtnProductsCashier.BackColor = Color.WhiteSmoke;
            BtnCategoriesAdmin.BackColor = Color.WhiteSmoke;
            BtnOrdersCashier.BackColor = Color.WhiteSmoke;
            BtnOrdersAdmin.BackColor = Color.WhiteSmoke;
            BtnAppointmentsAdmin.BackColor = Color.WhiteSmoke;
            BtnServicesAdmin.BackColor = Color.WhiteSmoke;
            BtnServicesCashier.BackColor = Color.WhiteSmoke;

            // PANELS
            PnlHomeAdmin.Visible = false;
            PnlCashiers.Visible = false;
            PnlOwners.Visible = false;
            PnlPets.Visible = false;
            PnlProducts.Visible = false;
            PnlCategories.Visible = false;
            PnlOrders.Visible = false;
            PnlAppointments.Visible = false;
            PnlServices.Visible = false;

            // REFRESH
            ToRefreshHome = true;
            ToRefreshCashiersTable = true;
            ToRefreshOwnersTable = true;
            ToRefreshPetsTable = true;
            ToRefreshProductsTable = true;
            ToRefreshCategoriesTable = true;
            ToRefreshOrdersTable = true;
            ToRefreshAppointmentsTable = true;
            ToRefreshServicesTable = true;

            switch (id)
            {
                case "home":
                    BtnHomeAdmin.BackColor = Color.Aquamarine;
                    PnlHomeAdmin.Visible = true;
                    ToRefreshHome = false;
                    RefreshHomeTables();
                    break;
                case "cashiers":
                    BtnCashiersAdmin.BackColor = Color.Aquamarine;
                    PnlCashiers.Visible = true;
                    ToRefreshCashiersTable = false;
                    RefreshCashiersTable();
                    break;
                case "owners":
                    BtnOwnersAdmin.BackColor = Color.Aquamarine;
                    PnlOwners.Visible = true;
                    ToRefreshOwnersTable = false;
                    RefreshOwnersTable();
                    break;
                case "pets":
                    BtnPetsAdmin.BackColor = Color.Aquamarine;
                    PnlPets.Visible = true;
                    ToRefreshPetsTable = false;
                    RefreshPetsTable();
                    break;
                case "categories":
                    BtnCategoriesAdmin.BackColor = Color.Aquamarine;
                    PnlCategories.Visible = true;
                    ToRefreshCategoriesTable = false;
                    RefreshCategoriesTable();
                    break;
                case "products":
                    BtnProductsAdmin.BackColor = Color.Aquamarine;
                    BtnProductsCashier.BackColor = Color.Aquamarine;
                    PnlProducts.Visible = true;
                    ToRefreshProductsTable = false;
                    RefreshProductsTable();
                    break;
                case "orders":
                    BtnOrdersCashier.BackColor = Color.Aquamarine;
                    BtnOrdersAdmin.BackColor = Color.Aquamarine;
                    PnlOrders.Visible = true;
                    ToRefreshOrdersTable = false;
                    RefreshOrdersTable();
                    break;
                case "appointments":
                    BtnAppointmentsAdmin.BackColor = Color.Aquamarine;
                    PnlAppointments.Visible = true;
                    ToRefreshAppointmentsTable = false;
                    RefreshAppointmentsTable();
                    break;
                case "services":
                    BtnServicesAdmin.BackColor = Color.Aquamarine;
                    BtnServicesCashier.BackColor = Color.Aquamarine;
                    PnlServices.Visible = true;
                    ToRefreshServicesTable = false;
                    RefreshServicesTable();
                    break;
                default:
                    break;
            }
        }

        // REFRESH TABLES
        private void RefreshCashiersTable(string filter = "")
        {
            Response getCashiersResponse = cashiersService.GetCashiers();

            if (getCashiersResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("#", typeof(int)));
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Username", typeof(string)));
                dt.Columns.Add(new DataColumn("First Name", typeof(string)));
                dt.Columns.Add(new DataColumn("Middle Name", typeof(string)));
                dt.Columns.Add(new DataColumn("Last Name", typeof(string)));
                dt.Columns.Add(new DataColumn("Gender", typeof(string)));

                List<User> cashiers = getCashiersResponse.Payload!;
                int rowNum = 1;
                foreach (User cashier in cashiers)
                {
                    string username = cashier.Username;
                    string firstName = cashier.FirstName;
                    string middleName = cashier.MiddleName;
                    string lastName = cashier.LastName;
                    string gender = cashier.Gender == 'M' ? "Male" : "Female";


                    bool toAdd = filter == "" || (username.ToUpper().Contains(filter) || firstName.ToUpper().Contains(filter) || middleName.ToUpper().Contains(filter) || lastName.ToUpper().Contains(filter) || gender.ToUpper().Contains(filter));

                    if (toAdd)
                    {
                        DataRow dr = dt.NewRow();
                        dr["#"] = rowNum++;
                        dr["Id"] = cashier.Id;
                        dr["Username"] = username;
                        dr["First Name"] = firstName;
                        dr["Middle Name"] = middleName;
                        dr["Last Name"] = lastName;
                        dr["Gender"] = gender;
                        dt.Rows.Add(dr);
                    }
                }

                DgvCashiers.DataSource = dt;
                DgvCashiers.Columns["Id"].Visible = false;
            }
            else
            {
                MessageBox.Show(getCashiersResponse.Message, "Cashiers", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void RefreshOwnersTable(string filter = "")
        {
            Response getOwnersResponse = ownersService.GetOwners();

            if (getOwnersResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("#", typeof(int)));
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("First Name", typeof(string)));
                dt.Columns.Add(new DataColumn("Middle Name", typeof(string)));
                dt.Columns.Add(new DataColumn("Last Name", typeof(string)));
                dt.Columns.Add(new DataColumn("Gender", typeof(string)));
                dt.Columns.Add(new DataColumn("Mobile Number", typeof(string)));

                List<Owner> owners = getOwnersResponse.Payload!;
                int rowNum = 1;
                foreach (Owner owner in owners)
                {
                    string firstName = owner.FirstName;
                    string middleName = owner.MiddleName;
                    string lastName = owner.LastName;
                    string gender = owner.Gender == 'M' ? "Male" : "Female";
                    string mobileNumber = owner.MobileNumber;

                    bool toAdd = filter == "" || (firstName.ToUpper().Contains(filter) || middleName.ToUpper().Contains(filter) || lastName.ToUpper().Contains(filter) || gender.ToUpper().Contains(filter) || mobileNumber.Contains(filter));

                    if (toAdd)
                    {
                        DataRow dr = dt.NewRow();
                        dr["#"] = rowNum++;
                        dr["Id"] = owner.Id;
                        dr["First Name"] = firstName;
                        dr["Middle Name"] = middleName;
                        dr["Last Name"] = lastName;
                        dr["Gender"] = gender;
                        dr["Mobile Number"] = mobileNumber;
                        dt.Rows.Add(dr);
                    }
                }

                DgvOwners.DataSource = dt;
                DgvOwners.Columns["Id"].Visible = false;
            }
            else
            {
                MessageBox.Show(getOwnersResponse.Message, "Owners", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void RefreshPetsTable(string filter = "")
        {
            Response getPetsResponse = petsService.GetPets();

            if (getPetsResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("#", typeof(int)));
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Pet Name", typeof(string)));
                dt.Columns.Add(new DataColumn("Type of Animal", typeof(string)));
                dt.Columns.Add(new DataColumn("Breed", typeof(string)));
                dt.Columns.Add(new DataColumn("Gender", typeof(string)));
                dt.Columns.Add(new DataColumn("Owner", typeof(string)));

                List<Pet> pets = getPetsResponse.Payload!;
                int rowNum = 1;
                foreach (Pet pet in pets)
                {
                    Response getOwnerNameResponse = petsService.GetOwnerName(pet.OwnerId);
                    string ownerName = getOwnerNameResponse.Status ? getOwnerNameResponse.Payload! : "";
                    string petName = pet.PetName;
                    string animalType = pet.AnimalType;
                    string breed = pet.Breed;
                    string gender = pet.Gender == 'M' ? "Male" : "Female";


                    bool toAdd = filter == "" || (ownerName.ToUpper().Contains(filter) || petName.ToUpper().Contains(filter) || animalType.Contains(filter) || breed.Contains(filter) || gender.ToUpper().Contains(filter));

                    if (toAdd)
                    {
                        DataRow dr = dt.NewRow();
                        dr["#"] = rowNum++;
                        dr["Id"] = pet.Id;
                        dr["Pet Name"] = petName;
                        dr["Type of Animal"] = animalType;
                        dr["Breed"] = breed;
                        dr["Gender"] = gender;
                        dr["Owner"] = ownerName;
                        dt.Rows.Add(dr);
                    }
                }

                DgvPets.DataSource = dt;
                DgvPets.Columns["Id"].Visible = false;
            }
            else
            {
                MessageBox.Show(getPetsResponse.Message, "Cashiers", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void RefreshCategoriesTable(string filter = "")
        {
            Response getCategoriesResponse = categoriesService.GetCategories();

            if (getCategoriesResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("#", typeof(int)));
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Name", typeof(string)));
                dt.Columns.Add(new DataColumn("Has Expiration", typeof(string)));

                List<Category> categories = getCategoriesResponse.Payload!;
                int rowNum = 1;
                foreach (Category category in categories)
                {
                    string name = category.Name;
                    string hasExpiration = category.HasExpiration == 1 ? "Yes" : "No";

                    bool toAdd = filter == "" || (name.ToUpper().Contains(filter) || hasExpiration.ToUpper().Contains(filter));

                    if (toAdd)
                    {
                        DataRow dr = dt.NewRow();
                        dr["#"] = rowNum++;
                        dr["Id"] = category.Id;
                        dr["Name"] = name;
                        dr["Has Expiration"] = hasExpiration;
                        dt.Rows.Add(dr);
                    }
                }

                DgvCategories.DataSource = dt;
                DgvCategories.Columns["Id"].Visible = false;
            }
            else
            {
                MessageBox.Show(getCategoriesResponse.Message, "Categories", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void RefreshProductsTable(string filter = "")
        {
            Response getProductsResponse = productsService.GetProducts();

            if (getProductsResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("#", typeof(int)));
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Name", typeof(string)));
                dt.Columns.Add(new DataColumn("Description", typeof(string)));
                dt.Columns.Add(new DataColumn("Price", typeof(string)));
                dt.Columns.Add(new DataColumn("Quantity", typeof(string)));
                dt.Columns.Add(new DataColumn("Category", typeof(string)));
                dt.Columns.Add(new DataColumn("Expiration", typeof(string)));
                dt.Columns.Add(new DataColumn("Status", typeof(string)));

                List<Product> products = getProductsResponse.Payload!;
                int rowNum = 1;
                foreach (Product product in products)
                {
                    Response getCategoryNameResponse = categoriesService.GetCategoryNameById(product.CategoryId);
                    string categoryName = getCategoryNameResponse.Status ? getCategoryNameResponse.Payload! : "";
                    string name = product.Name;
                    string description = product.Description;
                    decimal price = product.Price;
                    int quantity = product.Quantity;
                    string? expiration = product.ExpiredAt?.ToString("MMM dd, yyyy");

                    bool toAdd = filter == "" || (name.ToUpper().Contains(filter) || description.ToUpper().Contains(filter) || price.ToString().Contains(filter) || quantity.ToString().Contains(filter) || categoryName.ToUpper().Contains(filter)) || expiration != null && expiration.ToUpper().Contains(filter);

                    if (toAdd)
                    {
                        DataRow dr = dt.NewRow();
                        dr["#"] = rowNum++;
                        dr["Id"] = product.Id;
                        dr["Name"] = name;
                        dr["Description"] = description;
                        dr["Price"] = $"{price:n}";
                        dr["Quantity"] = $"{quantity:n0}";
                        dr["Category"] = categoryName;
                        dr["Expiration"] = expiration ?? "No";
                        dr["Status"] = product.ExpiredAt != null ? (product.ExpiredAt <= DateTime.Now ? "Expired" : "Not Expired") : "";
                        dt.Rows.Add(dr);
                    }
                }

                DgvProducts.DataSource = dt;
                DgvProducts.Columns["Id"].Visible = false;

                if (currentUser.Role == 'C')
                {
                    DgvProducts.Columns["Expiration"].Visible = false;
                    DgvProducts.Columns["Status"].Visible = false;
                }
            }
            else
            {
                MessageBox.Show(getProductsResponse.Message, "Products", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void RefreshOrdersTable(string filter = "")
        {
            Response getOrdersResponse = ordersService.GetOrders();

            if (getOrdersResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("#", typeof(int)));
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Customer", typeof(string)));
                dt.Columns.Add(new DataColumn("Created By", typeof(string)));
                dt.Columns.Add(new DataColumn("Role", typeof(string)));
                dt.Columns.Add(new DataColumn("Total", typeof(string)));
                dt.Columns.Add(new DataColumn("Date Created", typeof(string)));

                List<Order> orders = getOrdersResponse.Payload!;
                int rowNum = 1;
                foreach (Order order in orders)
                {
                    Response getCustomerResponse = ownersService.GetOwner(order.CustomerId);
                    Owner? customer = getCustomerResponse.Payload;
                    Response getCreatorResponse = authService.GetUser(order.CreatorId);
                    User? creator = getCreatorResponse.Payload;

                    string ownerName = customer != null ? customer.FirstName + " " + customer.LastName : "";
                    string creatorName = creator != null ? creator.FirstName + " " + creator.LastName : "";
                    string creatorRole = order.CreatorRole == 'C' ? "Cashier" : "Admin";
                    decimal total = order.Total;
                    string createdAt = order.CreatedAt.ToString("MMMM dd, yyyy hh:mm:ss tt");

                    bool toAdd = (filter == "" || (ownerName.ToUpper().Contains(filter) || creatorName.ToUpper().Contains(filter) || total.ToString().ToUpper().Contains(filter) || createdAt.ToUpper().Contains(filter))) && (currentUser.Role == 'C' ? order.CreatorId == currentUser.Id && order.CreatedAt.Date.ToString() == DateTime.Now.Date.ToString() : (order.CreatedAt.Date >= DtpOrdersFrom.Value && order.CreatedAt.Date <= DtpOrdersTo.Value));

                    if (toAdd)
                    {
                        DataRow dr = dt.NewRow();
                        dr["#"] = rowNum++;
                        dr["Id"] = order.Id;
                        dr["Customer"] = ownerName;
                        dr["Created By"] = creatorName;
                        dr["Role"] = creatorRole;
                        dr["Total"] = $"{total:n}";
                        dr["Date Created"] = createdAt;
                        dt.Rows.Add(dr);
                    }
                }

                DgvOrders.DataSource = dt;
                DgvOrders.Columns["Id"].Visible = false;
                if (currentUser.Role == 'C')
                {
                    DgvOrders.Columns["Created By"].Visible = false;
                    DgvOrders.Columns["Role"].Visible = false;
                }
            }
            else
            {
                MessageBox.Show(getOrdersResponse.Message, "Orders", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void RefreshAppointmentsTable(string filter = "")
        {
            Response getAppointmentsResponse = appointmentsService.GetAppointments();

            if (getAppointmentsResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("#", typeof(int)));
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Customer", typeof(string)));
                dt.Columns.Add(new DataColumn("Title", typeof(string)));
                dt.Columns.Add(new DataColumn("Details", typeof(string)));
                dt.Columns.Add(new DataColumn("Schedule", typeof(string)));
                dt.Columns.Add(new DataColumn("Status", typeof(string)));

                List<Appointment> appointments = getAppointmentsResponse.Payload!;
                int rowNum = 1;
                foreach (Appointment appointment in appointments)
                {
                    Response getCustomerResponse = ownersService.GetOwner(appointment.CustomerId);
                    Owner? customer = getCustomerResponse.Payload;

                    string title = appointment.Title;
                    string details = appointment.Details;
                    string ownerName = customer != null ? customer.FirstName + " " + customer.LastName : "";
                    string schedule = appointment.Schedule.ToString("MMMM dd, yyyy hh:mm:ss tt");
                    string status = appointment.Status == 1 ? "Pending" : appointment.Status == 2 ? "Completed" : appointment.Status == 3 ? "Cancelled" : "Expired";

                    bool toAdd = (filter == "" || (ownerName.ToUpper().Contains(filter) || title.ToUpper().Contains(filter) || details.ToUpper().Contains(filter) || schedule.ToUpper().Contains(filter) || status.ToUpper().Contains(filter)) && (appointment.Schedule.Date >= DtpAppointmentsFrom.Value && appointment.Schedule.Date <= DtpAppointmentsTo.Value));

                    if (toAdd)
                    {
                        DataRow dr = dt.NewRow();
                        dr["#"] = rowNum++;
                        dr["Id"] = appointment.Id;
                        dr["Customer"] = ownerName;
                        dr["Title"] = title;
                        dr["Details"] = details;
                        dr["Schedule"] = schedule;
                        dr["Status"] = status;
                        dt.Rows.Add(dr);
                    }
                }

                DgvAppointments.DataSource = dt;
                DgvAppointments.Columns["Id"].Visible = false;
            }
            else
            {
                MessageBox.Show(getAppointmentsResponse.Message, "Appointments", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void RefreshHomeTables()
        {
            Response getAppointmentsTodayResponse = appointmentsService.GetAppointmentsToday();
            if (getAppointmentsTodayResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("#", typeof(int)));
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Customer", typeof(string)));
                dt.Columns.Add(new DataColumn("Title", typeof(string)));
                dt.Columns.Add(new DataColumn("Schedule", typeof(string)));

                List<Appointment> appointments = getAppointmentsTodayResponse.Payload!;
                int rowNum = 1;
                foreach (Appointment appointment in appointments)
                {
                    Response getCustomerResponse = ownersService.GetOwner(appointment.CustomerId);
                    Owner? customer = getCustomerResponse.Payload;

                    string title = appointment.Title;
                    string ownerName = customer != null ? customer.FirstName + " " + customer.LastName : "";
                    string schedule = appointment.Schedule.ToString("MMMM dd, yyyy hh:mm:ss tt");

                    DataRow dr = dt.NewRow();
                    dr["#"] = rowNum++;
                    dr["Id"] = appointment.Id;
                    dr["Customer"] = ownerName;
                    dr["Title"] = title;
                    dr["Schedule"] = schedule;
                    dt.Rows.Add(dr);
                }

                DgvTodaysAppointments.DataSource = dt;
                DgvTodaysAppointments.Columns["Id"].Visible = false;
            }
            else
            {
                MessageBox.Show(getAppointmentsTodayResponse.Message, "Today's Appointments", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Response getAppointmentsExpired = appointmentsService.GetAppointmentsExpired();
            if (getAppointmentsExpired.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("#", typeof(int)));
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Customer", typeof(string)));
                dt.Columns.Add(new DataColumn("Title", typeof(string)));
                dt.Columns.Add(new DataColumn("Schedule", typeof(string)));

                List<Appointment> appointments = getAppointmentsExpired.Payload!;
                int rowNum = 1;
                foreach (Appointment appointment in appointments)
                {
                    Response getCustomerResponse = ownersService.GetOwner(appointment.CustomerId);
                    Owner? customer = getCustomerResponse.Payload;

                    string title = appointment.Title;
                    string ownerName = customer != null ? customer.FirstName + " " + customer.LastName : "";
                    string schedule = appointment.Schedule.ToString("MMMM dd, yyyy hh:mm:ss tt");

                    DataRow dr = dt.NewRow();
                    dr["#"] = rowNum++;
                    dr["Id"] = appointment.Id;
                    dr["Customer"] = ownerName;
                    dr["Title"] = title;
                    dr["Schedule"] = schedule;
                    dt.Rows.Add(dr);
                }

                DgvExpiredAppointments.DataSource = dt;
                DgvExpiredAppointments.Columns["Id"].Visible = false;
            }
            else
            {
                MessageBox.Show(getAppointmentsExpired.Message, "Expired Appointments", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            Response getExpiredProducts = productsService.GetExpiredProducts();
            if (getExpiredProducts.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("#", typeof(int)));
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Name", typeof(string)));
                dt.Columns.Add(new DataColumn("Category", typeof(string)));
                dt.Columns.Add(new DataColumn("Expiration", typeof(string)));

                List<Product> products = getExpiredProducts.Payload!;
                int rowNum = 1;
                foreach (Product product in products)
                {
                    Response getCategoryNameResponse = categoriesService.GetCategoryNameById(product.CategoryId);
                    string categoryName = getCategoryNameResponse.Status ? getCategoryNameResponse.Payload! : "";
                    string name = product.Name;
                    string description = product.Description;
                    decimal price = product.Price;
                    int quantity = product.Quantity;
                    string? expiration = product.ExpiredAt!.Value.ToString("MMM dd, yyyy");

                    DataRow dr = dt.NewRow();
                    dr["#"] = rowNum++;
                    dr["Id"] = product.Id;
                    dr["Name"] = name;
                    dr["Category"] = categoryName;
                    dr["Expiration"] = expiration;
                    dt.Rows.Add(dr);
                }

                DgvExpiredProducts.DataSource = dt;
                DgvExpiredProducts.Columns["Id"].Visible = false;
            }
            else
            {
                MessageBox.Show(getExpiredProducts.Message, "Expired Products", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Response getOutOfStockProducts = productsService.GetOutOfStockProducts();
            if (getOutOfStockProducts.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("#", typeof(int)));
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Name", typeof(string)));
                dt.Columns.Add(new DataColumn("Category", typeof(string)));

                List<Product> products = getOutOfStockProducts.Payload!;
                int rowNum = 1;
                foreach (Product product in products)
                {
                    Response getCategoryNameResponse = categoriesService.GetCategoryNameById(product.CategoryId);
                    string categoryName = getCategoryNameResponse.Status ? getCategoryNameResponse.Payload! : "";
                    string name = product.Name;
                    string description = product.Description;
                    decimal price = product.Price;
                    int quantity = product.Quantity;

                    DataRow dr = dt.NewRow();
                    dr["#"] = rowNum++;
                    dr["Id"] = product.Id;
                    dr["Name"] = name;
                    dr["Category"] = categoryName;
                    dt.Rows.Add(dr);
                }

                DgvOutOfStockProducts.DataSource = dt;
                DgvOutOfStockProducts.Columns["Id"].Visible = false;
            }
            else
            {
                MessageBox.Show(getOutOfStockProducts.Message, "Out of Stock Products", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void RefreshServicesTable(string filter = "")
        {
            Response getServicesResponse = servicesService.GetServices();

            if (getServicesResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("#", typeof(int)));
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Name", typeof(string)));
                dt.Columns.Add(new DataColumn("Description", typeof(string)));
                dt.Columns.Add(new DataColumn("Price", typeof(string)));

                List<Service> services = getServicesResponse.Payload!;
                int rowNum = 1;
                foreach (Service service in services)
                {
                    string name = service.Name;
                    string description = service.Description;
                    decimal price = service.Price;

                    bool toAdd = filter == "" || (name.ToUpper().Contains(filter) || description.ToUpper().Contains(filter) || price.ToString().Contains(filter));

                    if (toAdd)
                    {
                        DataRow dr = dt.NewRow();
                        dr["#"] = rowNum++;
                        dr["Id"] = service.Id;
                        dr["Name"] = name;
                        dr["Description"] = description;
                        dr["Price"] = $"{price:n}";
                        dt.Rows.Add(dr);
                    }
                }

                DgvServices.DataSource = dt;
                DgvServices.Columns["Id"].Visible = false;

            }
            else
            {
                MessageBox.Show(getServicesResponse.Message, "Services", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            PicUser.Image = currentUser.Role == 'A' ? (currentUser.Gender == 'M' ? Properties.Resources.admin_male : Properties.Resources.admin_female) : (currentUser.Gender == 'M' ? Properties.Resources.cashier_male : Properties.Resources.cashier_female);

            TxtUserFullName.Text = string.Format("{0} {1}", currentUser.FirstName, currentUser.LastName);
            TxtUserRole.Text = currentUser.Role == 'A' ? "ADMIN" : "CASHIER";

            PnlAdminNav.Visible = currentUser.Role == 'A';
            PnlCashierNav.Visible = currentUser.Role == 'C';

            DgvCashiers.MultiSelect = false;
            DgvCategories.MultiSelect = false;
            DgvOrders.MultiSelect = false;
            DgvOwners.MultiSelect = false;
            DgvPets.MultiSelect = false;
            DgvProducts.MultiSelect = false;
            DgvServices.MultiSelect = false;

            DgvTodaysAppointments.MultiSelect = false;
            DgvExpiredAppointments.MultiSelect = false;
            DgvExpiredProducts.MultiSelect = false;
            DgvOutOfStockProducts.MultiSelect = false;

            if (currentUser.Role == 'A')
            {
                Response getExpiredAppointmentsResponse = appointmentsService.GetExpiredAppointments();
                if (getExpiredAppointmentsResponse.Status)
                {
                    List<Appointment> expiredAppointments = getExpiredAppointmentsResponse.Payload!;

                    string updatedAt = DateTime.Now.ToString("yyyy-MM-dd H:mm:ss");
                    foreach (Appointment appointment in expiredAppointments)
                    {
                        appointmentsService.ExpireAppointment(appointment.Id, updatedAt);
                    }
                }
                else
                {
                    MessageBox.Show(getExpiredAppointmentsResponse.Message, "Expired Appointments", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                RefreshHomeTables();
                PnlHomeAdmin.Visible = true;
                BtnHomeAdmin.BackColor = Color.Aquamarine;
                PnlHomeAdmin.Visible = true;
            }
            else
            {
                RefreshOrdersTable();
                PnlHomeAdmin.Visible = false;
                BtnOrdersCashier.BackColor = Color.Aquamarine;
                PnlOrders.Visible = true;

                //BtnUpdateOrder.Visible = false;
                //BtnViewOrder.Location = new Point(BtnNewOrder.Location.X, BtnNewOrder.Location.Y);
                //BtnNewOrder.Location = new Point(BtnUpdateOrder.Location.X, BtnUpdateOrder.Location.Y);
                BtnViewOrder.Enabled = DgvOrders.Rows.Count > 0;

                LblFrom.Visible = false;
                LblTo.Visible = false;
                DtpOrdersFrom.Visible = false;
                DtpOrdersTo.Enabled = false;
            }


        }

        private void BtnLogoutAdmin_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure to Logout?", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                ToRefreshHome = true;
                ToRefreshCashiersTable = true;
                ToRefreshOwnersTable = true;
                ToRefreshPetsTable = true;
                ToRefreshProductsTable = true;
                ToRefreshCategoriesTable = true;
                ToRefreshOrdersTable = true;

                Close();

                LoginForm loginForm = new();
                loginForm.Show();
            }
        }

        private void BtnHomeAdmin_Click(object sender, EventArgs e)
        {
            if (ToRefreshHome)
            {
                HandleNavigation("home");
            }
        }

        private void BtnCashiersAdmin_Click(object sender, EventArgs e)
        {

            if (ToRefreshCashiersTable)
            {
                HandleNavigation("cashiers");

                BtnUpdateCashier.Enabled = DgvCashiers.Rows.Count > 0;
                BtnDeleteCashier.Enabled = DgvCashiers.Rows.Count > 0;

            }

        }

        private void BtnPetsAdmin_Click(object sender, EventArgs e)
        {
            if (ToRefreshPetsTable)
            {
                HandleNavigation("pets");

                BtnUpdatePet.Enabled = DgvPets.Rows.Count > 0;
                BtnDeletePet.Enabled = DgvPets.Rows.Count > 0;
                BtnActivitiesPet.Enabled = DgvPets.Rows.Count > 0;

            }
        }

        private void BtnHomeCashier_Click(object sender, EventArgs e)
        {
            if (ToRefreshHome)
            {
                HandleNavigation("home");
            }
        }

        private void BtnOwnersAdmin_Click(object sender, EventArgs e)
        {
            if (ToRefreshOwnersTable)
            {
                HandleNavigation("owners");

                BtnUpdateOwner.Enabled = DgvOwners.Rows.Count > 0;
                BtnDeleteOwner.Enabled = DgvOwners.Rows.Count > 0;
            }
        }

        private void BtnProductsAdmin_Click(object sender, EventArgs e)
        {
            if (ToRefreshProductsTable)
            {
                HandleNavigation("products");

                BtnUpdateProduct.Enabled = DgvProducts.Rows.Count > 0;
                BtnDeleteProduct.Enabled = DgvProducts.Rows.Count > 0;
            }
        }

        private void BtnCategoriesAdmin_Click(object sender, EventArgs e)
        {
            if (ToRefreshCategoriesTable)
            {
                HandleNavigation("categories");

                GrpBoxCategory.Enabled = false;

                BtnUpdateCategory.Enabled = DgvCategories.Rows.Count > 0;
                BtnDeleteCategory.Enabled = DgvCategories.Rows.Count > 0;
            }
        }

        private void BtnNewCashier_Click(object sender, EventArgs e)
        {
            NewCashierForm newCashierForm = new();
            newCashierForm.ShowDialog();

            if (ToRefreshCashiersTable)
            {
                RefreshCashiersTable();

                BtnUpdateCashier.Enabled = true;
                BtnDeleteCashier.Enabled = true;

                ToRefreshCashiersTable = false;

                TxtSearchCashier.Text = string.Empty;
            }
        }

        private void BtnUpdateCashier_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvCashiers.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvCashiers.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            UpdateCashierForm updateCashierForm = new(id);
            updateCashierForm.ShowDialog();

            if (ToRefreshCashiersTable)
            {
                RefreshCashiersTable();

                ToRefreshCashiersTable = false;

                TxtSearchCashier.Text = string.Empty;
            }

        }

        private void BtnDeleteCashier_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvCashiers.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvCashiers.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            DialogResult dialogResult = MessageBox.Show("Are you sure to delete this Cashier?", "Delete Cashier", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                Response deleteCashierResponse = cashiersService.DeleteCashier(id);
                if (deleteCashierResponse.Status)
                {
                    MessageBox.Show(deleteCashierResponse.Message, "Delete Cashier", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RefreshCashiersTable();

                    BtnUpdateCashier.Enabled = DgvCashiers.Rows.Count > 0;
                    BtnDeleteCashier.Enabled = DgvCashiers.Rows.Count > 0;

                    TxtSearchCashier.Text = string.Empty;
                }
                else
                {
                    MessageBox.Show(deleteCashierResponse.Message, "Delete Cashier", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnLogoutCashier_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure to Logout?", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                ToRefreshHome = true;
                ToRefreshCashiersTable = true;
                ToRefreshOwnersTable = true;
                ToRefreshPetsTable = true;
                ToRefreshProductsTable = true;
                ToRefreshCategoriesTable = true;
                ToRefreshOrdersTable = true;

                Close();

                LoginForm loginForm = new();
                loginForm.Show();
            }
        }

        private void BtnNewOwner_Click(object sender, EventArgs e)
        {
            NewOwnerForm newOwnerForm = new();
            newOwnerForm.ShowDialog();

            if (ToRefreshOwnersTable)
            {
                RefreshOwnersTable();

                BtnUpdateOwner.Enabled = true;
                BtnDeleteOwner.Enabled = true;

                ToRefreshOwnersTable = false;

                TxtSearchOwner.Text = string.Empty;
            }
        }

        private void BtnUpdateOwner_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvOwners.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvOwners.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            UpdateOwnerForm updateOwnerForm = new(id);
            updateOwnerForm.ShowDialog();

            if (ToRefreshOwnersTable)
            {
                RefreshOwnersTable();

                ToRefreshOwnersTable = false;

                TxtSearchOwner.Text = string.Empty;
            }
        }

        private void BtnDeleteOwner_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvOwners.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvOwners.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            // COUNT PETS
            Response countPetsResponse = petsService.CountPets(id);
            if (countPetsResponse.Status)
            {
                long petsCount = countPetsResponse.Payload;
                if (petsCount == 0)
                {
                    // COUNT ORDERS
                    Response countOrdersResponse = ordersService.CountOrderCustomer(id);
                    if (countOrdersResponse.Status)
                    {
                        long ordersCount = countOrdersResponse.Payload;
                        if (ordersCount == 0)
                        {
                            // COUNT APPOINTMENTS
                            Response countAppointmentsResponse = appointmentsService.CountAppointmentCustomer(id);
                            if (countAppointmentsResponse.Status)
                            {
                                long appointmentsCount = countAppointmentsResponse.Payload;
                                if (appointmentsCount == 0)
                                {
                                    DialogResult dialogResult = MessageBox.Show("Are you sure to delete this Pet Owner?", "Delete Pet Owner", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                    if (dialogResult == DialogResult.Yes)
                                    {
                                        Response deleteOwnerResponse = ownersService.DeleteOwner(id);
                                        if (deleteOwnerResponse.Status)
                                        {
                                            MessageBox.Show(deleteOwnerResponse.Message, "Delete Pet Owner", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            RefreshOwnersTable();

                                            BtnUpdateOwner.Enabled = DgvOwners.Rows.Count > 0;
                                            BtnDeleteOwner.Enabled = DgvOwners.Rows.Count > 0;

                                            TxtSearchOwner.Text = string.Empty;
                                        }
                                        else
                                        {
                                            MessageBox.Show(deleteOwnerResponse.Message, "Delete Pet Owner", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(string.Format("Cannot delete this Owner. This Owner has {0} Appointment{1}.", appointmentsCount, appointmentsCount > 1 ? "s" : ""), "Delete Pet Owner", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }
                            }
                            else
                            {
                                MessageBox.Show(countOrdersResponse.Message, "Delete Pet Owner", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show(string.Format("Cannot delete this Owner. This Owner has {0} Order{1}.", ordersCount, ordersCount > 1 ? "s" : ""), "Delete Pet Owner", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                    else
                    {
                        MessageBox.Show(countOrdersResponse.Message, "Delete Pet Owner", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show(string.Format("Cannot delete this Owner. This Owner has {0} Pet{1}.", petsCount, petsCount > 1 ? "s" : ""), "Delete Pet Owner", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
            {
                MessageBox.Show(countPetsResponse.Message, "Delete Pet Owner", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnNewPet_Click(object sender, EventArgs e)
        {
            NewPetForm newPetForm = new();
            newPetForm.ShowDialog();

            if (ToRefreshPetsTable)
            {
                RefreshPetsTable();

                BtnUpdatePet.Enabled = true;
                BtnDeletePet.Enabled = true;

                ToRefreshPetsTable = false;

                TxtSearchPet.Text = string.Empty;
            }
        }

        private void BtnUpdatePet_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvPets.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvPets.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            UpdatePetForm updatePetForm = new(id);
            updatePetForm.ShowDialog();

            if (ToRefreshPetsTable)
            {
                RefreshPetsTable();

                ToRefreshPetsTable = false;

                TxtSearchPet.Text = string.Empty;
            }
        }

        private void TxtSearchPet_TextChanged(object sender, EventArgs e)
        {
            RefreshPetsTable(TxtSearchPet.Text.Trim().ToUpper());

            BtnUpdatePet.Enabled = DgvPets.Rows.Count > 0;
            BtnDeletePet.Enabled = DgvPets.Rows.Count > 0;
        }

        private void TxtSearchOwner_TextChanged(object sender, EventArgs e)
        {
            RefreshOwnersTable(TxtSearchOwner.Text.Trim().ToUpper());

            BtnUpdateOwner.Enabled = DgvOwners.Rows.Count > 0;
            BtnDeleteOwner.Enabled = DgvOwners.Rows.Count > 0;
        }

        private void BtnDeletePet_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvPets.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvPets.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            Response countPetActivitiesResponse = petActivityService.CountPetActivities(id);

            if (countPetActivitiesResponse.Status)
            {
                long count = countPetActivitiesResponse.Payload!;

                if (count == 0)
                {
                    DialogResult dialogResult = MessageBox.Show("Are you sure to delete this Pet?", "Delete Pet", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dialogResult == DialogResult.Yes)
                    {
                        Response deletePetResponse = petsService.DeletePet(id);
                        if (deletePetResponse.Status)
                        {
                            MessageBox.Show(deletePetResponse.Message, "Delete Pet", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            RefreshPetsTable();

                            BtnUpdatePet.Enabled = DgvPets.Rows.Count > 0;
                            BtnDeletePet.Enabled = DgvPets.Rows.Count > 0;
                        }
                        else
                        {
                            MessageBox.Show(deletePetResponse.Message, "Delete Pet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show(string.Format("Cannot delete this Pet. This Pet has {0} activit{1}.", count, count > 1 ? "ies" : "y"), "Delete Pet", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show(countPetActivitiesResponse.Message, "Delete Pet", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TxtSearchCashier_TextChanged(object sender, EventArgs e)
        {
            RefreshCashiersTable(TxtSearchCashier.Text.Trim().ToUpper());

            BtnUpdateCashier.Enabled = DgvCashiers.Rows.Count > 0;
            BtnDeleteCashier.Enabled = DgvCashiers.Rows.Count > 0;
        }

        private void BtnNewCategory_Click(object sender, EventArgs e)
        {
            GrpBoxCategory.Enabled = true;

            BtnNewCategory.Enabled = false;
            BtnUpdateCategory.Enabled = false;
            BtnDeleteCategory.Enabled = false;

            GrpBoxCategory.Text = "NEW CATEGORY";
        }

        private void BtnCancelCategory_Click(object sender, EventArgs e)
        {
            TxtCategory.Text = "";
            GrpBoxCategory.Enabled = false;
            BtnNewCategory.Enabled = true;
            BtnUpdateCategory.Enabled = DgvCategories.Rows.Count > 0;
            BtnDeleteCategory.Enabled = DgvCategories.Rows.Count > 0;

            GrpBoxCategory.Text = string.Empty;

            categoryId = 0;

        }

        private void BtnSaveCategory_Click(object sender, EventArgs e)
        {
            string category = TxtCategory.Text.Trim();
            int expiration = ChkExpiration.Checked ? 1 : 0;

            if (category == string.Empty)
            {
                MessageBox.Show("Category is required.", string.Format("{0} Category", categoryId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Response checkCategoryResponse = categoriesService.CheckCategory(category, categoryId);
                if (checkCategoryResponse.Status)
                {
                    Response createUpdateCategoryResponse = categoriesService.CreateUpdateCategory(category, expiration, categoryId);
                    if (createUpdateCategoryResponse.Status)
                    {
                        MessageBox.Show(createUpdateCategoryResponse.Message, string.Format("{0} Category", categoryId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Information);
                        RefreshCategoriesTable();

                        TxtCategory.Text = string.Empty;
                        ChkExpiration.Checked = false;
                        GrpBoxCategory.Enabled = false;
                        BtnNewCategory.Enabled = true;
                        BtnUpdateCategory.Enabled = true;
                        BtnDeleteCategory.Enabled = true;

                        TxtSearchCategory.Text = string.Empty;
                    }
                    else
                    {
                        MessageBox.Show(createUpdateCategoryResponse.Message, string.Format("{0} Category", categoryId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show(checkCategoryResponse.Message, string.Format("{0} Category", categoryId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnUpdateCategory_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvCategories.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvCategories.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);
            string name = Convert.ToString(selectedRow.Cells["Name"].Value)!;
            string hasExpiration = Convert.ToString(selectedRow.Cells["Has Expiration"].Value)!;

            GrpBoxCategory.Enabled = true;

            BtnNewCategory.Enabled = false;
            BtnUpdateCategory.Enabled = false;
            BtnDeleteCategory.Enabled = false;

            GrpBoxCategory.Text = "UPDATE CATEGORY";

            categoryId = id;
            TxtCategory.Text = name;
            ChkExpiration.Checked = hasExpiration == "Yes";
        }

        private void BtnDeleteCategory_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvCategories.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvCategories.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            Response productsCountResponse = productsService.CountProductsByCategory(id);

            if (productsCountResponse.Status)
            {
                long productsCount = productsCountResponse.Payload!;

                if (productsCount == 0)
                {
                    DialogResult dialogResult = MessageBox.Show("Are you sure to delete this Category?", "Delete Category", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dialogResult == DialogResult.Yes)
                    {
                        Response deleteCategoryResponse = categoriesService.DeleteCategory(id);
                        if (deleteCategoryResponse.Status)
                        {
                            MessageBox.Show(deleteCategoryResponse.Message, "Delete Category", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            RefreshCategoriesTable();

                            TxtCategory.Text = "";
                            GrpBoxCategory.Enabled = false;
                            BtnNewCategory.Enabled = true;
                            BtnUpdateCategory.Enabled = DgvCategories.Rows.Count > 0;
                            BtnDeleteCategory.Enabled = DgvCategories.Rows.Count > 0; ;

                            TxtSearchCategory.Text = string.Empty;
                        }
                        else
                        {
                            MessageBox.Show(deleteCategoryResponse.Message, "Delete Category", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show(string.Format("Cannot delete this Category. This Category has {0} Product{1}.", productsCount, productsCount > 1 ? "s" : ""), "Delete Category", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
            {
                MessageBox.Show(productsCountResponse.Message, "Delete Category", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void TxtSearchCategory_TextChanged(object sender, EventArgs e)
        {
            RefreshCategoriesTable(TxtSearchCategory.Text.Trim().ToUpper());

            BtnUpdateCategory.Enabled = DgvCategories.Rows.Count > 0;
            BtnDeleteCategory.Enabled = DgvCategories.Rows.Count > 0;
        }

        private void BtnNewProduct_Click(object sender, EventArgs e)
        {
            NewProductForm newProductForm = new();
            newProductForm.ShowDialog();

            if (ToRefreshProductsTable)
            {
                RefreshProductsTable();

                BtnUpdateProduct.Enabled = true;
                BtnDeleteProduct.Enabled = true;

                ToRefreshProductsTable = false;

                TxtSearchProduct.Text = string.Empty;
            }
        }

        private void TxtSearchProduct_TextChanged(object sender, EventArgs e)
        {
            RefreshProductsTable(TxtSearchProduct.Text.Trim().ToUpper());

            BtnUpdateProduct.Enabled = DgvProducts.Rows.Count > 0;
            BtnDeleteProduct.Enabled = DgvProducts.Rows.Count > 0;
        }

        private void BtnUpdateProduct_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvProducts.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvProducts.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            UpdateProductForm updateProductForm = new(id);
            updateProductForm.ShowDialog();

            if (ToRefreshProductsTable)
            {
                RefreshProductsTable();

                ToRefreshProductsTable = false;

                TxtSearchProduct.Text = string.Empty;
            }
        }

        private void BtnDeleteProduct_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvServices.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvServices.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            // Count orders
            Response countOrderItemsResponse = ordersService.CountOrderItems(id, 'S');

            if (countOrderItemsResponse.Status)
            {
                long count = countOrderItemsResponse.Payload!;

                if (count == 0)
                {
                    DialogResult dialogResult = MessageBox.Show("Are you sure to delete this Product?", "Delete Product", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dialogResult == DialogResult.Yes)
                    {
                        Response deleteProductResponse = productsService.DeleteProduct(id);
                        if (deleteProductResponse.Status)
                        {
                            MessageBox.Show(deleteProductResponse.Message, "Delete Product", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            RefreshProductsTable();

                            BtnUpdateProduct.Enabled = DgvCategories.Rows.Count > 0;
                            BtnDeleteProduct.Enabled = DgvCategories.Rows.Count > 0; ;

                            TxtSearchProduct.Text = string.Empty;
                        }
                        else
                        {
                            MessageBox.Show(deleteProductResponse.Message, "Delete Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Connot delete this Prodcut. This product has record in Orders.", "Delete Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else
            {
                MessageBox.Show(countOrderItemsResponse.Message, "Delete Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnOrdersCashier_Click(object sender, EventArgs e)
        {
            if (ToRefreshOrdersTable)
            {
                HandleNavigation("orders");
                // BUTTONS
                //BtnUpdateOrder.Visible = false;
                //BtnViewOrder.Location = new Point(BtnNewOrder.Location.X, BtnNewOrder.Location.Y);
                //BtnNewOrder.Location = new Point(BtnUpdateOrder.Location.X, BtnUpdateOrder.Location.Y);
                BtnViewOrder.Enabled = DgvOrders.Rows.Count > 0;

                LblFrom.Visible = false;
                LblTo.Visible = false;
                DtpOrdersFrom.Visible = false;
                DtpOrdersTo.Enabled = false;
            }
        }

        private void BtnNewOrder_Click(object sender, EventArgs e)
        {
            OrderForm newOrderForm = new(currentUser, 0, "CREATE");
            newOrderForm.ShowDialog();

            if (ToRefreshOrdersTable)
            {
                RefreshOrdersTable();

                //BtnUpdateOrder.Enabled = true;
                BtnViewOrder.Enabled = true;

                ToRefreshOrdersTable = false;

                TxtSearchOrder.Text = string.Empty;
            }
        }

        private void TxtSearchOrder_TextChanged(object sender, EventArgs e)
        {
            RefreshOrdersTable(TxtSearchOrder.Text.Trim().ToUpper());
        }

        private void BtnProductsCashier_Click(object sender, EventArgs e)
        {
            if (ToRefreshProductsTable)
            {
                HandleNavigation("products");
                // BUTTONS
                BtnNewProduct.Visible = false;
                BtnUpdateProduct.Visible = false;
                BtnDeleteProduct.Visible = false;
            }
        }

        private void BtnViewOrder_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvOrders.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvOrders.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            OrderForm orderForm = new(currentUser, id, "VIEW");
            orderForm.ShowDialog();

            if (ToRefreshOrdersTable)
            {
                RefreshOrdersTable();

                BtnViewOrder.Enabled = true;

                ToRefreshOrdersTable = false;
                TxtSearchOrder.Text = string.Empty;
            }
        }

        private void BtnOrdersAdmin_Click(object sender, EventArgs e)
        {
            if (ToRefreshOrdersTable)
            {
                DtpOrdersFrom.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                DtpOrdersTo.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month));

                HandleNavigation("orders");
                BtnViewOrder.Enabled = DgvOrders.Rows.Count > 0;
            }
        }

        private void DtpOrdersFrom_ValueChanged(object sender, EventArgs e)
        {
            RefreshOrdersTable();
        }

        private void DtpOrdersTo_ValueChanged(object sender, EventArgs e)
        {
            RefreshOrdersTable();
        }

        private void BtnActivitiesPet_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvPets.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvPets.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            PetActivitiesForm petActivitiesForm = new(id);
            petActivitiesForm.ShowDialog();

        }

        private void BtnAppointmentsAdmin_Click(object sender, EventArgs e)
        {
            if (ToRefreshAppointmentsTable)
            {
                DtpAppointmentsFrom.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                DtpAppointmentsTo.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month));

                HandleNavigation("appointments");

                BtnUpdateAppointment.Enabled = DgvAppointments.Rows.Count > 0;
                BtnDeleteAppointment.Enabled = DgvAppointments.Rows.Count > 0;
            }
        }

        private void BtnNewAppointment_Click(object sender, EventArgs e)
        {
            AppointmentForm appointmentForm = new(0);
            appointmentForm.ShowDialog();

            if (ToRefreshAppointmentsTable)
            {
                RefreshAppointmentsTable();

                BtnUpdateAppointment.Enabled = true;
                BtnDeleteAppointment.Enabled = true;

                ToRefreshAppointmentsTable = false;

                TxtSearchAppointment.Text = string.Empty;
            }
        }

        private void TxtSearchAppointment_TextChanged(object sender, EventArgs e)
        {
            RefreshAppointmentsTable(TxtSearchAppointment.Text.Trim().ToUpper());
        }

        private void BtnUpdateAppointment_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvAppointments.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvAppointments.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            AppointmentForm appointmentForm = new(id);
            appointmentForm.ShowDialog();

            if (ToRefreshAppointmentsTable)
            {
                RefreshAppointmentsTable();

                BtnUpdateAppointment.Enabled = true;
                BtnDeleteAppointment.Enabled = true;

                ToRefreshAppointmentsTable = false;

                TxtSearchAppointment.Text = string.Empty;
            }
        }

        private void DtpAppointmentsFrom_ValueChanged(object sender, EventArgs e)
        {
            RefreshAppointmentsTable();
        }

        private void DtpAppointmentsTo_ValueChanged(object sender, EventArgs e)
        {
            RefreshAppointmentsTable();
        }

        private void BtnDeleteAppointment_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvAppointments.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvAppointments.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);
            string status = Convert.ToString(selectedRow.Cells["Status"].Value)!;

            if (status.ToLower() != "completed")
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure to delete this Appointment?", "Delete Appointment", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.Yes)
                {
                    Response deleteAppointmentResponse = appointmentsService.DeleteAppointment(id);
                    if (deleteAppointmentResponse.Status)
                    {
                        MessageBox.Show(deleteAppointmentResponse.Message, "Delete Appointment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        RefreshAppointmentsTable();

                        BtnUpdateAppointment.Enabled = DgvAppointments.Rows.Count > 0;
                        BtnDeleteAppointment.Enabled = DgvAppointments.Rows.Count > 0;
                    }
                    else
                    {
                        MessageBox.Show(deleteAppointmentResponse.Message, "Delete Appointment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Cannot delete this Appointment. This Appointment is already completed.", "Delete Appointment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnUpdateOrder_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvOrders.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvOrders.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            OrderForm orderForm = new(currentUser, id, "UPDATE");
            orderForm.ShowDialog();

            if (ToRefreshOrdersTable)
            {
                RefreshOrdersTable();

                //BtnUpdateOrder.Enabled = true;
                ToRefreshOrdersTable = false;

            }

        }


        private void BtnServicesAdmin_Click(object sender, EventArgs e)
        {
            if (ToRefreshServicesTable)
            {
                HandleNavigation("services");

                BtnUpdateService.Enabled = DgvServices.Rows.Count > 0;
                BtnDeleteService.Enabled = DgvServices.Rows.Count > 0;
            }
        }

        private void BtnNewService_Click(object sender, EventArgs e)
        {
            ServiceForm serviceForm = new();
            serviceForm.ShowDialog();

            if (ToRefreshServicesTable)
            {
                RefreshServicesTable();

                BtnUpdateService.Enabled = true;
                BtnDeleteService.Enabled = true;

                ToRefreshServicesTable = false;

                TxtSearchService.Text = string.Empty;
            }
        }

        private void TxtSearchService_TextChanged(object sender, EventArgs e)
        {
            RefreshServicesTable(TxtSearchService.Text.Trim().ToUpper());
        }

        private void BtnUpdateService_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvServices.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvServices.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            ServiceForm serviceForm = new(id);
            serviceForm.ShowDialog();

            if (ToRefreshServicesTable)
            {
                RefreshServicesTable();

                ToRefreshServicesTable = false;

                TxtSearchService.Text = string.Empty;
            }
        }

        private void BtnDeleteService_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvServices.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvServices.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            // Count orders
            Response countOrderItemsResponse = ordersService.CountOrderItems(id, 'S');

            if (countOrderItemsResponse.Status)
            {
                long count = countOrderItemsResponse.Payload!;

                if (count == 0)
                {
                    DialogResult dialogResult = MessageBox.Show("Are you sure to delete this Service?", "Delete Service", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dialogResult == DialogResult.Yes)
                    {
                        Response deleteServiceResponse = servicesService.DeleteService(id);
                        if (deleteServiceResponse.Status)
                        {
                            MessageBox.Show(deleteServiceResponse.Message, "Delete Service", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            RefreshProductsTable();

                            BtnUpdateProduct.Enabled = DgvCategories.Rows.Count > 0;
                            BtnDeleteProduct.Enabled = DgvCategories.Rows.Count > 0; ;

                            TxtSearchProduct.Text = string.Empty;
                        }
                        else
                        {
                            MessageBox.Show(deleteServiceResponse.Message, "Delete Service", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Connot delete this Service. This service has record in Orders.", "Delete Service", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else
            {
                MessageBox.Show(countOrderItemsResponse.Message, "Delete Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnServicesCashier_Click(object sender, EventArgs e)
        {
            if (ToRefreshServicesTable)
            {
                HandleNavigation("services");

                BtnNewService.Visible = false;
                BtnUpdateService.Visible = false;
                BtnDeleteService.Visible = false;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}