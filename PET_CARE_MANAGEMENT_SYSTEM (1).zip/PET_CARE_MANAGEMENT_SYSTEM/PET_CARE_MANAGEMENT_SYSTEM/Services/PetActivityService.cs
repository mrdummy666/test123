﻿using MySql.Data.MySqlClient;
using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Utils;
using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PET_CARE_MANAGEMENT_SYSTEM.Services
{
    public class PetActivityService
    {
        public DBConnect db;

        public PetActivityService() => db = new DBConnect();

        // GET PET ACTIVITIES
        public Response GetPetActivities(int petId)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT * FROM pet_activities WHERE petId = {0} AND status = 1 ORDER BY createdAt DESC", petId);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<PetActivity> petActivities = new();

                while (dataReader.Read())
                {
                    petActivities.Add(new PetActivity
                    {
                        Id = (int)dataReader["id"],
                        PetId = (int)dataReader["petId"],
                        Activity = (string)dataReader["activity"],
                        //Schedule = Convert.ToDateTime(dataReader["schedule"]),
                        CreatedAt = Convert.ToDateTime(dataReader["createdAt"]),
                        UpdatedAt = Convert.ToDateTime(dataReader["updatedAt"]),
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = petActivities
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CREATE PET ACTIVITY
        public Response CreatePetActivity(int petId, string activity, string createdAt, string updatedAt)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("INSERT INTO pet_activities (petId, activity, createdAt, updatedAt, Status) " +
                    "VALUES({0}, '{1}', '{2}', '{3}', 1)", petId, activity, createdAt, updatedAt);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();


                return new Response()
                {
                    Status = true,
                    Message = "New Pet Activity Created!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET PET ACTIVITY
        public Response GetPetActivity(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT * FROM pet_activities WHERE id = {0}", id);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                PetActivity? petActivity = null;

                while (dataReader.Read())
                {
                    petActivity = new PetActivity
                    {
                        Id = (int)dataReader["id"],
                        PetId = (int)dataReader["petId"],
                        //Schedule = Convert.ToDateTime(dataReader["schedule"]),
                        Activity = (string)dataReader["activity"],
                        CreatedAt = Convert.ToDateTime(dataReader["createdAt"]),
                        UpdatedAt = Convert.ToDateTime(dataReader["updatedAt"]),
                        Status = (int)dataReader["status"],
                    };
                }

                dataReader.Close();

                db.connection.Close();

                if (petActivity != null)
                {
                    return new Response()
                    {
                        Status = true,
                        Message = "",
                        Payload = petActivity,
                    };
                }
                else
                {
                    return new Response()
                    {
                        Status = false,
                        Message = "Something went wrong.",
                        Payload = null,
                    };
                }
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // UPDATE PET ACTIVITY
        public Response UpdatePetActivity(int petActivityId, string activity, string updatedAt)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("UPDATE pet_activities SET activity = '{0}', updatedAt = '{1}' WHERE id = {2}",
                    activity, updatedAt, petActivityId);
                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();


                return new Response()
                {
                    Status = true,
                    Message = "Pet Activity Successfully Updated!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // DELETE PET ACTIVITY
        public Response DeletePetActivity(int petActivityId)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("UPDATE pet_activities SET status = 0 WHERE id = {0}", petActivityId);
                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();


                return new Response()
                {
                    Status = true,
                    Message = "Pet Activity Successfully Deleted!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // COUNT PET ACTIVITY
        public Response CountPetActivities(int petId) {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT COUNT(*) AS CountPetActivities FROM pet_activities WHERE petId = {0} AND status != 0", petId);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                long countPetActivities = 0;

                while (dataReader.Read())
                {
                    countPetActivities = (long)dataReader["CountPetActivities"];
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = countPetActivities
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        //// GET ALL EXPIRED PET ACTIVITIES
        //public Response GetExpiredPetActivities ()
        //{
        //    try
        //    {
        //        db.connection.Open();

        //        string query = string.Format("SELECT * FROM pet_activities WHERE status = 1 AND schedule <= NOW()");
        //        MySqlCommand cmd = new(query, db.connection);
        //        MySqlDataReader dataReader = cmd.ExecuteReader();

        //        List<PetActivity> petActivities = new();

        //        while (dataReader.Read())
        //        {
        //            petActivities.Add(new PetActivity
        //            {
        //                Id = (int)dataReader["id"],
        //                PetId = (int)dataReader["petId"],
        //                Activity = (string)dataReader["activity"],
        //                Schedule = Convert.ToDateTime(dataReader["schedule"]),
        //                CreatedAt = Convert.ToDateTime(dataReader["createdAt"]),
        //                UpdatedAt = Convert.ToDateTime(dataReader["updatedAt"]),
        //                Status = (int)dataReader["status"],
        //            });
        //        }

        //        dataReader.Close();

        //        db.connection.Close();

        //        return new Response()
        //        {
        //            Status = true,
        //            Message = "",
        //            Payload = petActivities
        //        };
        //    }
        //    catch (Exception ex)
        //    {
        //        db.connection.Close();

        //        return new Response()
        //        {
        //            Status = false,
        //            Message = ex.Message,
        //            Payload = null
        //        };
        //    }
        //}

        //// EXPIRE PET ACTIVITY
        //public Response ExpirePetActivity(int petActivityId, string updatedAt)
        //{
        //    try
        //    {
        //        db.connection.Open();

        //        string query = string.Format("UPDATE pet_activities SET updatedAt = '{0}', status = 3 WHERE id = {1}", updatedAt, petActivityId);
        //        MySqlCommand cmd = new(string.Format(query), db.connection);
        //        cmd.ExecuteNonQuery();

        //        db.connection.Close();


        //        return new Response()
        //        {
        //            Status = true,
        //            Message = "Pet Activity Successfully Updated!",
        //            Payload = null
        //        };
        //    }
        //    catch (Exception ex)
        //    {
        //        db.connection.Close();

        //        return new Response()
        //        {
        //            Status = false,
        //            Message = ex.Message,
        //            Payload = null
        //        };
        //    }
        //}

    }
}
