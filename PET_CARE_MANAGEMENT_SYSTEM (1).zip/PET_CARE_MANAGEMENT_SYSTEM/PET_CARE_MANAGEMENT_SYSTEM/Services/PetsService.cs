﻿using MySql.Data.MySqlClient;
using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PET_CARE_MANAGEMENT_SYSTEM.Services
{
    public class PetsService
    {
        public DBConnect db;
        public PetsService() => db = new DBConnect();

        // GET PETS
        public Response GetPets()
        {
            try
            {
                db.connection.Open();

                string query = "SELECT * FROM pets WHERE status = 1";
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<Pet> pets = new();

                while (dataReader.Read())
                {
                    pets.Add(new Pet
                    {
                        Id = (int)dataReader["id"],
                        OwnerId = (int)dataReader["ownerId"],
                        PetName = (string)dataReader["petName"],
                        AnimalType = (string)dataReader["animalType"],
                        Breed = (string)dataReader["breed"],
                        Gender = dataReader["gender"].ToString()!.ToCharArray()[0],
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = pets
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET PET
        public Response GetPet(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT * FROM pets WHERE id = {0}", id);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                Pet? pet = null;

                while (dataReader.Read())
                {
                    pet = new Pet
                    {
                        Id = (int)dataReader["id"],
                        OwnerId = (int)dataReader["ownerId"],
                        PetName = (string)dataReader["petName"],
                        AnimalType = (string)dataReader["animalType"],
                        Breed = (string)dataReader["breed"],
                        Status = (int)dataReader["status"],
                    };
                }

                dataReader.Close();

                db.connection.Close();

                if (pet != null)
                {
                    return new Response()
                    {
                        Status = true,
                        Message = "",
                        Payload = pet,
                    };
                }
                else
                {
                    return new Response()
                    {
                        Status = false,
                        Message = "Something went wrong.",
                        Payload = null,
                    };
                }
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET OwnerName
        public Response GetOwnerName(int ownerId)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT firstName, lastName FROM owners WHERE id = {0}", ownerId);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                string ownerName = "";

                while (dataReader.Read())
                {
                    ownerName = (string)dataReader["firstName"] + " " + (string)dataReader["lastName"];
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = ownerName
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CREATE PET
        public Response CreatePet(int ownerId, string petName, string animalType, string breed, char gender)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("INSERT INTO pets (ownerId, petName, animalType, breed, gender, status) " +
                    "VALUES({0}, '{1}', '{2}', '{3}', '{4}', '{5}')", ownerId, petName, animalType, breed, gender, 1);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "New Pet Created!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // UPDATE PET
        public Response UpdatePet(int id, int ownerId, string petName, string animalType, string breed, char gender)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("UPDATE pets SET ownerId = {0}, petName = '{1}', animalType = '{2}', breed = '{3}', gender = '{4}' WHERE id = {5}",
                    ownerId, petName, animalType, breed, gender, id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Pet Successfully Updated!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // DELETE OWNER
        public Response DeletePet(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("Update pets SET status = 0 WHERE id = {0}", id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Pet Owner Successfully Deleted!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // COUNT PETS
        public Response CountPets(int ownerId)
        {
            try
            {
                db.connection.Open();
                string query = string.Format("SELECT COUNT(*) AS PetsCount FROM pets WHERE ownerId = {0} AND status = 1", ownerId);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                long petsCount = 0;

                while (dataReader.Read())
                {
                    petsCount = (long)dataReader["PetsCount"];
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = petsCount
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }
    }   
}
