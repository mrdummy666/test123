﻿using MySql.Data.MySqlClient;
using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace PET_CARE_MANAGEMENT_SYSTEM.Services
{
    public class AppointmentsService
    {
        public DBConnect db;

        public AppointmentsService() => db = new DBConnect();

        // GET APPOINTMENTS
        public Response GetAppointments()
        {
            try
            {
                db.connection.Open();

                string query = "SELECT * FROM appointments WHERE status != 0 ORDER BY schedule DESC";
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<Appointment> appointments = new();

                while (dataReader.Read())
                {
                    appointments.Add(new Appointment
                    {
                        Id = (int)dataReader["id"],
                        CustomerId = (int)dataReader["customerId"],
                        Details = (string)dataReader["details"],
                        Title = (string)dataReader["title"],
                        Schedule = Convert.ToDateTime(dataReader["schedule"]),
                        CreatedAt = Convert.ToDateTime(dataReader["createdAt"]),
                        UpdatedAt = Convert.ToDateTime(dataReader["updatedAt"]),
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = appointments
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CREATE APPOINTMENT
        public Response CreateAppointment(int customerId, string title, string details, string schedule, string createdAt, string updatedAt)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("INSERT INTO appointments (customerId, title, details, schedule, createdAt, updatedAt, Status) " +
                    "VALUES({0}, '{1}', '{2}', '{3}', '{4}', '{5}', {6})", customerId, title, details, schedule, createdAt, updatedAt, 1);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();


                db.connection.Close();


                return new Response()
                {
                    Status = true,
                    Message = "New Appointment Created!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET EXPIRED APPOINTMENTS
        public Response GetExpiredAppointments()
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT * FROM appointments WHERE status = 1 AND schedule <= NOW() ORDER BY schedule DESC");
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<Appointment> appointments = new();

                while (dataReader.Read())
                {
                    appointments.Add(new Appointment
                    {
                        Id = (int)dataReader["id"],
                        CustomerId = (int)dataReader["customerId"],
                        Title = (string)dataReader["title"],
                        Details = (string)dataReader["details"],
                        Schedule = Convert.ToDateTime(dataReader["schedule"]),
                        CreatedAt = Convert.ToDateTime(dataReader["createdAt"]),
                        UpdatedAt = Convert.ToDateTime(dataReader["updatedAt"]),
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = appointments
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // EXPIRE APPOINTMENT
        public Response ExpireAppointment(int appointmentId, string updatedAt)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("UPDATE appointments SET updatedAt = '{0}', status = 4 WHERE id = {1}", updatedAt, appointmentId);
                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // APPOINTMENT TODAY
        public Response GetAppointmentsToday()
        {
            try
            {
                db.connection.Open();
                string query = string.Format("SELECT * FROM appointments WHERE status = 1 AND schedule > NOW() AND CAST(schedule AS DATE) = CAST(NOW() AS DATE) ORDER BY schedule DESC");
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<Appointment> appointments = new();

                while (dataReader.Read())
                {
                    appointments.Add(new Appointment
                    {
                        Id = (int)dataReader["id"],
                        CustomerId = (int)dataReader["customerId"],
                        Title = (string)dataReader["title"],
                        Details = (string)dataReader["details"],
                        Schedule = Convert.ToDateTime(dataReader["schedule"]),
                        CreatedAt = Convert.ToDateTime(dataReader["createdAt"]),
                        UpdatedAt = Convert.ToDateTime(dataReader["updatedAt"]),
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = appointments
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET APPOINTMENTS EXPIRED
        public Response GetAppointmentsExpired()
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT * FROM appointments WHERE status = 4 AND CAST(schedule AS DATE) = CAST(NOW() AS DATE)");
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<Appointment> appointments = new();

                while (dataReader.Read())
                {
                    appointments.Add(new Appointment
                    {
                        Id = (int)dataReader["id"],
                        CustomerId = (int)dataReader["customerId"],
                        Title = (string)dataReader["title"],
                        Details = (string)dataReader["details"],
                        Schedule = Convert.ToDateTime(dataReader["schedule"]),
                        CreatedAt = Convert.ToDateTime(dataReader["createdAt"]),
                        UpdatedAt = Convert.ToDateTime(dataReader["updatedAt"]),
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = appointments
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET APPOINTMENTS
        public Response GetAppointment(int appointmentId)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT * FROM appointments WHERE id = {0}", appointmentId);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                Appointment? appointment = null;

                while (dataReader.Read())
                {
                    appointment = new Appointment
                    {
                        Id = (int)dataReader["id"],
                        CustomerId = (int)dataReader["customerId"],
                        Details = (string)dataReader["details"],
                        Title = (string)dataReader["title"],
                        Schedule = Convert.ToDateTime(dataReader["schedule"]),
                        CreatedAt = Convert.ToDateTime(dataReader["createdAt"]),
                        UpdatedAt = Convert.ToDateTime(dataReader["updatedAt"]),
                        Status = (int)dataReader["status"],
                    };
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = appointment
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // UPDATE APPOINTMENT
        public Response UpdateAppointment(int appointmentId, int customerId, string title, string details, string schedule, int status, string updatedAt)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("UPDATE appointments SET customerId = {0}, title = '{1}', details = '{2}', schedule = '{3}',  updatedAt = '{4}', status = {5} WHERE id = {6}",  customerId, title, details, schedule, updatedAt, status, appointmentId);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();


                db.connection.Close();


                return new Response()
                {
                    Status = true,
                    Message = "Appointment Successfully Updated!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // DELETE APPOINTMENT
        public Response DeleteAppointment(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("Update appointments SET status = 0 WHERE id = {0}", id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Appointment Successfully Deleted!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }
    
        // COUNT APPOINTMENT CUSTOMER
        public Response CountAppointmentCustomer(int customerId)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT COUNT(*) AS CountAppointmentCustomer FROM appointments WHERE customerId = {0} AND status = 1", customerId);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                long countAppointmentCustomer = 0;

                while (dataReader.Read())
                {
                    countAppointmentCustomer = (long)dataReader["CountAppointmentCustomer"];
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = countAppointmentCustomer
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }
    }
}
