﻿using MySql.Data.MySqlClient;
using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PET_CARE_MANAGEMENT_SYSTEM.Services
{
    public class ProductsService
    {
        public DBConnect db;

        public ProductsService() => db = new DBConnect();

        // GET PRODUCTS
        public Response GetProducts()
        {
            try
            {
                db.connection.Open();

                string query = "SELECT * FROM products WHERE status = 1";
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<Product> products = new();

                while (dataReader.Read())
                {
                    products.Add(new Product
                    {
                        Id = (int)dataReader["id"],
                        CategoryId = (int)dataReader["categoryId"],
                        Name = (string)dataReader["name"],
                        Description = (string)dataReader["description"],
                        Quantity = (int)dataReader["quantity"],
                        Price = (decimal)dataReader["price"],
                        ExpiredAt = dataReader["expiredAt"] == DBNull.Value ? null : Convert.ToDateTime(dataReader["expiredAt"]),
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = products
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET PRODUCT
        public Response GetProduct(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT * FROM products WHERE id = {0} AND status = 1", id);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                Product? product = null;

                while (dataReader.Read())
                {
                    product = new Product
                    {
                        Id = (int)dataReader["id"],
                        CategoryId = (int)dataReader["categoryId"],
                        Name = (string)dataReader["name"],
                        Description = (string)dataReader["description"],
                        Quantity = (int)dataReader["quantity"],
                        Price = (decimal)dataReader["price"],
                        ExpiredAt = dataReader["expiredAt"] == DBNull.Value ? null : Convert.ToDateTime(dataReader["expiredAt"]),
                        Status = (int)dataReader["status"],
                    };
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = product
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CHECK PRODUCT NAME
        public Response CheckProductName(string productName, int id = 0)
        {
            try
            {
                db.connection.Open();
                string query = string.Format("SELECT COUNT(*) AS CheckCount FROM products WHERE name = '{0}' AND status = 1", productName);
                if (id != 0) query = string.Format("SELECT COUNT(*) AS CheckCount FROM products WHERE name = '{0}' AND id != {1} AND status = 1", productName, id);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();


                long checkCount = 0;

                while (dataReader.Read())
                {
                    checkCount = (long)dataReader["CheckCount"];
                }

                dataReader.Close();

                db.connection.Close();

                if (checkCount > 0)
                {
                    return new Response()
                    {
                        Status = false,
                        Message = "Product already exists!",
                        Payload = null
                    };
                }
                else
                {
                    return new Response()
                    {
                        Status = true,
                        Message = "",
                        Payload = null
                    };
                }
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CREATE PRODUCT
        public Response CreateProduct(int categoryId, string name, string description, int quantity, decimal price, string? expiredAt)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("INSERT INTO products (categoryId, name, description, quantity, price, expiredAt, status) " +
                    "VALUES({0}, '{1}', '{2}', {3}, {4}, '{5}', {6})", categoryId, name, description, quantity, price, expiredAt, 1);
                if (expiredAt == null)
                {
                    query = string.Format("INSERT INTO products (categoryId, name, description, quantity, price, status) " +
                    "VALUES({0}, '{1}', '{2}', {3}, {4}, {5})", categoryId, name, description, quantity, price, 1);
                }
                

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "New Product Created!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // UPDATE PRODUCT
        public Response UpdateProduct(int id, int categoryId, string name, string description, int quantity, decimal price, string? expiredAt)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("UPDATE products SET categoryId = {0}, name = '{1}', description = '{2}', quantity = {3}, price = {4}, expiredAt = '{5}' WHERE id = {6}",
                    categoryId, name, description, quantity, price, expiredAt, id);
                if (expiredAt == null)
                {
                    query = string.Format("UPDATE products SET categoryId = {0}, name = '{1}', description = '{2}', quantity = {3}, price = {4}, expiredAt = NULL WHERE id = {5}",
                    categoryId, name, description, quantity, price, id);
                }

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Product Successfully Updated!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // COUNT PRODUCTS BY CATEGORY
        public Response CountProductsByCategory(int categoryId)
        {
            try
            {
                db.connection.Open();
                string query = string.Format("SELECT COUNT(*) AS ProductsCount FROM products WHERE categoryId = {0} AND status = 1", categoryId);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                long productsCount = 0;

                while (dataReader.Read())
                {
                    productsCount = (long)dataReader["ProductsCount"];
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = productsCount
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // DELETE PRODUCT
        public Response DeleteProduct(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("Update products SET status = 0 WHERE id = {0}", id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Product Successfully Deleted!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET EXPIRED PRODUCTS
        public Response GetExpiredProducts()
        {
            try
            {
                db.connection.Open();

                string query = "SELECT * FROM products WHERE status = 1 AND expiredAt <= CAST(NOW() AS DATE)";
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<Product> products = new();

                while (dataReader.Read())
                {
                    products.Add(new Product
                    {
                        Id = (int)dataReader["id"],
                        CategoryId = (int)dataReader["categoryId"],
                        Name = (string)dataReader["name"],
                        Description = (string)dataReader["description"],
                        Quantity = (int)dataReader["quantity"],
                        Price = (decimal)dataReader["price"],
                        ExpiredAt = dataReader["expiredAt"] == DBNull.Value ? null : Convert.ToDateTime(dataReader["expiredAt"]),
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = products
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET ORDER PRODUCTS
        public Response GetOrderProducts()
        {
            try
            {
                db.connection.Open();

                string query = "SELECT * FROM products WHERE status = 1 AND (expiredAt > CAST(NOW() AS DATE) || expiredAt IS NULL)";
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<Product> products = new();

                while (dataReader.Read())
                {
                    products.Add(new Product
                    {
                        Id = (int)dataReader["id"],
                        CategoryId = (int)dataReader["categoryId"],
                        Name = (string)dataReader["name"],
                        Description = (string)dataReader["description"],
                        Quantity = (int)dataReader["quantity"],
                        Price = (decimal)dataReader["price"],
                        ExpiredAt = dataReader["expiredAt"] == DBNull.Value ? null : Convert.ToDateTime(dataReader["expiredAt"]),
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = products
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET OUT OF STOCK PRODUCTS
        public Response GetOutOfStockProducts()
        {
            try
            {
                db.connection.Open();

                string query = "SELECT * FROM products WHERE status = 1 AND quantity = 0";
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<Product> products = new();

                while (dataReader.Read())
                {
                    products.Add(new Product
                    {
                        Id = (int)dataReader["id"],
                        CategoryId = (int)dataReader["categoryId"],
                        Name = (string)dataReader["name"],
                        Description = (string)dataReader["description"],
                        Quantity = (int)dataReader["quantity"],
                        Price = (decimal)dataReader["price"],
                        ExpiredAt = dataReader["expiredAt"] == DBNull.Value ? null : Convert.ToDateTime(dataReader["expiredAt"]),
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = products
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }
    }
}
