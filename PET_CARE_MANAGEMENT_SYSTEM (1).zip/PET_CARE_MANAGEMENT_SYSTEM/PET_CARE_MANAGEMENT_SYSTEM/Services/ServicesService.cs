﻿using MySql.Data.MySqlClient;
using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PET_CARE_MANAGEMENT_SYSTEM.Services
{
    public class ServicesService
    {
        public DBConnect db;

        public ServicesService() => db = new DBConnect();

        // GET SERVICES
        public Response GetServices()
        {
            try
            {
                db.connection.Open();

                string query = "SELECT * FROM services WHERE status = 1";
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<Service> services = new();

                while (dataReader.Read())
                {
                    services.Add(new Service
                    {
                        Id = (int)dataReader["id"],
                        Name = (string)dataReader["name"],
                        Description = (string)dataReader["description"],
                        Price = (decimal)dataReader["price"],
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = services
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET SERVICE
        public Response GetService(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT * FROM services WHERE id = {0} AND status = 1", id);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                Service? service = null;

                while (dataReader.Read())
                {
                    service = new Service
                    {
                        Id = (int)dataReader["id"],
                        Name = (string)dataReader["name"],
                        Description = (string)dataReader["description"],
                        Price = (decimal)dataReader["price"],
                        Status = (int)dataReader["status"],
                    };
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = service
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CHECK SERVICE NAME
        public Response CheckServiceName(string serviceName, int id = 0)
        {
            try
            {
                db.connection.Open();
                string query = string.Format("SELECT COUNT(*) AS CheckCount FROM services WHERE name = '{0}' AND status = 1", serviceName);
                if (id != 0) query = string.Format("SELECT COUNT(*) AS CheckCount FROM services WHERE name = '{0}' AND id != {1} AND status = 1", serviceName, id);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();


                long checkCount = 0;

                while (dataReader.Read())
                {
                    checkCount = (long)dataReader["CheckCount"];
                }

                dataReader.Close();

                db.connection.Close();

                if (checkCount > 0)
                {
                    return new Response()
                    {
                        Status = false,
                        Message = "Service already exists!",
                        Payload = null
                    };
                }
                else
                {
                    return new Response()
                    {
                        Status = true,
                        Message = "",
                        Payload = null
                    };
                }
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CREATE SERVICE
        public Response CreateService(string name, string description, decimal price)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("INSERT INTO services (name, description, price, status) VALUES('{0}', '{1}', {2}, {3})", name, description, price, 1);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "New Service Created!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // UPDATE SERVICE
        public Response UpdateService(int id, string name, string description, decimal price)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("UPDATE services SET  name = '{0}', description = '{1}', price = {2}  WHERE id = {3}",
                    name, description, price, id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Service Successfully Updated!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // DELETE PRODUCT
        public Response DeleteService(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("Update services SET status = 0 WHERE id = {0}", id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Service Successfully Deleted!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET ORDER PRODUCTS
        public Response GetOrderProducts()
        {
            try
            {
                db.connection.Open();

                string query = "SELECT * FROM products WHERE status = 1 AND (expiredAt > CAST(NOW() AS DATE) || expiredAt IS NULL)";
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<Product> products = new();

                while (dataReader.Read())
                {
                    products.Add(new Product
                    {
                        Id = (int)dataReader["id"],
                        CategoryId = (int)dataReader["categoryId"],
                        Name = (string)dataReader["name"],
                        Description = (string)dataReader["description"],
                        Quantity = (int)dataReader["quantity"],
                        Price = (decimal)dataReader["price"],
                        ExpiredAt = dataReader["expiredAt"] == DBNull.Value ? null : Convert.ToDateTime(dataReader["expiredAt"]),
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = products
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

    }
}
