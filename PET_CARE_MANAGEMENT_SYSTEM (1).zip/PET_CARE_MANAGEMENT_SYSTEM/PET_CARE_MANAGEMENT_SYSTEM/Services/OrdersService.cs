﻿using MySql.Data.MySqlClient;
using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PET_CARE_MANAGEMENT_SYSTEM.Services
{
    public class OrdersService
    {
        public DBConnect db;

        public OrdersService() => db = new DBConnect();

        // GET ORDERS
        public Response GetOrders()
        {
            try
            {
                db.connection.Open();

                string query = "SELECT * FROM orders WHERE status = 1";
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<Order> orders = new();

                while (dataReader.Read())
                {
                    orders.Add(new Order
                    {
                        Id = (int)dataReader["id"],
                        CustomerId = (int)dataReader["customerId"],
                        CreatorId = (int)dataReader["creatorId"],
                        CreatorRole = dataReader["creatorRole"].ToString()!.ToCharArray()[0],
                        Total = (decimal)dataReader["total"],
                        CreatedAt = Convert.ToDateTime(dataReader["createdAt"]),
                        UpdatedAt = Convert.ToDateTime(dataReader["updatedAt"]),
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = orders
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET ORDER
        public Response GetOrder(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT * FROM orders WHERE id = {0}", id);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                Order? order = null;

                while (dataReader.Read())
                {
                    order = new Order
                    {
                        Id = (int)dataReader["id"],
                        CustomerId = (int)dataReader["customerId"],
                        CreatorId = (int)dataReader["creatorId"],
                        CreatorRole = dataReader["creatorRole"].ToString()!.ToCharArray()[0],
                        Total = (decimal)dataReader["total"],
                        CreatedAt = Convert.ToDateTime(dataReader["createdAt"]),
                        UpdatedAt = Convert.ToDateTime(dataReader["updatedAt"]),
                        Status = (int)dataReader["status"],
                    };
                }

                dataReader.Close();

                db.connection.Close();

                if (order != null)
                {
                    return new Response()
                    {
                        Status = true,
                        Message = "",
                        Payload = order,
                    };
                }
                else
                {
                    return new Response()
                    {
                        Status = false,
                        Message = "Something went wrong.",
                        Payload = null,
                    };
                }
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET ORDER ITEMS
        public Response GetOrderItems(int orderId)
        {
            try
            {
                db.connection.Open();

                string query =string.Format("SELECT * FROM order_items WHERE orderId = {0} AND status = 1", orderId);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<OrderItem> orderItems = new();

                while (dataReader.Read())
                {
                    orderItems.Add(new OrderItem
                    {
                        Id = (int)dataReader["id"],
                        OrderId = (int)dataReader["orderId"],
                        Price = (decimal)dataReader["price"],
                        Quantity = (int)dataReader["quantity"],
                        ItemId= (int)dataReader["itemId"],
                        ItemType = dataReader["itemType"].ToString()!.ToCharArray()[0],
                        Total = (decimal)dataReader["total"],
                        CreatedAt = Convert.ToDateTime(dataReader["createdAt"]),
                        UpdatedAt = Convert.ToDateTime(dataReader["updatedAt"]),
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = orderItems
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET ORDER ITEM
        public Response GetOrderItem(int orderItemId)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT * FROM order_items WHERE id = {0} AND status = 1", orderItemId);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                OrderItem? orderItem = null;

                while (dataReader.Read())
                {
                    orderItem = new OrderItem
                    {
                        Id = (int)dataReader["id"],
                        OrderId = (int)dataReader["orderId"],
                        Price = (decimal)dataReader["price"],
                        Quantity = (int)dataReader["quantity"],
                        ItemId = (int)dataReader["itemId"],
                        ItemType = dataReader["itemType"].ToString()!.ToCharArray()[0],
                        Total = (decimal)dataReader["total"],
                        CreatedAt = Convert.ToDateTime(dataReader["createdAt"]),
                        UpdatedAt = Convert.ToDateTime(dataReader["updatedAt"]),
                        Status = (int)dataReader["status"],
                    };
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = orderItem
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET NEXT ID
        public Response GetNextId ()
        {
            try
            {
                db.connection.Open();
                string query = "SELECT MAX(id) AS MaxId FROM orders";
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                int maxId = 0;

                while (dataReader.Read())
                {
                    maxId = dataReader["MaxId"] is DBNull ? 0 : (int)dataReader["MaxId"];
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = maxId + 1
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CREATE ORDER
        public Response CreateOrder(int customerId, int creatorId, char creatorRole, decimal total, string createdAt, string updatedAt)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("INSERT INTO orders (customerId, creatorId, creatorRole, total, createdAt, updatedAt, Status) " +
                    "VALUES({0}, {1}, '{2}', {3}, '{4}', '{5}', {6})", customerId, creatorId, creatorRole, total, createdAt, updatedAt, 1);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                string query1 = "SELECT MAX(id) AS MaxId FROM orders";
                MySqlCommand cmd1 = new(query1, db.connection);
                MySqlDataReader dataReader = cmd1.ExecuteReader();

                int maxId = 0;

                while (dataReader.Read())
                {
                    maxId = (int)dataReader["MaxId"];
                }

                dataReader.Close();

                db.connection.Close();
                    

                return new Response()
                {
                    Status = true,
                    Message = "New Order Created!",
                    Payload = maxId
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CREATE ORDER ITEM
        public Response CreateOrderItem(int orderId, int itemId, char itemType, int quantity, decimal price, decimal total, string createdAt, string updatedAt)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("INSERT INTO order_items (orderId, itemId, itemType, quantity, price, total, createdAt, updatedAt, status) " +
                    "VALUES({0}, {1}, '{2}', {3}, {4}, {5}, '{6}', '{7}', {8})", orderId, itemId, itemType, quantity, price, total, createdAt, updatedAt, 1);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();
               

                db.connection.Close();


                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // UPDATE ORDER
        public Response UpdateOrder(int orderId, int customerId, decimal total, string updatedAt)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("UPDATE orders SET customerId = {0}, total = {1}, updatedAt = '{2}' WHERE id = {3}", customerId, total, updatedAt, orderId);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Order Successfully Updated!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // UPDATE ORDER ITEM
        public Response UpdateOrderItem(int orderItemId, int quantity, decimal price, decimal total, string updatedAt)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("UPDATE order_items SET quantity = {0}, price = {1}, total = {2}, updatedAt = '{3}' WHERE id = {4}", quantity, price, total, updatedAt, orderItemId);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();


                db.connection.Close();


                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // DELETE ORDER
        public Response DeleteOrder(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("Update orders SET status = 0 WHERE id = {0}", id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Order Successfully Deleted!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // DELETE ORDER ITEM
        public Response DeleteOrderItem(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("Update order_items SET status = 0 WHERE id = {0}", id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Order Item Successfully Deleted!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // COUNT ORDER ITEM
        public Response CountOrderItems(int itemId, char itemType)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT COUNT(*) AS CountOrderItems FROM order_items WHERE itemId = {0} AND itemType = {1} AND status = 1", itemId, itemType);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                long countOrderItems = 0;

                while (dataReader.Read())
                {
                    countOrderItems = (long)dataReader["CountOrderItems"];
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = countOrderItems
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // COUNT ORDER CUSTOMER
        public Response CountOrderCustomer(int customerId)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT COUNT(*) AS CountOrderCustomer FROM orders WHERE customerId = {0} AND status = 1", customerId);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                long countOrderCustomer = 0;

                while (dataReader.Read())
                {
                    countOrderCustomer = (long)dataReader["CountOrderCustomer"];
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = countOrderCustomer
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }
    }
}
