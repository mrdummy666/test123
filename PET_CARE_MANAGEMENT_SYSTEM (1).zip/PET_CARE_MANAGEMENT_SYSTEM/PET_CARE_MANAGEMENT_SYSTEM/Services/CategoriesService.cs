﻿using MySql.Data.MySqlClient;
using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace PET_CARE_MANAGEMENT_SYSTEM.Services
{
    public class CategoriesService
    {
        public DBConnect db;

        public CategoriesService() => db = new DBConnect();

        // GET CATEGORIES
        public Response GetCategories()
        {
            try
            {
                db.connection.Open();

                string query = "SELECT * FROM categories WHERE status = 1";
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<Category> categories = new();

                while (dataReader.Read())
                {
                    categories.Add(new Category
                    {
                        Id = (int)dataReader["id"],
                        Name = (string)dataReader["name"],
                        HasExpiration = (int)dataReader["hasExpiration"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = categories
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET CATEGORY ID BY NAME
        public Response GetCategoryIdByName(string categoryName)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT id FROM categories WHERE name = '{0}' AND status = 1", categoryName);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                int id = 0;

                while (dataReader.Read())
                {
                    id = (int)dataReader["id"];
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = id
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET CATEGORY NAME BY ID
        public Response GetCategoryNameById(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT name FROM categories WHERE id = {0} AND status = 1", id);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                string name = "";

                while (dataReader.Read())
                {
                    name = (string)dataReader["name"];
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = name
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CREATE/UPDATE CATEGORY
        public Response CreateUpdateCategory(string category, int expiration, int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("INSERT INTO categories (name, hasExpiration, status) VALUES('{0}', {1}, 1)", category, expiration);
                if (id != 0) query = string.Format("UPDATE categories SET name = '{0}', hasExpiration = {1} WHERE id = {2}", category, expiration, id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = id != 0 ? "Category Successfully Updated!" : "New Category Created!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CHECK CATEGORY
        public Response CheckCategory(string category, int id) {
            try
            {
                db.connection.Open();
                string query = string.Format("SELECT COUNT(*) AS CheckCount FROM categories WHERE name = '{0}' AND status = 1", category);
                if (id != 0) query = string.Format("SELECT COUNT(*) AS CheckCount FROM categories WHERE name = '{0}' AND id != {1} AND status = 1", category, id);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();


                long checkCount = 0;

                while (dataReader.Read())
                {
                    checkCount = (long)dataReader["CheckCount"];
                }

                dataReader.Close();

                db.connection.Close();

                if (checkCount > 0)
                {
                    return new Response()
                    {
                        Status = false,
                        Message = "Category already exists!",
                        Payload = null
                    };
                }
                else
                {
                    return new Response()
                    {
                        Status = true,
                        Message = "",
                        Payload = null
                    };
                }
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // DELETE CATEGORY
        public Response DeleteCategory(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("UPDATE categories SET status = 0 WHERE id = {0}", id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Category Successfully Deleted!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

    }
}
