﻿using MySql.Data.MySqlClient;
using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace PET_CARE_MANAGEMENT_SYSTEM.Services
{
    public class AuthService
    {
        public DBConnect db;

        public AuthService() => db = new DBConnect();

        // LOGIN
        public Response Login (string username, string password)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT * FROM users WHERE username = '{0}' AND password = '{1}' AND status = 1", username, password);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<User> users = new ();

                while (dataReader.Read())
                {

                    users.Add(new User
                    {
                        Id = (int)dataReader["id"],
                        Username = (string)dataReader["username"],
                        FirstName = (string)dataReader["firstName"],
                        MiddleName = (string)dataReader["middleName"],
                        LastName = (string)dataReader["lastName"],
                        Gender = dataReader["gender"].ToString()!.ToCharArray()[0],
                        Role = dataReader["role"].ToString()!.ToCharArray()[0],
                        IsInit = (int)dataReader["isInit"],
                        Status = (int)dataReader["status"],
                    });


                }

                dataReader.Close();

                db.connection.Close();

                if (users.Count > 0)
                {
                    return new Response()
                    {
                        Status = true,
                        Message = "Login Successful!",
                        Payload = users[0]
                    };
                } else
                {
                    return new Response()
                    {
                        Status = false,
                        Message = "Login Failed!",
                        Payload = null
                    };
                }
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CHECK USERNAME
        public Response CheckUsername(string username, int id = 0)
        {
            try
            {
                db.connection.Open();
                string query = string.Format("SELECT COUNT(*) AS CheckCount FROM users WHERE username = '{0}' AND status = 1", username);
                if (id != 0) query = string.Format("SELECT COUNT(*) AS CheckCount FROM users WHERE username = '{0}' AND id != {1} AND status = 1", username, id);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();


                long checkCount = 0;

                while (dataReader.Read())
                {
                    checkCount = (long) dataReader["CheckCount"];
                }

                dataReader.Close();

                db.connection.Close();

                if (checkCount > 0)
                {
                    return new Response()
                    {
                        Status = false,
                        Message = "Username is already used!",
                        Payload = null
                    };
                }
                else
                {
                    return new Response()
                    {
                        Status = true,
                        Message = "",
                        Payload = null
                    };
                }
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }
    
        // GET USER
        public Response GetUser(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT * FROM users WHERE id = {0}", id);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                User? user = null;

                while (dataReader.Read())
                {
                    user = new User
                    {
                        Id = (int)dataReader["id"],
                        Username = (string)dataReader["username"],
                        FirstName = (string)dataReader["firstName"],
                        MiddleName = (string)dataReader["middleName"],
                        LastName = (string)dataReader["lastName"],
                        Gender = dataReader["gender"].ToString()!.ToCharArray()[0],
                        Role = dataReader["role"].ToString()!.ToCharArray()[0],
                        IsInit = (int)dataReader["isInit"],
                        Status = (int)dataReader["status"],
                    };
                }

                dataReader.Close();

                db.connection.Close();

                if (user != null)
                {
                    return new Response()
                    {
                        Status = true,
                        Message = "",
                        Payload = user,
                    };
                } else
                {
                    return new Response()
                    {
                        Status = false,
                        Message = "Something went wrong.",
                        Payload = null,
                    };
                }
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CHANGE PASSWORD
        public Response ChangePassword(string newPassword, int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("UPDATE users SET password = '{0}', isInit = 1 WHERE id = {1}", newPassword, id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Password Successfully Changed!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }
    }
}
