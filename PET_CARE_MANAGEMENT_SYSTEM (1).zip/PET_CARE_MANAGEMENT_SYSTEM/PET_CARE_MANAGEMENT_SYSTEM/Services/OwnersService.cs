﻿using MySql.Data.MySqlClient;
using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace PET_CARE_MANAGEMENT_SYSTEM.Services
{
    public class OwnersService
    {
        public DBConnect db;
        public OwnersService() => db = new DBConnect();

        // GET OWNERS
        public Response GetOwners()
        {
            try
            {
                db.connection.Open();

                string query = "SELECT * FROM owners WHERE status = 1";
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<Owner> owners = new();

                while (dataReader.Read())
                {

                    owners.Add(new Owner
                    {
                        Id = (int)dataReader["id"],
                        FirstName = (string)dataReader["firstName"],
                        MiddleName = (string)dataReader["middleName"],
                        LastName = (string)dataReader["lastName"],
                        Gender = dataReader["gender"].ToString()!.ToCharArray()[0],
                        MobileNumber = (string)dataReader["mobileNumber"],
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = owners
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CREATE OWNER
        public Response CreateOwner(string firstName, string middleName, string lastName, char gender, string mobileNumber)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("INSERT INTO owners (firstName, middleName, lastName, gender, mobileNumber, status) " +
                    "VALUES('{0}', '{1}', '{2}', '{3}', '{4}', '{5}')", firstName, middleName, lastName, gender, mobileNumber, 1);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "New Pet Owner Created!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // GET OWNER
        public Response GetOwner(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("SELECT * FROM owners WHERE id = {0}", id);
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                Owner? owner = null;

                while (dataReader.Read())
                {
                    owner = new Owner
                    {
                        Id = (int)dataReader["id"],
                        FirstName = (string)dataReader["firstName"],
                        MiddleName = (string)dataReader["middleName"],
                        LastName = (string)dataReader["lastName"],
                        Gender = dataReader["gender"].ToString()!.ToCharArray()[0],
                        MobileNumber = (string)dataReader["mobileNumber"],
                        Status = (int)dataReader["status"],
                    };
                }

                dataReader.Close();

                db.connection.Close();

                if (owner != null)
                {
                    return new Response()
                    {
                        Status = true,
                        Message = "",
                        Payload = owner,
                    };
                }
                else
                {
                    return new Response()
                    {
                        Status = false,
                        Message = "Something went wrong.",
                        Payload = null,
                    };
                }
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }
    
        // UPDATE OWNER
        public Response UpdateOwner(int id, string firstName, string middleName, string lastName, char gender, string mobileNumber)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("UPDATE owners SET firstName = '{0}', middleName = '{1}', lastName = '{2}', gender = '{3}', mobileNumber = '{4}' WHERE id = {5}",
                    firstName, middleName, lastName, gender, mobileNumber, id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Pet Owner Successfully Updated!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }
    
        // DELETE OWNER
        public Response DeleteOwner(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("Update owners SET status = 0 WHERE id = {0}", id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Pet Owner Successfully Deleted!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }
    }
}
