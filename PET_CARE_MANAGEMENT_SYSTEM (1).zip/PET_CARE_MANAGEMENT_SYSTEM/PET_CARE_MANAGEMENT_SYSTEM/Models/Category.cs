﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PET_CARE_MANAGEMENT_SYSTEM.Models
{
    internal class Category
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int HasExpiration { get; set; }
        public int Status { get; set; }
    }
}
