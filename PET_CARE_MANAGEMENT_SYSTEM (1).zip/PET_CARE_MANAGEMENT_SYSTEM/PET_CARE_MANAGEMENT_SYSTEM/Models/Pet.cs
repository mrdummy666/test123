﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PET_CARE_MANAGEMENT_SYSTEM.Models
{
    public class Pet
    {
        public int Id { get; set; }
        public int OwnerId { get; set; }
        public string PetName { get; set; } = string.Empty;
        public string AnimalType { get; set; } = string.Empty;
        public string Breed { get; set; } = string.Empty;
        public char Gender { get; set; }
        public int Status { get; set; }
    }
}
