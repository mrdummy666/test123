﻿using MySql.Data.MySqlClient;

namespace PET_CARE_MANAGEMENT_SYSTEM.Utils
{
    public class DBConnect
    {
        public MySqlConnection connection;
        private readonly string server;
        private readonly string database;
        private readonly string uid;
        private readonly string password;
        private readonly string connStr = "SERVER={0};DATABASE={1};UID={2};PASSWORD={3};";

        public DBConnect()
        {
            server = "localhost";
            database = "db_pet_care_management_system";
            uid = "root";
            password = "";
            connection = new (string.Format(connStr, server, database, uid, password));
        }
    }

}
