﻿using PET_CARE_MANAGEMENT_SYSTEM;
using PET_CARE_MANAGEMENT_SYSTEM.Forms;
using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PET_CARE_MANAGEMENT_SYSTEM
{
    public partial class LoginForm : Form
    {
        public AuthService authService;
        public static bool isChangedPassword = false;
        public LoginForm()
        {
            InitializeComponent();
            authService = new();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            BtnLogin.Enabled = false;
            string username = TxtUsername.Text.Trim();
            string password = TxtPassword.Text.Trim();

            if (username.Length == 0 || password.Length == 0)
            {
                MessageBox.Show("Username and Password are required.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                var regexItem = PasswordRegex();

                if (regexItem.IsMatch(password))
                {
                    Response loginResponse = authService.Login(username, password);
                    if (loginResponse.Status)
                    {
                        MessageBox.Show(loginResponse.Message, "Login", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        User user = loginResponse.Payload!;

                        TxtUsername.Text = "";
                        TxtPassword.Text = "";

                        Hide();

                        if (user.IsInit == 0)
                        {
                            ChangePasswordForm changePasswordForm = new(user.Id);
                            changePasswordForm.ShowDialog();

                            if (isChangedPassword)
                            {
                                MainForm mainForm = new(user);
                                mainForm.Show();
                            } else
                            {
                                Show();
                            }
                        }
                        else
                        {
                            MainForm mainForm = new(user);
                            mainForm.Show();
                        }
                    }
                    else
                    {
                        MessageBox.Show(loginResponse.Message, "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Password must not contain special character.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
               
            }
            BtnLogin.Enabled = true;
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        [GeneratedRegex("^[a-zA-Z0-9 ]*$")]
        private static partial Regex PasswordRegex();
    }
}
