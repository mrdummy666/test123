﻿using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    public partial class ChangePasswordForm : Form
    {
        public AuthService authService;
        public int toUpdateId;
        public ChangePasswordForm(int userId)
        {
            InitializeComponent();
            authService = new();
            toUpdateId = userId;
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            string newPassword = TxtNewPassword.Text.Trim();
            string confirmPassword = TxtConfirmPassword.Text.Trim();


            if (newPassword.Length == 0 || confirmPassword.Length == 0)
            {
                MessageBox.Show("All fields are required.", "Change Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (newPassword != confirmPassword)
                {
                    MessageBox.Show("Password Confirmation doesn't match.", "Change Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {

                    Response changePasswordResponse = authService.ChangePassword(newPassword, toUpdateId);
                    if (changePasswordResponse.Status)
                    {
                        MessageBox.Show(changePasswordResponse.Message, "Change Password", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoginForm.isChangedPassword = true;
                        Close();
                    }
                    else
                    {
                        MessageBox.Show(changePasswordResponse.Message, "Change Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}
