﻿namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    partial class PetActivitiesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            BtnClose = new Button();
            label1 = new Label();
            TxtPetName = new TextBox();
            label2 = new Label();
            DgvPetActivities = new DataGridView();
            label3 = new Label();
            TxtOwner = new TextBox();
            DtpPetActivitiesTo = new DateTimePicker();
            LblTo = new Label();
            LblFrom = new Label();
            DtpPetActivitiesFrom = new DateTimePicker();
            BtnUpdateActivity = new Button();
            BtnDeleteActivity = new Button();
            BtnAddActivity = new Button();
            TxtSearchPetActivity = new TextBox();
            ((System.ComponentModel.ISupportInitialize)DgvPetActivities).BeginInit();
            SuspendLayout();
            // 
            // BtnClose
            // 
            BtnClose.BackColor = Color.Red;
            BtnClose.Cursor = Cursors.Hand;
            BtnClose.FlatAppearance.BorderSize = 0;
            BtnClose.FlatStyle = FlatStyle.Flat;
            BtnClose.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            BtnClose.ForeColor = Color.White;
            BtnClose.Location = new Point(602, 1);
            BtnClose.Name = "BtnClose";
            BtnClose.Size = new Size(42, 34);
            BtnClose.TabIndex = 6;
            BtnClose.Text = "X";
            BtnClose.UseVisualStyleBackColor = false;
            BtnClose.Click += BtnClose_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(4, 5);
            label1.Name = "label1";
            label1.Size = new Size(118, 20);
            label1.TabIndex = 8;
            label1.Text = "PET ACTIVITIES";
            // 
            // TxtPetName
            // 
            TxtPetName.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtPetName.Location = new Point(36, 86);
            TxtPetName.Name = "TxtPetName";
            TxtPetName.Size = new Size(253, 27);
            TxtPetName.TabIndex = 0;
            TxtPetName.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(36, 65);
            label2.Name = "label2";
            label2.Size = new Size(65, 17);
            label2.TabIndex = 10;
            label2.Text = "Pet Name";
            // 
            // DgvPetActivities
            // 
            DgvPetActivities.AllowUserToAddRows = false;
            DgvPetActivities.AllowUserToDeleteRows = false;
            DgvPetActivities.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvPetActivities.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.False;
            DgvPetActivities.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            DgvPetActivities.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvPetActivities.Location = new Point(36, 235);
            DgvPetActivities.Name = "DgvPetActivities";
            DgvPetActivities.ReadOnly = true;
            DgvPetActivities.RowTemplate.Height = 25;
            DgvPetActivities.Size = new Size(571, 348);
            DgvPetActivities.TabIndex = 21;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(36, 124);
            label3.Name = "label3";
            label3.Size = new Size(46, 17);
            label3.TabIndex = 11;
            label3.Text = "Owner";
            // 
            // TxtOwner
            // 
            TxtOwner.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtOwner.Location = new Point(36, 143);
            TxtOwner.Name = "TxtOwner";
            TxtOwner.Size = new Size(253, 27);
            TxtOwner.TabIndex = 1;
            TxtOwner.TextAlign = HorizontalAlignment.Center;
            // 
            // DtpPetActivitiesTo
            // 
            DtpPetActivitiesTo.CustomFormat = "MMMM dd, yyyy";
            DtpPetActivitiesTo.Format = DateTimePickerFormat.Custom;
            DtpPetActivitiesTo.Location = new Point(447, 206);
            DtpPetActivitiesTo.Name = "DtpPetActivitiesTo";
            DtpPetActivitiesTo.Size = new Size(160, 23);
            DtpPetActivitiesTo.TabIndex = 26;
            DtpPetActivitiesTo.ValueChanged += DtpPetActivitiesTo_ValueChanged;
            // 
            // LblTo
            // 
            LblTo.AutoSize = true;
            LblTo.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            LblTo.Location = new Point(425, 210);
            LblTo.Name = "LblTo";
            LblTo.Size = new Size(20, 15);
            LblTo.TabIndex = 25;
            LblTo.Text = "To";
            // 
            // LblFrom
            // 
            LblFrom.AutoSize = true;
            LblFrom.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            LblFrom.Location = new Point(223, 210);
            LblFrom.Name = "LblFrom";
            LblFrom.Size = new Size(36, 15);
            LblFrom.TabIndex = 24;
            LblFrom.Text = "From";
            // 
            // DtpPetActivitiesFrom
            // 
            DtpPetActivitiesFrom.CustomFormat = "MMMM dd, yyyy";
            DtpPetActivitiesFrom.Format = DateTimePickerFormat.Custom;
            DtpPetActivitiesFrom.Location = new Point(261, 206);
            DtpPetActivitiesFrom.Name = "DtpPetActivitiesFrom";
            DtpPetActivitiesFrom.Size = new Size(160, 23);
            DtpPetActivitiesFrom.TabIndex = 23;
            DtpPetActivitiesFrom.ValueChanged += DtpPetActivitiesFrom_ValueChanged;
            // 
            // BtnUpdateActivity
            // 
            BtnUpdateActivity.BackColor = Color.LimeGreen;
            BtnUpdateActivity.Cursor = Cursors.Hand;
            BtnUpdateActivity.FlatAppearance.BorderSize = 0;
            BtnUpdateActivity.FlatStyle = FlatStyle.Flat;
            BtnUpdateActivity.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            BtnUpdateActivity.ForeColor = Color.White;
            BtnUpdateActivity.Location = new Point(499, 586);
            BtnUpdateActivity.Name = "BtnUpdateActivity";
            BtnUpdateActivity.Size = new Size(53, 23);
            BtnUpdateActivity.TabIndex = 33;
            BtnUpdateActivity.Text = "Update";
            BtnUpdateActivity.UseVisualStyleBackColor = false;
            BtnUpdateActivity.Click += BtnUpdateActivity_Click;
            // 
            // BtnDeleteActivity
            // 
            BtnDeleteActivity.BackColor = Color.Red;
            BtnDeleteActivity.Cursor = Cursors.Hand;
            BtnDeleteActivity.FlatAppearance.BorderSize = 0;
            BtnDeleteActivity.FlatStyle = FlatStyle.Flat;
            BtnDeleteActivity.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            BtnDeleteActivity.ForeColor = Color.White;
            BtnDeleteActivity.Location = new Point(554, 586);
            BtnDeleteActivity.Name = "BtnDeleteActivity";
            BtnDeleteActivity.Size = new Size(53, 23);
            BtnDeleteActivity.TabIndex = 32;
            BtnDeleteActivity.Text = "Delete";
            BtnDeleteActivity.UseVisualStyleBackColor = false;
            BtnDeleteActivity.Click += BtnDeleteActivity_Click;
            // 
            // BtnAddActivity
            // 
            BtnAddActivity.BackColor = SystemColors.Highlight;
            BtnAddActivity.Cursor = Cursors.Hand;
            BtnAddActivity.FlatAppearance.BorderSize = 0;
            BtnAddActivity.FlatStyle = FlatStyle.Flat;
            BtnAddActivity.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            BtnAddActivity.ForeColor = Color.White;
            BtnAddActivity.Location = new Point(444, 586);
            BtnAddActivity.Name = "BtnAddActivity";
            BtnAddActivity.Size = new Size(53, 23);
            BtnAddActivity.TabIndex = 31;
            BtnAddActivity.Text = "Add";
            BtnAddActivity.UseVisualStyleBackColor = false;
            BtnAddActivity.Click += BtnAddActivity_Click;
            // 
            // TxtSearchPetActivity
            // 
            TxtSearchPetActivity.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            TxtSearchPetActivity.Location = new Point(36, 204);
            TxtSearchPetActivity.Name = "TxtSearchPetActivity";
            TxtSearchPetActivity.PlaceholderText = "Search Pet Activity";
            TxtSearchPetActivity.Size = new Size(169, 25);
            TxtSearchPetActivity.TabIndex = 34;
            TxtSearchPetActivity.TextChanged += TxtSearchPetActivity_TextChanged;
            // 
            // PetActivitiesForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(645, 644);
            Controls.Add(TxtSearchPetActivity);
            Controls.Add(BtnUpdateActivity);
            Controls.Add(BtnDeleteActivity);
            Controls.Add(BtnAddActivity);
            Controls.Add(DtpPetActivitiesTo);
            Controls.Add(LblTo);
            Controls.Add(LblFrom);
            Controls.Add(DtpPetActivitiesFrom);
            Controls.Add(DgvPetActivities);
            Controls.Add(TxtOwner);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(TxtPetName);
            Controls.Add(label1);
            Controls.Add(BtnClose);
            FormBorderStyle = FormBorderStyle.None;
            Name = "PetActivitiesForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "PetActivitiesForm";
            Load += PetActivitiesForm_Load;
            ((System.ComponentModel.ISupportInitialize)DgvPetActivities).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnClose;
        private Label label1;
        private TextBox TxtPetName;
        private Label label2;
        private DataGridView DgvPetActivities;
        private Label label3;
        private TextBox TxtOwner;
        private DateTimePicker DtpPetActivitiesTo;
        private Label LblTo;
        private Label LblFrom;
        private DateTimePicker DtpPetActivitiesFrom;
        private Button BtnUpdateActivity;
        private Button BtnDeleteActivity;
        private Button BtnAddActivity;
        private TextBox TxtSearchPetActivity;
    }
}