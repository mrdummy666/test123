﻿using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    public partial class PetActivityForm : Form
    {
        public PetActivityService petActivityService;
        public PetsService petsService;

        public int petId;
        public int petActivityId;
        public PetActivityForm(int petId, int petActivityId)
        {
            InitializeComponent();
            petActivityService = new();
            petsService = new();
            this.petId = petId;
            this.petActivityId = petActivityId;
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            string activity = TxtActivity.Text;
            string createdAt = DateTime.Now.ToString("yyyy-MM-dd H:mm:ss");
            string updatedAt = DateTime.Now.ToString("yyyy-MM-dd H:mm:ss");

            if (activity.Trim().Length == 0)
            {
                MessageBox.Show("Activity is required.", string.Format("{0} Pet Activity", petActivityId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                Response petActivityResponse = petActivityId == 0 ? petActivityService.CreatePetActivity(petId, activity, createdAt, updatedAt) : petActivityService.UpdatePetActivity(petActivityId, activity, updatedAt);

                if (petActivityResponse.Status)
                {
                    MessageBox.Show(petActivityResponse.Message, string.Format("{0} Pet Activity", petActivityId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Close();
                }
                else
                {
                    MessageBox.Show(petActivityResponse.Message, string.Format("{0} Pet Activity", petActivityId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void PetActivityForm_Load(object sender, EventArgs e)
        {
            TxtPetName.ReadOnly = true;
            TxtOwner.ReadOnly = true;
            //CBoxStatus.SelectedIndex = 0;


            Response getPetResponse = petsService.GetPet(petId);
            if (getPetResponse.Status)
            {
                Pet pet = getPetResponse.Payload!;
                TxtPetName.Text = pet.PetName;

                Response getOwnerNameResponse = petsService.GetOwnerName(pet.OwnerId);
                if (getOwnerNameResponse.Status)
                {
                    TxtOwner.Text = getOwnerNameResponse.Payload!;

                    if (petActivityId != 0)
                    {
                        Response getPetActivityResponse = petActivityService.GetPetActivity(petActivityId);
                        if (getPetActivityResponse.Status)
                        {
                            PetActivity petActivity = getPetActivityResponse.Payload!;
                            TxtActivity.Text = petActivity.Activity;
                            //DtpSchedule.Value = petActivity.Schedule;
                            //switch (petActivity.Status)
                            //{
                            //    case 1:
                            //        CBoxStatus.SelectedIndex = 0;
                            //        break;
                            //    case 2:
                            //        CBoxStatus.SelectedIndex = 1;
                            //        break;
                            //    case 3:
                            //        CBoxStatus.Items.Add("Expired");
                            //        CBoxStatus.SelectedIndex = 2;
                            //        break;
                            //    default:
                            //        break;
                            //}
                        }
                        else
                        {
                            MessageBox.Show(getPetActivityResponse.Message, string.Format("{0} Pet Activity", petActivityId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show(getOwnerNameResponse.Message, string.Format("{0} Pet Activity", petActivityId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show(getPetResponse.Message, string.Format("{0} Pet Activity", petActivityId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
