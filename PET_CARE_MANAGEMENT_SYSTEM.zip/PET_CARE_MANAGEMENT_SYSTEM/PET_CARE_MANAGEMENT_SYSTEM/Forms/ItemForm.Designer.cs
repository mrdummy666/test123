﻿namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    partial class ItemForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            BtnClose = new Button();
            LblTitle = new Label();
            panel1 = new Panel();
            NumQuantity = new NumericUpDown();
            TxtAmount = new TextBox();
            TxtSearchProduct = new TextBox();
            DgvProducts = new DataGridView();
            label6 = new Label();
            BtnSave = new Button();
            label5 = new Label();
            label4 = new Label();
            TxtPrice = new TextBox();
            label3 = new Label();
            label2 = new Label();
            TxtItemName = new TextBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)NumQuantity).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DgvProducts).BeginInit();
            SuspendLayout();
            // 
            // BtnClose
            // 
            BtnClose.BackColor = Color.Red;
            BtnClose.Cursor = Cursors.Hand;
            BtnClose.FlatAppearance.BorderSize = 0;
            BtnClose.FlatStyle = FlatStyle.Flat;
            BtnClose.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            BtnClose.ForeColor = Color.White;
            BtnClose.Location = new Point(736, 1);
            BtnClose.Name = "BtnClose";
            BtnClose.Size = new Size(42, 34);
            BtnClose.TabIndex = 6;
            BtnClose.Text = "X";
            BtnClose.UseVisualStyleBackColor = false;
            BtnClose.Click += BtnClose_Click;
            // 
            // LblTitle
            // 
            LblTitle.AutoSize = true;
            LblTitle.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            LblTitle.ForeColor = Color.Black;
            LblTitle.Location = new Point(4, 5);
            LblTitle.Name = "LblTitle";
            LblTitle.Size = new Size(45, 20);
            LblTitle.TabIndex = 8;
            LblTitle.Text = "ITEM";
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(NumQuantity);
            panel1.Controls.Add(TxtAmount);
            panel1.Controls.Add(TxtSearchProduct);
            panel1.Controls.Add(DgvProducts);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(BtnSave);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(TxtPrice);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(TxtItemName);
            panel1.Location = new Point(23, 38);
            panel1.Name = "panel1";
            panel1.Size = new Size(734, 380);
            panel1.TabIndex = 24;
            // 
            // NumQuantity
            // 
            NumQuantity.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            NumQuantity.Location = new Point(13, 160);
            NumQuantity.Name = "NumQuantity";
            NumQuantity.Size = new Size(253, 27);
            NumQuantity.TabIndex = 23;
            NumQuantity.ValueChanged += NumQuantity_ValueChanged;
            NumQuantity.KeyUp += NumQuantity_KeyUp;
            // 
            // TxtAmount
            // 
            TxtAmount.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtAmount.Location = new Point(13, 219);
            TxtAmount.Name = "TxtAmount";
            TxtAmount.Size = new Size(253, 27);
            TxtAmount.TabIndex = 22;
            // 
            // TxtSearchProduct
            // 
            TxtSearchProduct.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            TxtSearchProduct.Location = new Point(529, 15);
            TxtSearchProduct.Name = "TxtSearchProduct";
            TxtSearchProduct.PlaceholderText = "Search Product";
            TxtSearchProduct.Size = new Size(189, 25);
            TxtSearchProduct.TabIndex = 21;
            TxtSearchProduct.TextChanged += TxtSearchOwner_TextChanged;
            // 
            // DgvProducts
            // 
            DgvProducts.AllowUserToAddRows = false;
            DgvProducts.AllowUserToDeleteRows = false;
            DgvProducts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvProducts.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.False;
            DgvProducts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            DgvProducts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvProducts.Location = new Point(293, 46);
            DgvProducts.Name = "DgvProducts";
            DgvProducts.ReadOnly = true;
            DgvProducts.RowTemplate.Height = 25;
            DgvProducts.Size = new Size(425, 200);
            DgvProducts.TabIndex = 19;
            DgvProducts.CellClick += DgvProducts_CellClick;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(13, 198);
            label6.Name = "label6";
            label6.Size = new Size(53, 17);
            label6.TabIndex = 18;
            label6.Text = "Amount";
            // 
            // BtnSave
            // 
            BtnSave.BackColor = SystemColors.Highlight;
            BtnSave.Cursor = Cursors.Hand;
            BtnSave.FlatAppearance.BorderSize = 0;
            BtnSave.FlatStyle = FlatStyle.Flat;
            BtnSave.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnSave.ForeColor = Color.White;
            BtnSave.Location = new Point(309, 332);
            BtnSave.Name = "BtnSave";
            BtnSave.Size = new Size(113, 34);
            BtnSave.TabIndex = 5;
            BtnSave.Text = "Add";
            BtnSave.UseVisualStyleBackColor = false;
            BtnSave.Click += BtnSave_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(293, 25);
            label5.Name = "label5";
            label5.Size = new Size(59, 17);
            label5.TabIndex = 15;
            label5.Text = "Products";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(13, 141);
            label4.Name = "label4";
            label4.Size = new Size(56, 17);
            label4.TabIndex = 13;
            label4.Text = "Quantity";
            // 
            // TxtPrice
            // 
            TxtPrice.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtPrice.Location = new Point(13, 103);
            TxtPrice.Name = "TxtPrice";
            TxtPrice.Size = new Size(253, 27);
            TxtPrice.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(13, 84);
            label3.Name = "label3";
            label3.Size = new Size(36, 17);
            label3.TabIndex = 11;
            label3.Text = "Price";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(13, 25);
            label2.Name = "label2";
            label2.Size = new Size(72, 17);
            label2.TabIndex = 10;
            label2.Text = "Item Name";
            // 
            // TxtItemName
            // 
            TxtItemName.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtItemName.Location = new Point(13, 46);
            TxtItemName.Name = "TxtItemName";
            TxtItemName.Size = new Size(253, 27);
            TxtItemName.TabIndex = 0;
            // 
            // ItemForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(779, 430);
            Controls.Add(panel1);
            Controls.Add(LblTitle);
            Controls.Add(BtnClose);
            FormBorderStyle = FormBorderStyle.None;
            Name = "ItemForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "NewPetForm";
            Load += NewPetForm_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)NumQuantity).EndInit();
            ((System.ComponentModel.ISupportInitialize)DgvProducts).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnClose;
        private Label LblTitle;
        private TextBox TxtItemName;
        private Label label2;
        private Label label3;
        private TextBox TxtPrice;
        private Label label4;
        private Label label5;
        private Button BtnSave;
        private Label label6;
        private DataGridView DgvProducts;
        private TextBox TxtSearchProduct;
        private TextBox TxtAmount;
        private NumericUpDown NumQuantity;
        private Panel panel1;
    }
}