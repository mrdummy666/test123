﻿using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    public partial class NewProductForm : Form
    {
        public CategoriesService categoriesService;
        public ProductsService productsService;
        private List<Category> categories = new();
        public NewProductForm()
        {
            InitializeComponent();
            categoriesService = new();
            productsService = new();
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            string name = TxtName.Text.Trim();
            string description = TxtDescription.Text.Trim();
            int quantity = (int)NumQuantity.Value;
            decimal price = Convert.ToDecimal(TxtPrice.Text.Trim());
            string categoryName = CboxCategory.SelectedItem != null ? CboxCategory.SelectedItem.ToString()! : "";
            string expiredAt = DtpExpirationDate.Value.ToString("yyyy-MM-dd H:mm:ss");

            if (name.Length == 0 || description.Length == 0 || categoryName.Length == 0)
            {
                MessageBox.Show("All fields are required.", "New Product", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Response checkProductName = productsService.CheckProductName(name);

                if (checkProductName.Status)
                {
                    Response getCategoryNameResponse = categoriesService.GetCategoryIdByName(categoryName);

                    if (getCategoryNameResponse.Status)
                    {
                        Response createProductResponse = productsService.CreateProduct(getCategoryNameResponse.Payload!, name, description, quantity, price, DtpExpirationDate.Visible ? expiredAt : null);
                        if (createProductResponse.Status)
                        {
                            MessageBox.Show(createProductResponse.Message, "New Product", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            MainForm.ToRefreshProductsTable = true;
                            Close();
                        }
                        else
                        {
                            MessageBox.Show(createProductResponse.Message, "New Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show(getCategoryNameResponse.Message, "New Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show(checkProductName.Message, "New Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void NewProductForm_Load(object sender, EventArgs e)
        {
            TxtPrice.Text = "0.00";
            DtpExpirationDate.MinDate = DateTime.Now.AddDays(1);

            Response getCategoriesResponse = categoriesService.GetCategories();
            if (getCategoriesResponse.Status)
            {
                categories = getCategoriesResponse.Payload!;
                foreach (Category category in categories)
                {
                    CboxCategory.Items.Add(category.Name);
                }
                if (categories.Count > 0)
                {
                    CboxCategory.SelectedIndex = 0;
                    string categoryName = CboxCategory.SelectedItem!.ToString()!;

                    int hasExpiration = categories.Where(c => c.Name == categoryName).FirstOrDefault()!.HasExpiration;

                    LblExpirationDate.Visible = hasExpiration == 1;
                    DtpExpirationDate.Visible = hasExpiration == 1;
                };

            }
            else
            {
                MessageBox.Show(getCategoriesResponse.Message, "New Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TxtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            // allows 0-9, backspace, and decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }

            // checks to make sure only 1 decimal is allowed
            if (e.KeyChar == 46)
            {
                if (((TextBox)sender).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }

        private void CboxCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            string categoryName = CboxCategory.SelectedItem!.ToString()!;

            int hasExpiration = categories.Where(c => c.Name == categoryName).FirstOrDefault()!.HasExpiration;

            LblExpirationDate.Visible = hasExpiration == 1;
            DtpExpirationDate.Visible = hasExpiration == 1;
        }
    }
}
