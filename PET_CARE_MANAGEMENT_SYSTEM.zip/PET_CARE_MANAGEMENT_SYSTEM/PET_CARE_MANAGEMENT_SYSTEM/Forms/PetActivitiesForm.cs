﻿using Mysqlx.Crud;
using Org.BouncyCastle.Asn1.X509;
using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    public partial class PetActivitiesForm : Form
    {
        public PetActivityService petActivityService;
        public PetsService petsService;
        public int petId;
        public PetActivitiesForm(int petId)
        {
            InitializeComponent();
            petActivityService = new();
            petsService = new();
            this.petId = petId;
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void PetActivitiesForm_Load(object sender, EventArgs e)
        {
            TxtPetName.ReadOnly = true;
            TxtOwner.ReadOnly = true;

            DtpPetActivitiesFrom.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            DtpPetActivitiesTo.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month));

            Response getPetResponse = petsService.GetPet(petId);

            if (getPetResponse.Status)
            {
                Pet pet = getPetResponse.Payload!;
                TxtPetName.Text = pet.PetName;

                Response getOwnerNameResponse = petsService.GetOwnerName(pet.OwnerId);
                if (getOwnerNameResponse.Status)
                {
                    TxtOwner.Text = getOwnerNameResponse.Payload!;
                }
                else
                {
                    MessageBox.Show(getOwnerNameResponse.Message, "Pet Activities", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show(getPetResponse.Message, "Pet Activities", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            RefreshPetActivitiesTable();

            DgvPetActivities.MultiSelect = false;
            if (DgvPetActivities.Rows.Count > 0) DgvPetActivities.Rows[0].Selected = true;

            BtnUpdateActivity.Enabled = DgvPetActivities.Rows.Count > 0;
            BtnDeleteActivity.Enabled = DgvPetActivities.Rows.Count > 0;

        }

        private void RefreshPetActivitiesTable(string filter = "")
        {
            Response getPetActivitiesResponse = petActivityService.GetPetActivities(petId);

            if (getPetActivitiesResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Activity", typeof(string)));
                dt.Columns.Add(new DataColumn("Date", typeof(string)));
                //dt.Columns.Add(new DataColumn("Status", typeof(string)));

                List<PetActivity> petActivities = getPetActivitiesResponse.Payload!;

                foreach (PetActivity petActivity in petActivities)
                {
                    string activity = petActivity.Activity;
                    string createdAt = petActivity.CreatedAt.ToString("MMMM dd, yyyy hh:mm:ss tt");

                    // 1 = Pending
                    // 2 = Completed
                    // 3 = Expired
                    //string status = petActivity.Status == 1 ? "Pending" : (petActivity.Status == 2 ? "Completed" : "Expired");

                    bool toAdd = (filter == "" || (activity.ToUpper().Contains(filter) || createdAt.ToUpper().Contains(filter))) && (petActivity.CreatedAt.Date >= DtpPetActivitiesFrom.Value && petActivity.CreatedAt.Date <= DtpPetActivitiesTo.Value);

                    if (toAdd)
                    {
                        DataRow dr = dt.NewRow();
                        dr["Id"] = petActivity.Id;
                        dr["Activity"] = activity;
                        dr["Date"] = createdAt;
                        //dr["Status"] = status;
                        dt.Rows.Add(dr);
                    }
                }
                DgvPetActivities.DataSource = dt;
                DgvPetActivities.Columns["Id"].Visible = false;
            }
            else
            {
                MessageBox.Show(getPetActivitiesResponse.Message, "Pet Activities", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TxtSearchPetActivity_TextChanged(object sender, EventArgs e)
        {
            RefreshPetActivitiesTable(TxtSearchPetActivity.Text.Trim().ToUpper());
        }

        private void DtpPetActivitiesFrom_ValueChanged(object sender, EventArgs e)
        {
            RefreshPetActivitiesTable();
        }

        private void DtpPetActivitiesTo_ValueChanged(object sender, EventArgs e)
        {
            RefreshPetActivitiesTable();
        }

        private void BtnAddActivity_Click(object sender, EventArgs e)
        {
            Hide();
            PetActivityForm petActivityForm = new(petId, 0);
            petActivityForm.ShowDialog();
            Show();
            RefreshPetActivitiesTable();


            BtnDeleteActivity.Enabled = DgvPetActivities.Rows.Count > 0;
            BtnUpdateActivity.Enabled = DgvPetActivities.Rows.Count > 0;
        }

        private void BtnUpdateActivity_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvPetActivities.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvPetActivities.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            Hide();
            PetActivityForm petActivityForm = new(petId, id);
            petActivityForm.ShowDialog();
            Show();
            RefreshPetActivitiesTable();
        }

        private void BtnDeleteActivity_Click(object sender, EventArgs e)
        {
            int selectedRowIndex = DgvPetActivities.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = DgvPetActivities.Rows[selectedRowIndex];
            int id = int.Parse(Convert.ToString(selectedRow.Cells["Id"].Value)!);

            DialogResult dialogResult = MessageBox.Show("Are you sure to delete this Pet Activity?", "Delete Pet Activity", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                Response deletePetActivity = petActivityService.DeletePetActivity(id);
                if (deletePetActivity.Status)
                {
                    MessageBox.Show(deletePetActivity.Message, "Delete Pet Activity", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RefreshPetActivitiesTable();

                    BtnUpdateActivity.Enabled = DgvPetActivities.Rows.Count > 0;
                    BtnDeleteActivity.Enabled = DgvPetActivities.Rows.Count > 0; ;

                    TxtSearchPetActivity.Text = string.Empty;
                }
                else
                {
                    MessageBox.Show(deletePetActivity.Message, "Delete Pet Activity", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
