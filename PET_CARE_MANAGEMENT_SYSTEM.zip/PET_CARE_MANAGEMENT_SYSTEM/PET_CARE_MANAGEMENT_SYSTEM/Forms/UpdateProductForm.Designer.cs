﻿namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    partial class UpdateProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnClose = new Button();
            label1 = new Label();
            TxtName = new TextBox();
            label2 = new Label();
            label3 = new Label();
            TxtDescription = new TextBox();
            label4 = new Label();
            TxtPrice = new TextBox();
            label5 = new Label();
            BtnSave = new Button();
            label6 = new Label();
            CboxCategory = new ComboBox();
            NumQuantity = new NumericUpDown();
            DtpExpirationDate = new DateTimePicker();
            LblExpirationDate = new Label();
            ((System.ComponentModel.ISupportInitialize)NumQuantity).BeginInit();
            SuspendLayout();
            // 
            // BtnClose
            // 
            BtnClose.BackColor = Color.Red;
            BtnClose.Cursor = Cursors.Hand;
            BtnClose.FlatAppearance.BorderSize = 0;
            BtnClose.FlatStyle = FlatStyle.Flat;
            BtnClose.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            BtnClose.ForeColor = Color.White;
            BtnClose.Location = new Point(281, 1);
            BtnClose.Name = "BtnClose";
            BtnClose.Size = new Size(42, 34);
            BtnClose.TabIndex = 6;
            BtnClose.Text = "X";
            BtnClose.UseVisualStyleBackColor = false;
            BtnClose.Click += BtnClose_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(4, 5);
            label1.Name = "label1";
            label1.Size = new Size(141, 20);
            label1.TabIndex = 8;
            label1.Text = "UPDATE PRODUCT";
            // 
            // TxtName
            // 
            TxtName.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtName.Location = new Point(36, 86);
            TxtName.Name = "TxtName";
            TxtName.Size = new Size(253, 27);
            TxtName.TabIndex = 0;
            TxtName.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(36, 65);
            label2.Name = "label2";
            label2.Size = new Size(92, 17);
            label2.TabIndex = 10;
            label2.Text = "Product Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(36, 124);
            label3.Name = "label3";
            label3.Size = new Size(123, 17);
            label3.TabIndex = 11;
            label3.Text = "Product Description";
            // 
            // TxtDescription
            // 
            TxtDescription.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtDescription.Location = new Point(36, 143);
            TxtDescription.Multiline = true;
            TxtDescription.Name = "TxtDescription";
            TxtDescription.Size = new Size(253, 91);
            TxtDescription.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(36, 244);
            label4.Name = "label4";
            label4.Size = new Size(36, 17);
            label4.TabIndex = 13;
            label4.Text = "Price";
            // 
            // TxtPrice
            // 
            TxtPrice.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            TxtPrice.Location = new Point(36, 264);
            TxtPrice.Name = "TxtPrice";
            TxtPrice.Size = new Size(253, 27);
            TxtPrice.TabIndex = 4;
            TxtPrice.KeyPress += TxtPrice_KeyPress;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(36, 362);
            label5.Name = "label5";
            label5.Size = new Size(61, 17);
            label5.TabIndex = 15;
            label5.Text = "Category";
            // 
            // BtnSave
            // 
            BtnSave.BackColor = SystemColors.Highlight;
            BtnSave.Cursor = Cursors.Hand;
            BtnSave.FlatAppearance.BorderSize = 0;
            BtnSave.FlatStyle = FlatStyle.Flat;
            BtnSave.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnSave.ForeColor = Color.White;
            BtnSave.Location = new Point(105, 489);
            BtnSave.Name = "BtnSave";
            BtnSave.Size = new Size(113, 34);
            BtnSave.TabIndex = 5;
            BtnSave.Text = "Save";
            BtnSave.UseVisualStyleBackColor = false;
            BtnSave.Click += BtnSave_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(36, 301);
            label6.Name = "label6";
            label6.Size = new Size(56, 17);
            label6.TabIndex = 18;
            label6.Text = "Quantity";
            // 
            // CboxCategory
            // 
            CboxCategory.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            CboxCategory.FormattingEnabled = true;
            CboxCategory.Location = new Point(36, 382);
            CboxCategory.Name = "CboxCategory";
            CboxCategory.Size = new Size(253, 29);
            CboxCategory.TabIndex = 3;
            CboxCategory.SelectedIndexChanged += CboxCategory_SelectedIndexChanged;
            // 
            // NumQuantity
            // 
            NumQuantity.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            NumQuantity.Location = new Point(36, 321);
            NumQuantity.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
            NumQuantity.Name = "NumQuantity";
            NumQuantity.Size = new Size(253, 27);
            NumQuantity.TabIndex = 19;
            // 
            // DtpExpirationDate
            // 
            DtpExpirationDate.CalendarFont = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            DtpExpirationDate.CustomFormat = "MMMM dd, yyyy";
            DtpExpirationDate.Format = DateTimePickerFormat.Custom;
            DtpExpirationDate.Location = new Point(36, 444);
            DtpExpirationDate.Name = "DtpExpirationDate";
            DtpExpirationDate.Size = new Size(253, 23);
            DtpExpirationDate.TabIndex = 27;
            // 
            // LblExpirationDate
            // 
            LblExpirationDate.AutoSize = true;
            LblExpirationDate.BackColor = Color.WhiteSmoke;
            LblExpirationDate.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            LblExpirationDate.Location = new Point(36, 425);
            LblExpirationDate.Name = "LblExpirationDate";
            LblExpirationDate.Size = new Size(97, 17);
            LblExpirationDate.TabIndex = 26;
            LblExpirationDate.Text = "Expiration Date";
            // 
            // UpdateProductForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(324, 535);
            Controls.Add(DtpExpirationDate);
            Controls.Add(LblExpirationDate);
            Controls.Add(NumQuantity);
            Controls.Add(CboxCategory);
            Controls.Add(label6);
            Controls.Add(BtnSave);
            Controls.Add(TxtPrice);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(TxtDescription);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(TxtName);
            Controls.Add(label1);
            Controls.Add(BtnClose);
            FormBorderStyle = FormBorderStyle.None;
            Name = "UpdateProductForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "UpdateProductForm";
            Load += UpdateProductForm_Load;
            ((System.ComponentModel.ISupportInitialize)NumQuantity).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnClose;
        private Label label1;
        private TextBox TxtName;
        private Label label2;
        private Label label3;
        private TextBox TxtDescription;
        private Label label4;
        private TextBox TxtPrice;
        private Label label5;
        private Button BtnSave;
        private Label label6;
        private ComboBox CboxCategory;
        private NumericUpDown NumQuantity;
        private DateTimePicker DtpExpirationDate;
        private Label LblExpirationDate;
    }
}