﻿using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PET_CARE_MANAGEMENT_SYSTEM.Forms
{
    public partial class ItemForm : Form
    {
        private readonly ProductsService productsService;
        public int itemId;
        public int orderId;
        public Product? selectedProduct = null;
        public ItemForm(int orderId, int itemId = 0)
        {
            InitializeComponent();
            productsService = new();
            this.orderId = orderId;
            this.itemId = itemId;
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            //OrderItem? item = OrderForm.orderItems.FirstOrDefault(oi => oi.ItemId == selectedProduct!.Id);

            int index = OrderForm.orderItems.FindIndex(oi => oi.ItemId == selectedProduct!.Id);

            if (index > -1)
            {
                OrderItem toUpdate = OrderForm.orderItems[index];
                //if (itemId != 0)
                //{
                //    toUpdate.Quantity = (int)NumQuantity.Value;
                //    toUpdate.Total = Convert.ToDecimal(TxtAmount.Text);
                //    toUpdate.Status = 1;
                //}
                //else
                //{
                //    toUpdate.Quantity += (int)NumQuantity.Value;
                //    toUpdate.Total = Convert.ToDecimal(TxtAmount.Text);
                //    toUpdate.Status = 1;
                //}
                toUpdate.Quantity = (int)NumQuantity.Value;
                toUpdate.Total = Convert.ToDecimal(TxtAmount.Text);
                toUpdate.Status = 1;
                OrderForm.orderItems[index] = toUpdate;
            }
            else
            {
                OrderForm.orderItems.Add(new OrderItem
                {
                    Id = OrderForm.orderItems.Count * -1,
                    ItemId = selectedProduct!.Id,
                    OrderId = orderId,
                    Price = selectedProduct!.Price,
                    Quantity = (int)NumQuantity.Value,
                    Total = Convert.ToDecimal(TxtAmount.Text),
                    Status = 1
                });
            }



            Close();
        }

        private void NewPetForm_Load(object sender, EventArgs e)
        {
            DgvProducts.MultiSelect = false;
            RefreshProductsTable();
            BtnSave.Enabled = false;
            //if (DgvProducts.Rows.Count > 0) DgvProducts.Rows[0].Selected = true;

            TxtItemName.ReadOnly = true;
            TxtPrice.ReadOnly = true;
            TxtAmount.ReadOnly = true;
            NumQuantity.Enabled = false;


            //if (orderId == 0)
            //{
            // NEW ITEM
            if (itemId == 0)
            {
                // CREATE
                LblTitle.Text = "ADD ITEM";

                TxtPrice.Text = "0.00";
                NumQuantity.Value = 0;
                TxtAmount.Text = "0.00";
            }
            else
            {
                //UPDATE
                LblTitle.Text = "UPDATE ITEM";
                OrderItem item = OrderForm.orderItems.FirstOrDefault(oi => oi.ItemId == itemId)!;
                Product product = productsService.GetProduct(itemId).Payload!;

                selectedProduct = new Product
                {
                    Id = itemId,
                    Name = product.Name,
                    //Quantity = product.Quantity - item.Quantity,
                    Quantity = product.Quantity,
                    Price = item.Price
                };

                TxtItemName.Text = product.Name;
                TxtPrice.Text = $"{item.Price:n}";
                //NumQuantity.Maximum = item.Quantity;
                NumQuantity.Value = item.Quantity > product.Quantity ? product.Quantity : item.Quantity;
                NumQuantity.Minimum = 1;
                TxtAmount.Text = $"{item.Total:n}";

                NumQuantity.Enabled = true;

                DgvProducts.Enabled = false;
                TxtSearchProduct.Enabled = false;

                BtnSave.Enabled = true;
            }
            //}
            //else
            //{
            //    // UPDATE
            //    LblTitle.Text = "UPDATE ITEM";
            //    OrderItem item = OrderForm.orderItems.FirstOrDefault(oi => oi.ItemId == itemId)!;
            //    Product product = productsService.GetProduct(itemId).Payload!;

            //    selectedProduct = new Product
            //    {
            //        Id = itemId,
            //        Name = product.Name,
            //        Quantity = product.Quantity - item.Quantity,
            //        Price = item.Price
            //    };

            //    TxtItemName.Text = product.Name;
            //    TxtPrice.Text = $"{item.Price:n}";
            //    //NumQuantity.Maximum = item.Quantity;
            //    NumQuantity.Value = item.Quantity;
            //    TxtAmount.Text = $"{item.Total:n}";

            //    NumQuantity.Enabled = true;

            //    DgvProducts.Enabled = false;
            //    TxtSearchProduct.Enabled = false;

            //    BtnSave.Enabled = true;

            //}
        }

        private void RefreshProductsTable(string filter = "")
        {
            Response getProductsResponse = productsService.GetOrderProducts();

            if (getProductsResponse.Status)
            {
                DataTable dt = new();
                dt.Columns.Add(new DataColumn("Id", typeof(int)));
                dt.Columns.Add(new DataColumn("Name", typeof(string)));
                dt.Columns.Add(new DataColumn("Description", typeof(string)));
                dt.Columns.Add(new DataColumn("Available Qty", typeof(string)));
                dt.Columns.Add(new DataColumn("Price", typeof(string)));

                List<Product> products = getProductsResponse.Payload!;

                int selectedIndex = 0;
                int ctr = 0;
                foreach (Product product in products)
                {
                    string name = product.Name;
                    string description = product.Description;
                    int quantity = product.Quantity;
                    decimal price = product.Price;

                    if (name.ToUpper().Contains(filter) || description.ToUpper().Contains(filter) || quantity.ToString().Contains(filter) || price.ToString().Contains(filter))
                    {

                        //OrderItem? foundItem = OrderForm.orderItems.FirstOrDefault(oi => oi.ItemId == product.Id);

                        //if (foundItem != null)
                        //{
                        //    quantity -= foundItem.Quantity;
                        //}

                        if (itemId != 0)
                        {
                            if (itemId == product.Id)
                            {
                                selectedIndex = ctr;
                                NumQuantity.Maximum = product.Quantity;
                            }
                            ctr++;
                        }

                        DataRow dr = dt.NewRow();
                        dr["Id"] = product.Id;
                        dr["Name"] = name;
                        dr["Description"] = description;
                        dr["Available Qty"] = $"{quantity:n0}";
                        dr["price"] = $"{price:n}";
                        dt.Rows.Add(dr);
                    }
                }

                DgvProducts.DataSource = dt;
                DgvProducts.Columns["Id"].Visible = false;
                if (itemId != 0) DgvProducts.Rows[selectedIndex].Selected = true;
            }
            else
            {
                MessageBox.Show(getProductsResponse.Message, string.Format("{0} Item", itemId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void TxtSearchOwner_TextChanged(object sender, EventArgs e)
        {
            RefreshProductsTable(TxtSearchProduct.Text.Trim().ToUpper());
        }

        private void DgvProducts_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            if (index > -1)
            {
                int id = (int)DgvProducts.Rows[index].Cells[0].Value;
                string name = (string)DgvProducts.Rows[index].Cells[1].Value;
                int availQty = int.Parse(DgvProducts.Rows[index].Cells[3].Value.ToString()!.Replace(",", ""));
                decimal price = Convert.ToDecimal(DgvProducts.Rows[index].Cells[4].Value);

                if (availQty > 0)
                {
                    selectedProduct = new Product
                    {
                        Id = id,
                        Name = name,
                        Quantity = availQty,
                        Price = price,
                    };
                    TxtItemName.Text = selectedProduct.Name;
                    TxtPrice.Text = $"{selectedProduct.Price:n}";
                    NumQuantity.Value = 1;
                    TxtAmount.Text = $"{selectedProduct.Price:n}";

                    NumQuantity.Enabled = true;
                    NumQuantity.Minimum = 1;
                    NumQuantity.Maximum = selectedProduct.Quantity;
                    BtnSave.Enabled = true;
                }
                else
                {
                    MessageBox.Show("There's no available quantity for this Item.", string.Format("{0} Item", itemId == 0 ? "New" : "Update"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }


        private void NumQuantity_KeyUp(object sender, KeyEventArgs e)
        {
            TxtAmount.Text = $"{(NumQuantity.Value * selectedProduct!.Price):n}";
        }

        private void NumQuantity_ValueChanged(object sender, EventArgs e)
        {
            TxtAmount.Text = $"{(NumQuantity.Value * selectedProduct!.Price):n}";
        }
    }
}
