﻿using MySql.Data.MySqlClient;
using PET_CARE_MANAGEMENT_SYSTEM.Models;
using PET_CARE_MANAGEMENT_SYSTEM.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace PET_CARE_MANAGEMENT_SYSTEM.Services
{
    public class CashiersService
    {

        public DBConnect db;

        public CashiersService() => db = new DBConnect();


        // GET CASHIERS
        public Response GetCashiers ()
        {
            try
            {
                db.connection.Open();

                string query = "SELECT * FROM users WHERE role = 'C' AND status = 1";
                MySqlCommand cmd = new(query, db.connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                List<User> cashiers = new();

                while (dataReader.Read())
                {

                    cashiers.Add(new User
                    {
                        Id = (int)dataReader["id"],
                        Username = (string)dataReader["username"],
                        FirstName = (string)dataReader["firstName"],
                        MiddleName = (string)dataReader["middleName"],
                        LastName = (string)dataReader["lastName"],
                        Gender = dataReader["gender"].ToString()!.ToCharArray()[0],
                        Role = dataReader["role"].ToString()!.ToCharArray()[0],
                        IsInit = (int)dataReader["isInit"],
                        Status = (int)dataReader["status"],
                    });
                }

                dataReader.Close();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "",
                    Payload = cashiers
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // CREATE CASHIER
        public Response CreateCashier (string firstName, string middleName, string lastName, char gender, string username)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("INSERT INTO users (username, password, firstName, middleName, lastName, gender, role, isInit, status) " +
                    "VALUES('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', {7}, {8})", 
                    username, "12345", firstName, middleName, lastName, gender, 'C', 0, 1);

                MySqlCommand cmd = new (string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "New Cashier Created!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }

        // UPDATE CASHIER
        public Response UpdateCashier(int id, string firstName, string middleName, string lastName, char gender, string username)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("UPDATE users SET firstName = '{0}', middleName = '{1}', lastName = '{2}', gender = '{3}', username = '{4}' WHERE id = {5}",
                    firstName, middleName, lastName, gender, username, id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Cashier Successfully Updated!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }
    
        // DELETE CASHIER
        public Response DeleteCashier(int id)
        {
            try
            {
                db.connection.Open();

                string query = string.Format("UPDATE users SET status = 0 WHERE id = {0}", id);

                MySqlCommand cmd = new(string.Format(query), db.connection);
                cmd.ExecuteNonQuery();

                db.connection.Close();

                return new Response()
                {
                    Status = true,
                    Message = "Cashier Successfully Deleted!",
                    Payload = null
                };
            }
            catch (Exception ex)
            {
                db.connection.Close();

                return new Response()
                {
                    Status = false,
                    Message = ex.Message,
                    Payload = null
                };
            }
        }
    }
}
