﻿namespace PET_CARE_MANAGEMENT_SYSTEM
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            picCompany = new PictureBox();
            LblUsername = new Label();
            LblPassword = new Label();
            TxtUsername = new TextBox();
            TxtPassword = new TextBox();
            BtnLogin = new Button();
            BtnClose = new Button();
            ((System.ComponentModel.ISupportInitialize)picCompany).BeginInit();
            SuspendLayout();
            // 
            // picCompany
            // 
            picCompany.Image = (Image)resources.GetObject("picCompany.Image");
            picCompany.Location = new Point(-1, 38);
            picCompany.Name = "picCompany";
            picCompany.Size = new Size(474, 270);
            picCompany.SizeMode = PictureBoxSizeMode.StretchImage;
            picCompany.TabIndex = 0;
            picCompany.TabStop = false;
            // 
            // LblUsername
            // 
            LblUsername.AutoSize = true;
            LblUsername.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            LblUsername.Location = new Point(92, 341);
            LblUsername.Name = "LblUsername";
            LblUsername.Size = new Size(87, 21);
            LblUsername.TabIndex = 1;
            LblUsername.Text = "Username";
            LblUsername.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // LblPassword
            // 
            LblPassword.AutoSize = true;
            LblPassword.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            LblPassword.Location = new Point(92, 414);
            LblPassword.Name = "LblPassword";
            LblPassword.Size = new Size(82, 21);
            LblPassword.TabIndex = 2;
            LblPassword.Text = "Password";
            LblPassword.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // TxtUsername
            // 
            TxtUsername.Font = new Font("Segoe UI", 12.75F, FontStyle.Regular, GraphicsUnit.Point);
            TxtUsername.Location = new Point(92, 365);
            TxtUsername.MaxLength = 20;
            TxtUsername.Name = "TxtUsername";
            TxtUsername.Size = new Size(290, 30);
            TxtUsername.TabIndex = 3;
            TxtUsername.TextAlign = HorizontalAlignment.Center;
            // 
            // TxtPassword
            // 
            TxtPassword.Font = new Font("Segoe UI", 12.75F, FontStyle.Regular, GraphicsUnit.Point);
            TxtPassword.Location = new Point(92, 438);
            TxtPassword.MaxLength = 20;
            TxtPassword.Name = "TxtPassword";
            TxtPassword.PasswordChar = '●';
            TxtPassword.Size = new Size(290, 30);
            TxtPassword.TabIndex = 4;
            TxtPassword.TextAlign = HorizontalAlignment.Center;
            // 
            // BtnLogin
            // 
            BtnLogin.BackColor = Color.MediumTurquoise;
            BtnLogin.Cursor = Cursors.Hand;
            BtnLogin.FlatAppearance.BorderSize = 0;
            BtnLogin.FlatStyle = FlatStyle.Flat;
            BtnLogin.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            BtnLogin.Location = new Point(92, 487);
            BtnLogin.Name = "BtnLogin";
            BtnLogin.Size = new Size(290, 45);
            BtnLogin.TabIndex = 5;
            BtnLogin.Text = "Login";
            BtnLogin.UseVisualStyleBackColor = false;
            BtnLogin.Click += BtnLogin_Click;
            // 
            // BtnClose
            // 
            BtnClose.BackColor = Color.Red;
            BtnClose.Cursor = Cursors.Hand;
            BtnClose.FlatAppearance.BorderSize = 0;
            BtnClose.FlatStyle = FlatStyle.Flat;
            BtnClose.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            BtnClose.ForeColor = Color.White;
            BtnClose.Location = new Point(431, 1);
            BtnClose.Name = "BtnClose";
            BtnClose.Size = new Size(42, 34);
            BtnClose.TabIndex = 6;
            BtnClose.Text = "X";
            BtnClose.UseVisualStyleBackColor = false;
            BtnClose.Click += BtnClose_Click;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(474, 599);
            Controls.Add(BtnClose);
            Controls.Add(BtnLogin);
            Controls.Add(TxtPassword);
            Controls.Add(TxtUsername);
            Controls.Add(LblPassword);
            Controls.Add(LblUsername);
            Controls.Add(picCompany);
            FormBorderStyle = FormBorderStyle.None;
            Name = "LoginForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "LOGIN";
            ((System.ComponentModel.ISupportInitialize)picCompany).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox picCompany;
        private Label LblUsername;
        private Label LblPassword;
        private TextBox TxtUsername;
        private TextBox TxtPassword;
        private Button BtnLogin;
        private Button BtnClose;
    }
}