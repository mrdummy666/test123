﻿namespace PET_CARE_MANAGEMENT_SYSTEM
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            DataGridViewCellStyle dataGridViewCellStyle10 = new DataGridViewCellStyle();
            panel1 = new Panel();
            TxtUserRole = new TextBox();
            TxtUserFullName = new TextBox();
            PicUser = new PictureBox();
            PnlAdminNav = new Panel();
            BtnAppointmentsAdmin = new Button();
            BtnOrdersAdmin = new Button();
            BtnCategoriesAdmin = new Button();
            BtnProductsAdmin = new Button();
            BtnPetsAdmin = new Button();
            BtnOwnersAdmin = new Button();
            BtnHomeAdmin = new Button();
            BtnCashiersAdmin = new Button();
            BtnLogoutAdmin = new Button();
            PnlCashierNav = new Panel();
            BtnProductsCashier = new Button();
            BtnOrdersCashier = new Button();
            BtnHomeCashier = new Button();
            BtnLogoutCashier = new Button();
            PnlCashiers = new Panel();
            TxtSearchCashier = new TextBox();
            BtnDeleteCashier = new Button();
            BtnUpdateCashier = new Button();
            BtnNewCashier = new Button();
            DgvCashiers = new DataGridView();
            PnlProducts = new Panel();
            TxtSearchProduct = new TextBox();
            BtnDeleteProduct = new Button();
            BtnUpdateProduct = new Button();
            BtnNewProduct = new Button();
            DgvProducts = new DataGridView();
            PnlCategories = new Panel();
            GrpBoxCategory = new GroupBox();
            ChkExpiration = new CheckBox();
            BtnCancelCategory = new Button();
            BtnSaveCategory = new Button();
            label1 = new Label();
            TxtCategory = new TextBox();
            TxtSearchCategory = new TextBox();
            BtnDeleteCategory = new Button();
            BtnUpdateCategory = new Button();
            BtnNewCategory = new Button();
            DgvCategories = new DataGridView();
            PnlOwners = new Panel();
            TxtSearchOwner = new TextBox();
            BtnDeleteOwner = new Button();
            BtnUpdateOwner = new Button();
            BtnNewOwner = new Button();
            DgvOwners = new DataGridView();
            PnlAppointments = new Panel();
            BtnDeleteAppointment = new Button();
            DtpAppointmentsTo = new DateTimePicker();
            label2 = new Label();
            label3 = new Label();
            DtpAppointmentsFrom = new DateTimePicker();
            TxtSearchAppointment = new TextBox();
            BtnUpdateAppointment = new Button();
            BtnNewAppointment = new Button();
            DgvAppointments = new DataGridView();
            PnlPets = new Panel();
            BtnActivitiesPet = new Button();
            TxtSearchPet = new TextBox();
            BtnDeletePet = new Button();
            BtnUpdatePet = new Button();
            BtnNewPet = new Button();
            DgvPets = new DataGridView();
            PnlHomeAdmin = new Panel();
            GrpTodaysAppointments = new GroupBox();
            DgvTodaysAppointments = new DataGridView();
            GrpExpiredAppointments = new GroupBox();
            DgvExpiredAppointments = new DataGridView();
            GrpExpiredProducts = new GroupBox();
            DgvExpiredProducts = new DataGridView();
            PnlHomeCashier = new Panel();
            PicCompany = new PictureBox();
            PnlOrders = new Panel();
            DtpOrdersTo = new DateTimePicker();
            LblTo = new Label();
            LblFrom = new Label();
            DtpOrdersFrom = new DateTimePicker();
            TxtSearchOrder = new TextBox();
            BtnUpdateOrder = new Button();
            BtnNewOrder = new Button();
            DgvOrders = new DataGridView();
            BtnViewOrder = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)PicUser).BeginInit();
            PnlAdminNav.SuspendLayout();
            PnlCashierNav.SuspendLayout();
            PnlCashiers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DgvCashiers).BeginInit();
            PnlProducts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DgvProducts).BeginInit();
            PnlCategories.SuspendLayout();
            GrpBoxCategory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DgvCategories).BeginInit();
            PnlOwners.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DgvOwners).BeginInit();
            PnlAppointments.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DgvAppointments).BeginInit();
            PnlPets.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DgvPets).BeginInit();
            PnlHomeAdmin.SuspendLayout();
            GrpTodaysAppointments.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DgvTodaysAppointments).BeginInit();
            GrpExpiredAppointments.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DgvExpiredAppointments).BeginInit();
            GrpExpiredProducts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DgvExpiredProducts).BeginInit();
            PnlHomeCashier.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)PicCompany).BeginInit();
            PnlOrders.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DgvOrders).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Transparent;
            panel1.Controls.Add(TxtUserRole);
            panel1.Controls.Add(TxtUserFullName);
            panel1.Controls.Add(PicUser);
            panel1.Controls.Add(PnlAdminNav);
            panel1.Controls.Add(PnlCashierNav);
            panel1.Location = new Point(-1, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(177, 633);
            panel1.TabIndex = 0;
            // 
            // TxtUserRole
            // 
            TxtUserRole.BackColor = Color.DarkTurquoise;
            TxtUserRole.BorderStyle = BorderStyle.None;
            TxtUserRole.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            TxtUserRole.Location = new Point(13, 165);
            TxtUserRole.Name = "TxtUserRole";
            TxtUserRole.Size = new Size(153, 18);
            TxtUserRole.TabIndex = 3;
            TxtUserRole.Text = "Role";
            TxtUserRole.TextAlign = HorizontalAlignment.Center;
            // 
            // TxtUserFullName
            // 
            TxtUserFullName.BackColor = Color.DarkTurquoise;
            TxtUserFullName.BorderStyle = BorderStyle.None;
            TxtUserFullName.Location = new Point(10, 185);
            TxtUserFullName.Name = "TxtUserFullName";
            TxtUserFullName.Size = new Size(156, 16);
            TxtUserFullName.TabIndex = 2;
            TxtUserFullName.Text = "User Fullname";
            TxtUserFullName.TextAlign = HorizontalAlignment.Center;
            // 
            // PicUser
            // 
            PicUser.Location = new Point(10, 13);
            PicUser.Name = "PicUser";
            PicUser.Size = new Size(156, 150);
            PicUser.SizeMode = PictureBoxSizeMode.StretchImage;
            PicUser.TabIndex = 0;
            PicUser.TabStop = false;
            // 
            // PnlAdminNav
            // 
            PnlAdminNav.BorderStyle = BorderStyle.FixedSingle;
            PnlAdminNav.Controls.Add(BtnAppointmentsAdmin);
            PnlAdminNav.Controls.Add(BtnOrdersAdmin);
            PnlAdminNav.Controls.Add(BtnCategoriesAdmin);
            PnlAdminNav.Controls.Add(BtnProductsAdmin);
            PnlAdminNav.Controls.Add(BtnPetsAdmin);
            PnlAdminNav.Controls.Add(BtnOwnersAdmin);
            PnlAdminNav.Controls.Add(BtnHomeAdmin);
            PnlAdminNav.Controls.Add(BtnCashiersAdmin);
            PnlAdminNav.Controls.Add(BtnLogoutAdmin);
            PnlAdminNav.Location = new Point(12, 207);
            PnlAdminNav.Name = "PnlAdminNav";
            PnlAdminNav.Size = new Size(156, 417);
            PnlAdminNav.TabIndex = 1;
            // 
            // BtnAppointmentsAdmin
            // 
            BtnAppointmentsAdmin.BackColor = Color.WhiteSmoke;
            BtnAppointmentsAdmin.Cursor = Cursors.Hand;
            BtnAppointmentsAdmin.FlatAppearance.BorderSize = 0;
            BtnAppointmentsAdmin.FlatStyle = FlatStyle.Flat;
            BtnAppointmentsAdmin.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnAppointmentsAdmin.ForeColor = Color.Black;
            BtnAppointmentsAdmin.Location = new Point(9, 91);
            BtnAppointmentsAdmin.Name = "BtnAppointmentsAdmin";
            BtnAppointmentsAdmin.Size = new Size(137, 37);
            BtnAppointmentsAdmin.TabIndex = 8;
            BtnAppointmentsAdmin.Text = "Appointments";
            BtnAppointmentsAdmin.UseVisualStyleBackColor = false;
            BtnAppointmentsAdmin.Click += BtnAppointmentsAdmin_Click;
            // 
            // BtnOrdersAdmin
            // 
            BtnOrdersAdmin.BackColor = Color.WhiteSmoke;
            BtnOrdersAdmin.Cursor = Cursors.Hand;
            BtnOrdersAdmin.FlatAppearance.BorderSize = 0;
            BtnOrdersAdmin.FlatStyle = FlatStyle.Flat;
            BtnOrdersAdmin.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOrdersAdmin.ForeColor = Color.Black;
            BtnOrdersAdmin.Location = new Point(9, 48);
            BtnOrdersAdmin.Name = "BtnOrdersAdmin";
            BtnOrdersAdmin.Size = new Size(137, 37);
            BtnOrdersAdmin.TabIndex = 7;
            BtnOrdersAdmin.Text = "Orders";
            BtnOrdersAdmin.UseVisualStyleBackColor = false;
            BtnOrdersAdmin.Click += BtnOrdersAdmin_Click;
            // 
            // BtnCategoriesAdmin
            // 
            BtnCategoriesAdmin.BackColor = Color.WhiteSmoke;
            BtnCategoriesAdmin.Cursor = Cursors.Hand;
            BtnCategoriesAdmin.FlatAppearance.BorderSize = 0;
            BtnCategoriesAdmin.FlatStyle = FlatStyle.Flat;
            BtnCategoriesAdmin.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnCategoriesAdmin.ForeColor = Color.Black;
            BtnCategoriesAdmin.Location = new Point(9, 263);
            BtnCategoriesAdmin.Name = "BtnCategoriesAdmin";
            BtnCategoriesAdmin.Size = new Size(137, 37);
            BtnCategoriesAdmin.TabIndex = 6;
            BtnCategoriesAdmin.Text = "Product Categories";
            BtnCategoriesAdmin.UseVisualStyleBackColor = false;
            BtnCategoriesAdmin.Click += BtnCategoriesAdmin_Click;
            // 
            // BtnProductsAdmin
            // 
            BtnProductsAdmin.BackColor = Color.WhiteSmoke;
            BtnProductsAdmin.Cursor = Cursors.Hand;
            BtnProductsAdmin.FlatAppearance.BorderSize = 0;
            BtnProductsAdmin.FlatStyle = FlatStyle.Flat;
            BtnProductsAdmin.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnProductsAdmin.ForeColor = Color.Black;
            BtnProductsAdmin.Location = new Point(9, 220);
            BtnProductsAdmin.Name = "BtnProductsAdmin";
            BtnProductsAdmin.Size = new Size(137, 37);
            BtnProductsAdmin.TabIndex = 5;
            BtnProductsAdmin.Text = "Products";
            BtnProductsAdmin.UseVisualStyleBackColor = false;
            BtnProductsAdmin.Click += BtnProductsAdmin_Click;
            // 
            // BtnPetsAdmin
            // 
            BtnPetsAdmin.BackColor = Color.WhiteSmoke;
            BtnPetsAdmin.Cursor = Cursors.Hand;
            BtnPetsAdmin.FlatAppearance.BorderSize = 0;
            BtnPetsAdmin.FlatStyle = FlatStyle.Flat;
            BtnPetsAdmin.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnPetsAdmin.ForeColor = Color.Black;
            BtnPetsAdmin.Location = new Point(9, 177);
            BtnPetsAdmin.Name = "BtnPetsAdmin";
            BtnPetsAdmin.Size = new Size(137, 37);
            BtnPetsAdmin.TabIndex = 4;
            BtnPetsAdmin.Text = "Pets";
            BtnPetsAdmin.UseVisualStyleBackColor = false;
            BtnPetsAdmin.Click += BtnPetsAdmin_Click;
            // 
            // BtnOwnersAdmin
            // 
            BtnOwnersAdmin.BackColor = Color.WhiteSmoke;
            BtnOwnersAdmin.Cursor = Cursors.Hand;
            BtnOwnersAdmin.FlatAppearance.BorderSize = 0;
            BtnOwnersAdmin.FlatStyle = FlatStyle.Flat;
            BtnOwnersAdmin.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOwnersAdmin.ForeColor = Color.Black;
            BtnOwnersAdmin.Location = new Point(9, 134);
            BtnOwnersAdmin.Name = "BtnOwnersAdmin";
            BtnOwnersAdmin.Size = new Size(137, 37);
            BtnOwnersAdmin.TabIndex = 3;
            BtnOwnersAdmin.Text = "Pet Owners";
            BtnOwnersAdmin.UseVisualStyleBackColor = false;
            BtnOwnersAdmin.Click += BtnOwnersAdmin_Click;
            // 
            // BtnHomeAdmin
            // 
            BtnHomeAdmin.BackColor = Color.WhiteSmoke;
            BtnHomeAdmin.Cursor = Cursors.Hand;
            BtnHomeAdmin.FlatAppearance.BorderSize = 0;
            BtnHomeAdmin.FlatStyle = FlatStyle.Flat;
            BtnHomeAdmin.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnHomeAdmin.ForeColor = Color.Black;
            BtnHomeAdmin.Location = new Point(9, 5);
            BtnHomeAdmin.Name = "BtnHomeAdmin";
            BtnHomeAdmin.Size = new Size(137, 37);
            BtnHomeAdmin.TabIndex = 2;
            BtnHomeAdmin.Text = "Home";
            BtnHomeAdmin.UseVisualStyleBackColor = false;
            BtnHomeAdmin.Click += BtnHomeAdmin_Click;
            // 
            // BtnCashiersAdmin
            // 
            BtnCashiersAdmin.BackColor = Color.WhiteSmoke;
            BtnCashiersAdmin.Cursor = Cursors.Hand;
            BtnCashiersAdmin.FlatAppearance.BorderSize = 0;
            BtnCashiersAdmin.FlatStyle = FlatStyle.Flat;
            BtnCashiersAdmin.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnCashiersAdmin.ForeColor = Color.Black;
            BtnCashiersAdmin.Location = new Point(9, 306);
            BtnCashiersAdmin.Name = "BtnCashiersAdmin";
            BtnCashiersAdmin.Size = new Size(137, 37);
            BtnCashiersAdmin.TabIndex = 1;
            BtnCashiersAdmin.Text = "Cashiers";
            BtnCashiersAdmin.UseVisualStyleBackColor = false;
            BtnCashiersAdmin.Click += BtnCashiersAdmin_Click;
            // 
            // BtnLogoutAdmin
            // 
            BtnLogoutAdmin.BackColor = Color.Red;
            BtnLogoutAdmin.Cursor = Cursors.Hand;
            BtnLogoutAdmin.FlatAppearance.BorderSize = 0;
            BtnLogoutAdmin.FlatStyle = FlatStyle.Flat;
            BtnLogoutAdmin.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnLogoutAdmin.ForeColor = Color.White;
            BtnLogoutAdmin.Location = new Point(9, 375);
            BtnLogoutAdmin.Name = "BtnLogoutAdmin";
            BtnLogoutAdmin.Size = new Size(137, 37);
            BtnLogoutAdmin.TabIndex = 0;
            BtnLogoutAdmin.Text = "Logout";
            BtnLogoutAdmin.UseVisualStyleBackColor = false;
            BtnLogoutAdmin.Click += BtnLogoutAdmin_Click;
            // 
            // PnlCashierNav
            // 
            PnlCashierNav.BorderStyle = BorderStyle.FixedSingle;
            PnlCashierNav.Controls.Add(BtnProductsCashier);
            PnlCashierNav.Controls.Add(BtnOrdersCashier);
            PnlCashierNav.Controls.Add(BtnHomeCashier);
            PnlCashierNav.Controls.Add(BtnLogoutCashier);
            PnlCashierNav.Location = new Point(12, 207);
            PnlCashierNav.Name = "PnlCashierNav";
            PnlCashierNav.Size = new Size(156, 417);
            PnlCashierNav.TabIndex = 3;
            // 
            // BtnProductsCashier
            // 
            BtnProductsCashier.BackColor = Color.WhiteSmoke;
            BtnProductsCashier.Cursor = Cursors.Hand;
            BtnProductsCashier.FlatAppearance.BorderSize = 0;
            BtnProductsCashier.FlatStyle = FlatStyle.Flat;
            BtnProductsCashier.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnProductsCashier.ForeColor = Color.Black;
            BtnProductsCashier.Location = new Point(9, 91);
            BtnProductsCashier.Name = "BtnProductsCashier";
            BtnProductsCashier.Size = new Size(137, 37);
            BtnProductsCashier.TabIndex = 4;
            BtnProductsCashier.Text = "Products";
            BtnProductsCashier.UseVisualStyleBackColor = false;
            BtnProductsCashier.Click += BtnProductsCashier_Click;
            // 
            // BtnOrdersCashier
            // 
            BtnOrdersCashier.BackColor = Color.WhiteSmoke;
            BtnOrdersCashier.Cursor = Cursors.Hand;
            BtnOrdersCashier.FlatAppearance.BorderSize = 0;
            BtnOrdersCashier.FlatStyle = FlatStyle.Flat;
            BtnOrdersCashier.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnOrdersCashier.ForeColor = Color.Black;
            BtnOrdersCashier.Location = new Point(9, 48);
            BtnOrdersCashier.Name = "BtnOrdersCashier";
            BtnOrdersCashier.Size = new Size(137, 37);
            BtnOrdersCashier.TabIndex = 3;
            BtnOrdersCashier.Text = "Orders";
            BtnOrdersCashier.UseVisualStyleBackColor = false;
            BtnOrdersCashier.Click += BtnOrdersCashier_Click;
            // 
            // BtnHomeCashier
            // 
            BtnHomeCashier.BackColor = Color.WhiteSmoke;
            BtnHomeCashier.Cursor = Cursors.Hand;
            BtnHomeCashier.FlatAppearance.BorderSize = 0;
            BtnHomeCashier.FlatStyle = FlatStyle.Flat;
            BtnHomeCashier.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnHomeCashier.ForeColor = Color.Black;
            BtnHomeCashier.Location = new Point(9, 5);
            BtnHomeCashier.Name = "BtnHomeCashier";
            BtnHomeCashier.Size = new Size(137, 37);
            BtnHomeCashier.TabIndex = 2;
            BtnHomeCashier.Text = "Home";
            BtnHomeCashier.UseVisualStyleBackColor = false;
            BtnHomeCashier.Click += BtnHomeCashier_Click;
            // 
            // BtnLogoutCashier
            // 
            BtnLogoutCashier.BackColor = Color.Red;
            BtnLogoutCashier.Cursor = Cursors.Hand;
            BtnLogoutCashier.FlatAppearance.BorderSize = 0;
            BtnLogoutCashier.FlatStyle = FlatStyle.Flat;
            BtnLogoutCashier.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnLogoutCashier.ForeColor = Color.White;
            BtnLogoutCashier.Location = new Point(9, 375);
            BtnLogoutCashier.Name = "BtnLogoutCashier";
            BtnLogoutCashier.Size = new Size(137, 37);
            BtnLogoutCashier.TabIndex = 0;
            BtnLogoutCashier.Text = "Logout";
            BtnLogoutCashier.UseVisualStyleBackColor = false;
            BtnLogoutCashier.Click += BtnLogoutCashier_Click;
            // 
            // PnlCashiers
            // 
            PnlCashiers.BackColor = Color.White;
            PnlCashiers.Controls.Add(TxtSearchCashier);
            PnlCashiers.Controls.Add(BtnDeleteCashier);
            PnlCashiers.Controls.Add(BtnUpdateCashier);
            PnlCashiers.Controls.Add(BtnNewCashier);
            PnlCashiers.Controls.Add(DgvCashiers);
            PnlCashiers.Location = new Point(185, 9);
            PnlCashiers.Name = "PnlCashiers";
            PnlCashiers.Size = new Size(837, 614);
            PnlCashiers.TabIndex = 1;
            PnlCashiers.Visible = false;
            // 
            // TxtSearchCashier
            // 
            TxtSearchCashier.Location = new Point(13, 10);
            TxtSearchCashier.Name = "TxtSearchCashier";
            TxtSearchCashier.PlaceholderText = "Search Cashier";
            TxtSearchCashier.Size = new Size(256, 23);
            TxtSearchCashier.TabIndex = 5;
            TxtSearchCashier.TextChanged += TxtSearchCashier_TextChanged;
            // 
            // BtnDeleteCashier
            // 
            BtnDeleteCashier.BackColor = Color.Red;
            BtnDeleteCashier.Cursor = Cursors.Hand;
            BtnDeleteCashier.FlatAppearance.BorderSize = 0;
            BtnDeleteCashier.FlatStyle = FlatStyle.Flat;
            BtnDeleteCashier.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnDeleteCashier.ForeColor = Color.White;
            BtnDeleteCashier.Location = new Point(712, 569);
            BtnDeleteCashier.Name = "BtnDeleteCashier";
            BtnDeleteCashier.Size = new Size(112, 35);
            BtnDeleteCashier.TabIndex = 3;
            BtnDeleteCashier.Text = "Delete";
            BtnDeleteCashier.UseVisualStyleBackColor = false;
            BtnDeleteCashier.Click += BtnDeleteCashier_Click;
            // 
            // BtnUpdateCashier
            // 
            BtnUpdateCashier.BackColor = Color.LimeGreen;
            BtnUpdateCashier.Cursor = Cursors.Hand;
            BtnUpdateCashier.FlatAppearance.BorderSize = 0;
            BtnUpdateCashier.FlatStyle = FlatStyle.Flat;
            BtnUpdateCashier.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnUpdateCashier.ForeColor = Color.White;
            BtnUpdateCashier.Location = new Point(594, 569);
            BtnUpdateCashier.Name = "BtnUpdateCashier";
            BtnUpdateCashier.Size = new Size(112, 35);
            BtnUpdateCashier.TabIndex = 2;
            BtnUpdateCashier.Text = "Update";
            BtnUpdateCashier.UseVisualStyleBackColor = false;
            BtnUpdateCashier.Click += BtnUpdateCashier_Click;
            // 
            // BtnNewCashier
            // 
            BtnNewCashier.BackColor = SystemColors.Highlight;
            BtnNewCashier.Cursor = Cursors.Hand;
            BtnNewCashier.FlatAppearance.BorderSize = 0;
            BtnNewCashier.FlatStyle = FlatStyle.Flat;
            BtnNewCashier.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnNewCashier.ForeColor = Color.White;
            BtnNewCashier.Location = new Point(476, 569);
            BtnNewCashier.Name = "BtnNewCashier";
            BtnNewCashier.Size = new Size(112, 35);
            BtnNewCashier.TabIndex = 1;
            BtnNewCashier.Text = "New";
            BtnNewCashier.UseVisualStyleBackColor = false;
            BtnNewCashier.Click += BtnNewCashier_Click;
            // 
            // DgvCashiers
            // 
            DgvCashiers.AllowUserToAddRows = false;
            DgvCashiers.AllowUserToDeleteRows = false;
            DgvCashiers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvCashiers.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.False;
            DgvCashiers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            DgvCashiers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvCashiers.Location = new Point(13, 39);
            DgvCashiers.Name = "DgvCashiers";
            DgvCashiers.ReadOnly = true;
            DgvCashiers.RowTemplate.Height = 25;
            DgvCashiers.Size = new Size(811, 520);
            DgvCashiers.TabIndex = 0;
            // 
            // PnlProducts
            // 
            PnlProducts.BackColor = Color.White;
            PnlProducts.Controls.Add(TxtSearchProduct);
            PnlProducts.Controls.Add(BtnDeleteProduct);
            PnlProducts.Controls.Add(BtnUpdateProduct);
            PnlProducts.Controls.Add(BtnNewProduct);
            PnlProducts.Controls.Add(DgvProducts);
            PnlProducts.Location = new Point(185, 9);
            PnlProducts.Name = "PnlProducts";
            PnlProducts.Size = new Size(837, 614);
            PnlProducts.TabIndex = 6;
            PnlProducts.Visible = false;
            // 
            // TxtSearchProduct
            // 
            TxtSearchProduct.Location = new Point(13, 10);
            TxtSearchProduct.Name = "TxtSearchProduct";
            TxtSearchProduct.PlaceholderText = "Search Product";
            TxtSearchProduct.Size = new Size(256, 23);
            TxtSearchProduct.TabIndex = 5;
            TxtSearchProduct.TextChanged += TxtSearchProduct_TextChanged;
            // 
            // BtnDeleteProduct
            // 
            BtnDeleteProduct.BackColor = Color.Red;
            BtnDeleteProduct.Cursor = Cursors.Hand;
            BtnDeleteProduct.FlatAppearance.BorderSize = 0;
            BtnDeleteProduct.FlatStyle = FlatStyle.Flat;
            BtnDeleteProduct.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnDeleteProduct.ForeColor = Color.White;
            BtnDeleteProduct.Location = new Point(712, 569);
            BtnDeleteProduct.Name = "BtnDeleteProduct";
            BtnDeleteProduct.Size = new Size(112, 35);
            BtnDeleteProduct.TabIndex = 3;
            BtnDeleteProduct.Text = "Delete";
            BtnDeleteProduct.UseVisualStyleBackColor = false;
            BtnDeleteProduct.Click += BtnDeleteProduct_Click;
            // 
            // BtnUpdateProduct
            // 
            BtnUpdateProduct.BackColor = Color.LimeGreen;
            BtnUpdateProduct.Cursor = Cursors.Hand;
            BtnUpdateProduct.FlatAppearance.BorderSize = 0;
            BtnUpdateProduct.FlatStyle = FlatStyle.Flat;
            BtnUpdateProduct.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnUpdateProduct.ForeColor = Color.White;
            BtnUpdateProduct.Location = new Point(594, 569);
            BtnUpdateProduct.Name = "BtnUpdateProduct";
            BtnUpdateProduct.Size = new Size(112, 35);
            BtnUpdateProduct.TabIndex = 2;
            BtnUpdateProduct.Text = "Update";
            BtnUpdateProduct.UseVisualStyleBackColor = false;
            BtnUpdateProduct.Click += BtnUpdateProduct_Click;
            // 
            // BtnNewProduct
            // 
            BtnNewProduct.BackColor = SystemColors.Highlight;
            BtnNewProduct.Cursor = Cursors.Hand;
            BtnNewProduct.FlatAppearance.BorderSize = 0;
            BtnNewProduct.FlatStyle = FlatStyle.Flat;
            BtnNewProduct.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnNewProduct.ForeColor = Color.White;
            BtnNewProduct.Location = new Point(476, 569);
            BtnNewProduct.Name = "BtnNewProduct";
            BtnNewProduct.Size = new Size(112, 35);
            BtnNewProduct.TabIndex = 1;
            BtnNewProduct.Text = "New";
            BtnNewProduct.UseVisualStyleBackColor = false;
            BtnNewProduct.Click += BtnNewProduct_Click;
            // 
            // DgvProducts
            // 
            DgvProducts.AllowUserToAddRows = false;
            DgvProducts.AllowUserToDeleteRows = false;
            DgvProducts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvProducts.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Control;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            DgvProducts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            DgvProducts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvProducts.Location = new Point(13, 39);
            DgvProducts.Name = "DgvProducts";
            DgvProducts.ReadOnly = true;
            DgvProducts.RowTemplate.Height = 25;
            DgvProducts.Size = new Size(811, 520);
            DgvProducts.TabIndex = 0;
            // 
            // PnlCategories
            // 
            PnlCategories.BackColor = Color.White;
            PnlCategories.Controls.Add(GrpBoxCategory);
            PnlCategories.Controls.Add(TxtSearchCategory);
            PnlCategories.Controls.Add(BtnDeleteCategory);
            PnlCategories.Controls.Add(BtnUpdateCategory);
            PnlCategories.Controls.Add(BtnNewCategory);
            PnlCategories.Controls.Add(DgvCategories);
            PnlCategories.Location = new Point(185, 9);
            PnlCategories.Name = "PnlCategories";
            PnlCategories.Size = new Size(837, 614);
            PnlCategories.TabIndex = 7;
            PnlCategories.Visible = false;
            // 
            // GrpBoxCategory
            // 
            GrpBoxCategory.Controls.Add(ChkExpiration);
            GrpBoxCategory.Controls.Add(BtnCancelCategory);
            GrpBoxCategory.Controls.Add(BtnSaveCategory);
            GrpBoxCategory.Controls.Add(label1);
            GrpBoxCategory.Controls.Add(TxtCategory);
            GrpBoxCategory.Location = new Point(425, 82);
            GrpBoxCategory.Name = "GrpBoxCategory";
            GrpBoxCategory.Size = new Size(377, 287);
            GrpBoxCategory.TabIndex = 6;
            GrpBoxCategory.TabStop = false;
            // 
            // ChkExpiration
            // 
            ChkExpiration.AutoSize = true;
            ChkExpiration.Location = new Point(21, 105);
            ChkExpiration.Name = "ChkExpiration";
            ChkExpiration.Size = new Size(79, 19);
            ChkExpiration.TabIndex = 9;
            ChkExpiration.Text = "Expiration";
            ChkExpiration.UseVisualStyleBackColor = true;
            // 
            // BtnCancelCategory
            // 
            BtnCancelCategory.BackColor = Color.Red;
            BtnCancelCategory.Cursor = Cursors.Hand;
            BtnCancelCategory.FlatAppearance.BorderSize = 0;
            BtnCancelCategory.FlatStyle = FlatStyle.Flat;
            BtnCancelCategory.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnCancelCategory.ForeColor = Color.White;
            BtnCancelCategory.Location = new Point(195, 230);
            BtnCancelCategory.Name = "BtnCancelCategory";
            BtnCancelCategory.Size = new Size(112, 35);
            BtnCancelCategory.TabIndex = 7;
            BtnCancelCategory.Text = "Cancel";
            BtnCancelCategory.UseVisualStyleBackColor = false;
            BtnCancelCategory.Click += BtnCancelCategory_Click;
            // 
            // BtnSaveCategory
            // 
            BtnSaveCategory.BackColor = Color.LimeGreen;
            BtnSaveCategory.Cursor = Cursors.Hand;
            BtnSaveCategory.FlatAppearance.BorderSize = 0;
            BtnSaveCategory.FlatStyle = FlatStyle.Flat;
            BtnSaveCategory.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnSaveCategory.ForeColor = Color.White;
            BtnSaveCategory.Location = new Point(78, 230);
            BtnSaveCategory.Name = "BtnSaveCategory";
            BtnSaveCategory.Size = new Size(112, 35);
            BtnSaveCategory.TabIndex = 7;
            BtnSaveCategory.Text = "Save";
            BtnSaveCategory.UseVisualStyleBackColor = false;
            BtnSaveCategory.Click += BtnSaveCategory_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(21, 37);
            label1.Name = "label1";
            label1.Size = new Size(55, 15);
            label1.TabIndex = 1;
            label1.Text = "Category";
            // 
            // TxtCategory
            // 
            TxtCategory.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            TxtCategory.Location = new Point(21, 57);
            TxtCategory.Name = "TxtCategory";
            TxtCategory.Size = new Size(335, 29);
            TxtCategory.TabIndex = 0;
            // 
            // TxtSearchCategory
            // 
            TxtSearchCategory.Location = new Point(13, 10);
            TxtSearchCategory.Name = "TxtSearchCategory";
            TxtSearchCategory.PlaceholderText = "Search Category";
            TxtSearchCategory.Size = new Size(256, 23);
            TxtSearchCategory.TabIndex = 5;
            TxtSearchCategory.TabStop = false;
            TxtSearchCategory.TextChanged += TxtSearchCategory_TextChanged;
            // 
            // BtnDeleteCategory
            // 
            BtnDeleteCategory.BackColor = Color.Red;
            BtnDeleteCategory.Cursor = Cursors.Hand;
            BtnDeleteCategory.FlatAppearance.BorderSize = 0;
            BtnDeleteCategory.FlatStyle = FlatStyle.Flat;
            BtnDeleteCategory.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnDeleteCategory.ForeColor = Color.White;
            BtnDeleteCategory.Location = new Point(712, 569);
            BtnDeleteCategory.Name = "BtnDeleteCategory";
            BtnDeleteCategory.Size = new Size(112, 35);
            BtnDeleteCategory.TabIndex = 3;
            BtnDeleteCategory.Text = "Delete";
            BtnDeleteCategory.UseVisualStyleBackColor = false;
            BtnDeleteCategory.Click += BtnDeleteCategory_Click;
            // 
            // BtnUpdateCategory
            // 
            BtnUpdateCategory.BackColor = Color.LimeGreen;
            BtnUpdateCategory.Cursor = Cursors.Hand;
            BtnUpdateCategory.FlatAppearance.BorderSize = 0;
            BtnUpdateCategory.FlatStyle = FlatStyle.Flat;
            BtnUpdateCategory.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnUpdateCategory.ForeColor = Color.White;
            BtnUpdateCategory.Location = new Point(594, 569);
            BtnUpdateCategory.Name = "BtnUpdateCategory";
            BtnUpdateCategory.Size = new Size(112, 35);
            BtnUpdateCategory.TabIndex = 2;
            BtnUpdateCategory.Text = "Update";
            BtnUpdateCategory.UseVisualStyleBackColor = false;
            BtnUpdateCategory.Click += BtnUpdateCategory_Click;
            // 
            // BtnNewCategory
            // 
            BtnNewCategory.BackColor = SystemColors.Highlight;
            BtnNewCategory.Cursor = Cursors.Hand;
            BtnNewCategory.FlatAppearance.BorderSize = 0;
            BtnNewCategory.FlatStyle = FlatStyle.Flat;
            BtnNewCategory.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnNewCategory.ForeColor = Color.White;
            BtnNewCategory.Location = new Point(476, 569);
            BtnNewCategory.Name = "BtnNewCategory";
            BtnNewCategory.Size = new Size(112, 35);
            BtnNewCategory.TabIndex = 1;
            BtnNewCategory.Text = "New";
            BtnNewCategory.UseVisualStyleBackColor = false;
            BtnNewCategory.Click += BtnNewCategory_Click;
            // 
            // DgvCategories
            // 
            DgvCategories.AllowUserToAddRows = false;
            DgvCategories.AllowUserToDeleteRows = false;
            DgvCategories.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvCategories.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            DgvCategories.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            DgvCategories.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvCategories.Location = new Point(13, 39);
            DgvCategories.Name = "DgvCategories";
            DgvCategories.ReadOnly = true;
            DgvCategories.RowTemplate.Height = 25;
            DgvCategories.Size = new Size(375, 520);
            DgvCategories.TabIndex = 0;
            // 
            // PnlOwners
            // 
            PnlOwners.BackColor = Color.White;
            PnlOwners.Controls.Add(TxtSearchOwner);
            PnlOwners.Controls.Add(BtnDeleteOwner);
            PnlOwners.Controls.Add(BtnUpdateOwner);
            PnlOwners.Controls.Add(BtnNewOwner);
            PnlOwners.Controls.Add(DgvOwners);
            PnlOwners.Location = new Point(185, 9);
            PnlOwners.Name = "PnlOwners";
            PnlOwners.Size = new Size(837, 614);
            PnlOwners.TabIndex = 4;
            PnlOwners.Visible = false;
            // 
            // TxtSearchOwner
            // 
            TxtSearchOwner.Location = new Point(13, 10);
            TxtSearchOwner.Name = "TxtSearchOwner";
            TxtSearchOwner.PlaceholderText = "Search Pet Owner";
            TxtSearchOwner.Size = new Size(256, 23);
            TxtSearchOwner.TabIndex = 5;
            TxtSearchOwner.TextChanged += TxtSearchOwner_TextChanged;
            // 
            // BtnDeleteOwner
            // 
            BtnDeleteOwner.BackColor = Color.Red;
            BtnDeleteOwner.Cursor = Cursors.Hand;
            BtnDeleteOwner.FlatAppearance.BorderSize = 0;
            BtnDeleteOwner.FlatStyle = FlatStyle.Flat;
            BtnDeleteOwner.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnDeleteOwner.ForeColor = Color.White;
            BtnDeleteOwner.Location = new Point(712, 569);
            BtnDeleteOwner.Name = "BtnDeleteOwner";
            BtnDeleteOwner.Size = new Size(112, 35);
            BtnDeleteOwner.TabIndex = 3;
            BtnDeleteOwner.Text = "Delete";
            BtnDeleteOwner.UseVisualStyleBackColor = false;
            BtnDeleteOwner.Click += BtnDeleteOwner_Click;
            // 
            // BtnUpdateOwner
            // 
            BtnUpdateOwner.BackColor = Color.LimeGreen;
            BtnUpdateOwner.Cursor = Cursors.Hand;
            BtnUpdateOwner.FlatAppearance.BorderSize = 0;
            BtnUpdateOwner.FlatStyle = FlatStyle.Flat;
            BtnUpdateOwner.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnUpdateOwner.ForeColor = Color.White;
            BtnUpdateOwner.Location = new Point(594, 569);
            BtnUpdateOwner.Name = "BtnUpdateOwner";
            BtnUpdateOwner.Size = new Size(112, 35);
            BtnUpdateOwner.TabIndex = 2;
            BtnUpdateOwner.Text = "Update";
            BtnUpdateOwner.UseVisualStyleBackColor = false;
            BtnUpdateOwner.Click += BtnUpdateOwner_Click;
            // 
            // BtnNewOwner
            // 
            BtnNewOwner.BackColor = SystemColors.Highlight;
            BtnNewOwner.Cursor = Cursors.Hand;
            BtnNewOwner.FlatAppearance.BorderSize = 0;
            BtnNewOwner.FlatStyle = FlatStyle.Flat;
            BtnNewOwner.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnNewOwner.ForeColor = Color.White;
            BtnNewOwner.Location = new Point(476, 569);
            BtnNewOwner.Name = "BtnNewOwner";
            BtnNewOwner.Size = new Size(112, 35);
            BtnNewOwner.TabIndex = 1;
            BtnNewOwner.Text = "New";
            BtnNewOwner.UseVisualStyleBackColor = false;
            BtnNewOwner.Click += BtnNewOwner_Click;
            // 
            // DgvOwners
            // 
            DgvOwners.AllowUserToAddRows = false;
            DgvOwners.AllowUserToDeleteRows = false;
            DgvOwners.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvOwners.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = SystemColors.Control;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.False;
            DgvOwners.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            DgvOwners.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvOwners.Location = new Point(13, 39);
            DgvOwners.Name = "DgvOwners";
            DgvOwners.ReadOnly = true;
            DgvOwners.RowTemplate.Height = 25;
            DgvOwners.Size = new Size(811, 520);
            DgvOwners.TabIndex = 0;
            // 
            // PnlAppointments
            // 
            PnlAppointments.BackColor = Color.White;
            PnlAppointments.Controls.Add(BtnDeleteAppointment);
            PnlAppointments.Controls.Add(DtpAppointmentsTo);
            PnlAppointments.Controls.Add(label2);
            PnlAppointments.Controls.Add(label3);
            PnlAppointments.Controls.Add(DtpAppointmentsFrom);
            PnlAppointments.Controls.Add(TxtSearchAppointment);
            PnlAppointments.Controls.Add(BtnUpdateAppointment);
            PnlAppointments.Controls.Add(BtnNewAppointment);
            PnlAppointments.Controls.Add(DgvAppointments);
            PnlAppointments.Location = new Point(185, 9);
            PnlAppointments.Name = "PnlAppointments";
            PnlAppointments.Size = new Size(837, 614);
            PnlAppointments.TabIndex = 6;
            PnlAppointments.Visible = false;
            // 
            // BtnDeleteAppointment
            // 
            BtnDeleteAppointment.BackColor = Color.Red;
            BtnDeleteAppointment.Cursor = Cursors.Hand;
            BtnDeleteAppointment.FlatAppearance.BorderSize = 0;
            BtnDeleteAppointment.FlatStyle = FlatStyle.Flat;
            BtnDeleteAppointment.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnDeleteAppointment.ForeColor = Color.White;
            BtnDeleteAppointment.Location = new Point(709, 565);
            BtnDeleteAppointment.Name = "BtnDeleteAppointment";
            BtnDeleteAppointment.Size = new Size(112, 35);
            BtnDeleteAppointment.TabIndex = 15;
            BtnDeleteAppointment.Text = "Delete";
            BtnDeleteAppointment.UseVisualStyleBackColor = false;
            BtnDeleteAppointment.Click += BtnDeleteAppointment_Click;
            // 
            // DtpAppointmentsTo
            // 
            DtpAppointmentsTo.CustomFormat = "MMMM dd, yyyy";
            DtpAppointmentsTo.Format = DateTimePickerFormat.Custom;
            DtpAppointmentsTo.Location = new Point(640, 10);
            DtpAppointmentsTo.Name = "DtpAppointmentsTo";
            DtpAppointmentsTo.Size = new Size(184, 23);
            DtpAppointmentsTo.TabIndex = 14;
            DtpAppointmentsTo.ValueChanged += DtpAppointmentsTo_ValueChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(615, 14);
            label2.Name = "label2";
            label2.Size = new Size(20, 15);
            label2.TabIndex = 13;
            label2.Text = "To";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(374, 14);
            label3.Name = "label3";
            label3.Size = new Size(36, 15);
            label3.TabIndex = 12;
            label3.Text = "From";
            // 
            // DtpAppointmentsFrom
            // 
            DtpAppointmentsFrom.CustomFormat = "MMMM dd, yyyy";
            DtpAppointmentsFrom.Format = DateTimePickerFormat.Custom;
            DtpAppointmentsFrom.Location = new Point(415, 10);
            DtpAppointmentsFrom.Name = "DtpAppointmentsFrom";
            DtpAppointmentsFrom.Size = new Size(184, 23);
            DtpAppointmentsFrom.TabIndex = 11;
            DtpAppointmentsFrom.ValueChanged += DtpAppointmentsFrom_ValueChanged;
            // 
            // TxtSearchAppointment
            // 
            TxtSearchAppointment.Location = new Point(13, 10);
            TxtSearchAppointment.Name = "TxtSearchAppointment";
            TxtSearchAppointment.PlaceholderText = "Search Appointment";
            TxtSearchAppointment.Size = new Size(256, 23);
            TxtSearchAppointment.TabIndex = 5;
            TxtSearchAppointment.TextChanged += TxtSearchAppointment_TextChanged;
            // 
            // BtnUpdateAppointment
            // 
            BtnUpdateAppointment.BackColor = Color.LimeGreen;
            BtnUpdateAppointment.Cursor = Cursors.Hand;
            BtnUpdateAppointment.FlatAppearance.BorderSize = 0;
            BtnUpdateAppointment.FlatStyle = FlatStyle.Flat;
            BtnUpdateAppointment.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnUpdateAppointment.ForeColor = Color.White;
            BtnUpdateAppointment.Location = new Point(591, 565);
            BtnUpdateAppointment.Name = "BtnUpdateAppointment";
            BtnUpdateAppointment.Size = new Size(112, 35);
            BtnUpdateAppointment.TabIndex = 2;
            BtnUpdateAppointment.Text = "Update";
            BtnUpdateAppointment.UseVisualStyleBackColor = false;
            BtnUpdateAppointment.Click += BtnUpdateAppointment_Click;
            // 
            // BtnNewAppointment
            // 
            BtnNewAppointment.BackColor = SystemColors.Highlight;
            BtnNewAppointment.Cursor = Cursors.Hand;
            BtnNewAppointment.FlatAppearance.BorderSize = 0;
            BtnNewAppointment.FlatStyle = FlatStyle.Flat;
            BtnNewAppointment.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnNewAppointment.ForeColor = Color.White;
            BtnNewAppointment.Location = new Point(473, 565);
            BtnNewAppointment.Name = "BtnNewAppointment";
            BtnNewAppointment.Size = new Size(112, 35);
            BtnNewAppointment.TabIndex = 1;
            BtnNewAppointment.Text = "New";
            BtnNewAppointment.UseVisualStyleBackColor = false;
            BtnNewAppointment.Click += BtnNewAppointment_Click;
            // 
            // DgvAppointments
            // 
            DgvAppointments.AllowUserToAddRows = false;
            DgvAppointments.AllowUserToDeleteRows = false;
            DgvAppointments.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvAppointments.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = SystemColors.Control;
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle5.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
            DgvAppointments.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            DgvAppointments.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvAppointments.Location = new Point(13, 39);
            DgvAppointments.Name = "DgvAppointments";
            DgvAppointments.ReadOnly = true;
            DgvAppointments.RowTemplate.Height = 25;
            DgvAppointments.Size = new Size(811, 520);
            DgvAppointments.TabIndex = 0;
            // 
            // PnlPets
            // 
            PnlPets.BackColor = Color.White;
            PnlPets.Controls.Add(BtnActivitiesPet);
            PnlPets.Controls.Add(TxtSearchPet);
            PnlPets.Controls.Add(BtnDeletePet);
            PnlPets.Controls.Add(BtnUpdatePet);
            PnlPets.Controls.Add(BtnNewPet);
            PnlPets.Controls.Add(DgvPets);
            PnlPets.Location = new Point(185, 9);
            PnlPets.Name = "PnlPets";
            PnlPets.Size = new Size(837, 614);
            PnlPets.TabIndex = 5;
            PnlPets.Visible = false;
            // 
            // BtnActivitiesPet
            // 
            BtnActivitiesPet.BackColor = Color.LimeGreen;
            BtnActivitiesPet.Cursor = Cursors.Hand;
            BtnActivitiesPet.FlatAppearance.BorderSize = 0;
            BtnActivitiesPet.FlatStyle = FlatStyle.Flat;
            BtnActivitiesPet.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnActivitiesPet.ForeColor = Color.White;
            BtnActivitiesPet.Location = new Point(358, 569);
            BtnActivitiesPet.Name = "BtnActivitiesPet";
            BtnActivitiesPet.Size = new Size(112, 35);
            BtnActivitiesPet.TabIndex = 7;
            BtnActivitiesPet.Text = "Activities";
            BtnActivitiesPet.UseVisualStyleBackColor = false;
            BtnActivitiesPet.Click += BtnActivitiesPet_Click;
            // 
            // TxtSearchPet
            // 
            TxtSearchPet.Location = new Point(13, 10);
            TxtSearchPet.Name = "TxtSearchPet";
            TxtSearchPet.PlaceholderText = "Search Pet";
            TxtSearchPet.Size = new Size(256, 23);
            TxtSearchPet.TabIndex = 4;
            TxtSearchPet.TextChanged += TxtSearchPet_TextChanged;
            // 
            // BtnDeletePet
            // 
            BtnDeletePet.BackColor = Color.Red;
            BtnDeletePet.Cursor = Cursors.Hand;
            BtnDeletePet.FlatAppearance.BorderSize = 0;
            BtnDeletePet.FlatStyle = FlatStyle.Flat;
            BtnDeletePet.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnDeletePet.ForeColor = Color.White;
            BtnDeletePet.Location = new Point(709, 569);
            BtnDeletePet.Name = "BtnDeletePet";
            BtnDeletePet.Size = new Size(112, 35);
            BtnDeletePet.TabIndex = 3;
            BtnDeletePet.Text = "Delete";
            BtnDeletePet.UseVisualStyleBackColor = false;
            BtnDeletePet.Click += BtnDeletePet_Click;
            // 
            // BtnUpdatePet
            // 
            BtnUpdatePet.BackColor = Color.LimeGreen;
            BtnUpdatePet.Cursor = Cursors.Hand;
            BtnUpdatePet.FlatAppearance.BorderSize = 0;
            BtnUpdatePet.FlatStyle = FlatStyle.Flat;
            BtnUpdatePet.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnUpdatePet.ForeColor = Color.White;
            BtnUpdatePet.Location = new Point(594, 569);
            BtnUpdatePet.Name = "BtnUpdatePet";
            BtnUpdatePet.Size = new Size(112, 35);
            BtnUpdatePet.TabIndex = 2;
            BtnUpdatePet.Text = "Update";
            BtnUpdatePet.UseVisualStyleBackColor = false;
            BtnUpdatePet.Click += BtnUpdatePet_Click;
            // 
            // BtnNewPet
            // 
            BtnNewPet.BackColor = SystemColors.Highlight;
            BtnNewPet.Cursor = Cursors.Hand;
            BtnNewPet.FlatAppearance.BorderSize = 0;
            BtnNewPet.FlatStyle = FlatStyle.Flat;
            BtnNewPet.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnNewPet.ForeColor = Color.White;
            BtnNewPet.Location = new Point(476, 569);
            BtnNewPet.Name = "BtnNewPet";
            BtnNewPet.Size = new Size(112, 35);
            BtnNewPet.TabIndex = 1;
            BtnNewPet.Text = "New";
            BtnNewPet.UseVisualStyleBackColor = false;
            BtnNewPet.Click += BtnNewPet_Click;
            // 
            // DgvPets
            // 
            DgvPets.AllowUserToAddRows = false;
            DgvPets.AllowUserToDeleteRows = false;
            DgvPets.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvPets.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = SystemColors.Control;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.False;
            DgvPets.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            DgvPets.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvPets.Location = new Point(13, 39);
            DgvPets.Name = "DgvPets";
            DgvPets.ReadOnly = true;
            DgvPets.RowTemplate.Height = 25;
            DgvPets.Size = new Size(811, 520);
            DgvPets.TabIndex = 0;
            // 
            // PnlHomeAdmin
            // 
            PnlHomeAdmin.BackColor = Color.White;
            PnlHomeAdmin.Controls.Add(GrpTodaysAppointments);
            PnlHomeAdmin.Controls.Add(GrpExpiredAppointments);
            PnlHomeAdmin.Controls.Add(GrpExpiredProducts);
            PnlHomeAdmin.Location = new Point(185, 9);
            PnlHomeAdmin.Name = "PnlHomeAdmin";
            PnlHomeAdmin.Size = new Size(834, 614);
            PnlHomeAdmin.TabIndex = 4;
            // 
            // GrpTodaysAppointments
            // 
            GrpTodaysAppointments.Controls.Add(DgvTodaysAppointments);
            GrpTodaysAppointments.Location = new Point(342, 312);
            GrpTodaysAppointments.Name = "GrpTodaysAppointments";
            GrpTodaysAppointments.Size = new Size(489, 294);
            GrpTodaysAppointments.TabIndex = 2;
            GrpTodaysAppointments.TabStop = false;
            GrpTodaysAppointments.Text = "Todays Appointments";
            // 
            // DgvTodaysAppointments
            // 
            DgvTodaysAppointments.AllowUserToAddRows = false;
            DgvTodaysAppointments.AllowUserToDeleteRows = false;
            DgvTodaysAppointments.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvTodaysAppointments.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = SystemColors.Control;
            dataGridViewCellStyle7.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle7.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.False;
            DgvTodaysAppointments.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            DgvTodaysAppointments.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvTodaysAppointments.Location = new Point(6, 22);
            DgvTodaysAppointments.Name = "DgvTodaysAppointments";
            DgvTodaysAppointments.ReadOnly = true;
            DgvTodaysAppointments.RowTemplate.Height = 25;
            DgvTodaysAppointments.Size = new Size(477, 266);
            DgvTodaysAppointments.TabIndex = 22;
            // 
            // GrpExpiredAppointments
            // 
            GrpExpiredAppointments.Controls.Add(DgvExpiredAppointments);
            GrpExpiredAppointments.ForeColor = SystemColors.ControlText;
            GrpExpiredAppointments.Location = new Point(342, 11);
            GrpExpiredAppointments.Name = "GrpExpiredAppointments";
            GrpExpiredAppointments.Size = new Size(489, 295);
            GrpExpiredAppointments.TabIndex = 1;
            GrpExpiredAppointments.TabStop = false;
            GrpExpiredAppointments.Text = "Expired Appointments";
            // 
            // DgvExpiredAppointments
            // 
            DgvExpiredAppointments.AllowUserToAddRows = false;
            DgvExpiredAppointments.AllowUserToDeleteRows = false;
            DgvExpiredAppointments.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvExpiredAppointments.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = SystemColors.Control;
            dataGridViewCellStyle8.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle8.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.False;
            DgvExpiredAppointments.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            DgvExpiredAppointments.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvExpiredAppointments.Location = new Point(6, 21);
            DgvExpiredAppointments.Name = "DgvExpiredAppointments";
            DgvExpiredAppointments.ReadOnly = true;
            DgvExpiredAppointments.RowTemplate.Height = 25;
            DgvExpiredAppointments.Size = new Size(477, 268);
            DgvExpiredAppointments.TabIndex = 21;
            // 
            // GrpExpiredProducts
            // 
            GrpExpiredProducts.Controls.Add(DgvExpiredProducts);
            GrpExpiredProducts.Location = new Point(3, 10);
            GrpExpiredProducts.Name = "GrpExpiredProducts";
            GrpExpiredProducts.Size = new Size(326, 596);
            GrpExpiredProducts.TabIndex = 0;
            GrpExpiredProducts.TabStop = false;
            GrpExpiredProducts.Text = "Expired Products";
            // 
            // DgvExpiredProducts
            // 
            DgvExpiredProducts.AllowUserToAddRows = false;
            DgvExpiredProducts.AllowUserToDeleteRows = false;
            DgvExpiredProducts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvExpiredProducts.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = SystemColors.Control;
            dataGridViewCellStyle9.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle9.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = DataGridViewTriState.False;
            DgvExpiredProducts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            DgvExpiredProducts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvExpiredProducts.Location = new Point(6, 22);
            DgvExpiredProducts.Name = "DgvExpiredProducts";
            DgvExpiredProducts.ReadOnly = true;
            DgvExpiredProducts.RowTemplate.Height = 25;
            DgvExpiredProducts.Size = new Size(314, 568);
            DgvExpiredProducts.TabIndex = 20;
            // 
            // PnlHomeCashier
            // 
            PnlHomeCashier.BackColor = Color.White;
            PnlHomeCashier.Controls.Add(PicCompany);
            PnlHomeCashier.Location = new Point(187, 9);
            PnlHomeCashier.Name = "PnlHomeCashier";
            PnlHomeCashier.Size = new Size(834, 614);
            PnlHomeCashier.TabIndex = 5;
            // 
            // PicCompany
            // 
            PicCompany.Image = (Image)resources.GetObject("PicCompany.Image");
            PicCompany.Location = new Point(3, 65);
            PicCompany.Name = "PicCompany";
            PicCompany.Size = new Size(829, 494);
            PicCompany.SizeMode = PictureBoxSizeMode.StretchImage;
            PicCompany.TabIndex = 0;
            PicCompany.TabStop = false;
            // 
            // PnlOrders
            // 
            PnlOrders.BackColor = Color.White;
            PnlOrders.Controls.Add(DtpOrdersTo);
            PnlOrders.Controls.Add(LblTo);
            PnlOrders.Controls.Add(LblFrom);
            PnlOrders.Controls.Add(DtpOrdersFrom);
            PnlOrders.Controls.Add(TxtSearchOrder);
            PnlOrders.Controls.Add(BtnUpdateOrder);
            PnlOrders.Controls.Add(BtnNewOrder);
            PnlOrders.Controls.Add(DgvOrders);
            PnlOrders.Controls.Add(BtnViewOrder);
            PnlOrders.Location = new Point(185, 9);
            PnlOrders.Name = "PnlOrders";
            PnlOrders.Size = new Size(837, 614);
            PnlOrders.TabIndex = 7;
            PnlOrders.Visible = false;
            // 
            // DtpOrdersTo
            // 
            DtpOrdersTo.CustomFormat = "MMMM dd, yyyy";
            DtpOrdersTo.Format = DateTimePickerFormat.Custom;
            DtpOrdersTo.Location = new Point(640, 10);
            DtpOrdersTo.Name = "DtpOrdersTo";
            DtpOrdersTo.Size = new Size(184, 23);
            DtpOrdersTo.TabIndex = 10;
            DtpOrdersTo.ValueChanged += DtpOrdersTo_ValueChanged;
            // 
            // LblTo
            // 
            LblTo.AutoSize = true;
            LblTo.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            LblTo.Location = new Point(615, 14);
            LblTo.Name = "LblTo";
            LblTo.Size = new Size(20, 15);
            LblTo.TabIndex = 9;
            LblTo.Text = "To";
            // 
            // LblFrom
            // 
            LblFrom.AutoSize = true;
            LblFrom.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            LblFrom.Location = new Point(374, 14);
            LblFrom.Name = "LblFrom";
            LblFrom.Size = new Size(36, 15);
            LblFrom.TabIndex = 8;
            LblFrom.Text = "From";
            // 
            // DtpOrdersFrom
            // 
            DtpOrdersFrom.CustomFormat = "MMMM dd, yyyy";
            DtpOrdersFrom.Format = DateTimePickerFormat.Custom;
            DtpOrdersFrom.Location = new Point(415, 10);
            DtpOrdersFrom.Name = "DtpOrdersFrom";
            DtpOrdersFrom.Size = new Size(184, 23);
            DtpOrdersFrom.TabIndex = 7;
            DtpOrdersFrom.ValueChanged += DtpOrdersFrom_ValueChanged;
            // 
            // TxtSearchOrder
            // 
            TxtSearchOrder.Location = new Point(13, 10);
            TxtSearchOrder.Name = "TxtSearchOrder";
            TxtSearchOrder.PlaceholderText = "Search Order";
            TxtSearchOrder.Size = new Size(256, 23);
            TxtSearchOrder.TabIndex = 5;
            TxtSearchOrder.TextChanged += TxtSearchOrder_TextChanged;
            // 
            // BtnUpdateOrder
            // 
            BtnUpdateOrder.BackColor = Color.LimeGreen;
            BtnUpdateOrder.Cursor = Cursors.Hand;
            BtnUpdateOrder.FlatAppearance.BorderSize = 0;
            BtnUpdateOrder.FlatStyle = FlatStyle.Flat;
            BtnUpdateOrder.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnUpdateOrder.ForeColor = Color.White;
            BtnUpdateOrder.Location = new Point(712, 565);
            BtnUpdateOrder.Name = "BtnUpdateOrder";
            BtnUpdateOrder.Size = new Size(112, 35);
            BtnUpdateOrder.TabIndex = 2;
            BtnUpdateOrder.Text = "Update";
            BtnUpdateOrder.UseVisualStyleBackColor = false;
            BtnUpdateOrder.Click += BtnUpdateOrder_Click;
            // 
            // BtnNewOrder
            // 
            BtnNewOrder.BackColor = SystemColors.Highlight;
            BtnNewOrder.Cursor = Cursors.Hand;
            BtnNewOrder.FlatAppearance.BorderSize = 0;
            BtnNewOrder.FlatStyle = FlatStyle.Flat;
            BtnNewOrder.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnNewOrder.ForeColor = Color.White;
            BtnNewOrder.Location = new Point(594, 565);
            BtnNewOrder.Name = "BtnNewOrder";
            BtnNewOrder.Size = new Size(112, 35);
            BtnNewOrder.TabIndex = 1;
            BtnNewOrder.Text = "New";
            BtnNewOrder.UseVisualStyleBackColor = false;
            BtnNewOrder.Click += BtnNewOrder_Click;
            // 
            // DgvOrders
            // 
            DgvOrders.AllowUserToAddRows = false;
            DgvOrders.AllowUserToDeleteRows = false;
            DgvOrders.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvOrders.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle10.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = SystemColors.Control;
            dataGridViewCellStyle10.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle10.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = DataGridViewTriState.False;
            DgvOrders.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            DgvOrders.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvOrders.Location = new Point(13, 39);
            DgvOrders.Name = "DgvOrders";
            DgvOrders.ReadOnly = true;
            DgvOrders.RowTemplate.Height = 25;
            DgvOrders.Size = new Size(811, 520);
            DgvOrders.TabIndex = 0;
            // 
            // BtnViewOrder
            // 
            BtnViewOrder.BackColor = Color.LimeGreen;
            BtnViewOrder.Cursor = Cursors.Hand;
            BtnViewOrder.FlatAppearance.BorderSize = 0;
            BtnViewOrder.FlatStyle = FlatStyle.Flat;
            BtnViewOrder.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BtnViewOrder.ForeColor = Color.White;
            BtnViewOrder.Location = new Point(476, 565);
            BtnViewOrder.Name = "BtnViewOrder";
            BtnViewOrder.Size = new Size(112, 35);
            BtnViewOrder.TabIndex = 6;
            BtnViewOrder.Text = "View";
            BtnViewOrder.UseVisualStyleBackColor = false;
            BtnViewOrder.Click += BtnViewOrder_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkTurquoise;
            ClientSize = new Size(1034, 632);
            Controls.Add(panel1);
            Controls.Add(PnlOrders);
            Controls.Add(PnlProducts);
            Controls.Add(PnlAppointments);
            Controls.Add(PnlCashiers);
            Controls.Add(PnlHomeCashier);
            Controls.Add(PnlHomeAdmin);
            Controls.Add(PnlPets);
            Controls.Add(PnlOwners);
            Controls.Add(PnlCategories);
            FormBorderStyle = FormBorderStyle.None;
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MainForm";
            Load += MainForm_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)PicUser).EndInit();
            PnlAdminNav.ResumeLayout(false);
            PnlCashierNav.ResumeLayout(false);
            PnlCashiers.ResumeLayout(false);
            PnlCashiers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DgvCashiers).EndInit();
            PnlProducts.ResumeLayout(false);
            PnlProducts.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DgvProducts).EndInit();
            PnlCategories.ResumeLayout(false);
            PnlCategories.PerformLayout();
            GrpBoxCategory.ResumeLayout(false);
            GrpBoxCategory.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DgvCategories).EndInit();
            PnlOwners.ResumeLayout(false);
            PnlOwners.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DgvOwners).EndInit();
            PnlAppointments.ResumeLayout(false);
            PnlAppointments.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DgvAppointments).EndInit();
            PnlPets.ResumeLayout(false);
            PnlPets.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DgvPets).EndInit();
            PnlHomeAdmin.ResumeLayout(false);
            GrpTodaysAppointments.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)DgvTodaysAppointments).EndInit();
            GrpExpiredAppointments.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)DgvExpiredAppointments).EndInit();
            GrpExpiredProducts.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)DgvExpiredProducts).EndInit();
            PnlHomeCashier.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)PicCompany).EndInit();
            PnlOrders.ResumeLayout(false);
            PnlOrders.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DgvOrders).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private PictureBox PicUser;
        private Panel PnlAdminNav;
        private Button BtnLogoutAdmin;
        private Button BtnCashiersAdmin;
        private Panel PnlCashiers;
        private DataGridView DgvCashiers;
        private Button BtnNewCashier;
        private Button BtnUpdateCashier;
        private Button BtnDeleteCashier;
        private Button BtnHomeAdmin;
        private Panel PnlHomeAdmin;
        private TextBox TxtUserFullName;
        private TextBox TxtUserRole;
        private Panel PnlCashierNav;
        private Button BtnHomeCashier;
        private Button BtnLogoutCashier;
        private Button BtnOwnersAdmin;
        private Panel PnlOwners;
        private Button BtnDeleteOwner;
        private Button BtnUpdateOwner;
        private Button BtnNewOwner;
        private DataGridView DgvOwners;
        private Button BtnPetsAdmin;
        private Panel PnlPets;
        private Button BtnDeletePet;
        private Button BtnUpdatePet;
        private Button BtnNewPet;
        private DataGridView DgvPets;
        private TextBox TxtSearchPet;
        private TextBox TxtSearchCashier;
        private TextBox TxtSearchOwner;
        private Button BtnProductsAdmin;
        private Panel PnlProducts;
        private TextBox TxtSearchProduct;
        private Button BtnDeleteProduct;
        private Button BtnUpdateProduct;
        private Button BtnNewProduct;
        private DataGridView DgvProducts;
        private Button BtnCategoriesAdmin;
        private Panel PnlCategories;
        private TextBox TxtSearchCategory;
        private Button BtnDeleteCategory;
        private Button BtnUpdateCategory;
        private Button BtnNewCategory;
        private DataGridView DgvCategories;
        private GroupBox GrpBoxCategory;
        private TextBox TxtCategory;
        private Label label1;
        private Button BtnSaveCategory;
        private Button BtnCancelCategory;
        private Button BtnOrdersCashier;
        private Panel PnlOrders;
        private TextBox TxtSearchOrder;
        private Button BtnUpdateOrder;
        private Button BtnNewOrder;
        private DataGridView DgvOrders;
        private Button BtnViewOrder;
        private Label LblFrom;
        private DateTimePicker DtpOrdersFrom;
        private DateTimePicker DtpOrdersTo;
        private Label LblTo;
        private Button BtnProductsCashier;
        private Button BtnOrdersAdmin;
        private Button BtnActivitiesPet;
        private Button BtnAppointmentsAdmin;
        private Panel PnlAppointments;
        private TextBox TxtSearchAppointment;
        private Button BtnUpdateAppointment;
        private Button BtnNewAppointment;
        private DataGridView DgvAppointments;
        private DateTimePicker DtpAppointmentsTo;
        private Label label2;
        private Label label3;
        private DateTimePicker DtpAppointmentsFrom;
        private Button BtnDeleteAppointment;
        private GroupBox GrpTodaysAppointments;
        private GroupBox GrpExpiredAppointments;
        private GroupBox GrpExpiredProducts;
        private DataGridView DgvTodaysAppointments;
        private DataGridView DgvExpiredAppointments;
        private DataGridView DgvExpiredProducts;
        private CheckBox ChkExpiration;
        private PictureBox picCompany;
        private Panel PnlHomeCashier;
        private PictureBox PicCompany;
    }
}